import smtplib, ssl
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import pandas as pd
import json
import boto3
import logging
from ..src.etl_config import ETLConfig


class NotificationUtility:

    def __init__(self, json_message_0, etl_config: ETLConfig):
        self.json_message_0 = json_message_0
        self.etl_config = etl_config
        self.logger = logging.getLogger("my_logger")
        '''
        Args:
        etl_config
        json_message_0 :



        '''

    def send_sns(self):
        """
        Returns :
            my_dict
        """
        try:
            success = True
            self.logger.info('Executing send_sns')
            sns = boto3.client('sns')

            self.logger.info("Send_SNS: {}".format(self.json_message_0))

            self.logger.info('sns_topic')

            response = sns.publish(
                TargetArn=self.etl_config.sns_topic,
                MessageStructure="json",
                Message=self.json_message_0
            )
            self.logger.info("Notification has been sent to SNS topic......")
            self.logger.info("SNS response: {}".format(response))
            my_dict = {1: True}
            self.logger.info('my_dict')
            return my_dict, success
        except Exception as e:
            self.logger.error('Error occurred')
            self.logger.error(str(e))
            my_dict = None
            success = False
            return my_dict, success


class SimpleEmailService:
    def __init__(self, json_obj, sender, recipients, subject, etl_config: ETLConfig,
                 smtp_ses_user, smtp_ses_password, smtp_endpoint):
        self.json_obj = json_obj
        self.sender = sender
        self.recipients = recipients
        self.subject = subject
        self.etl_config = etl_config
        self.smtp_ses_user = smtp_ses_user
        self.smtp_ses_password = smtp_ses_password
        self.smtp_endpoint = smtp_endpoint
        self.logger = logging.getLogger("my_logger")

        '''
        Args:
            json_obj:
            sender:
            recipients:
            subject:
            region_name:
            smtp_ses_user:
            smtp_ses_password:
            smtp_endpoint:

        '''

    def send_ses(self):

        """
        Returns:
            my_dict
        """
        self.logger.info('Executing send_ses')

        try:
            success = True
            self.logger.info("json_obj: ")
            self.logger.info(self.json_obj)
            if list(self.json_obj.keys())[0] == "Message":
                self.logger.info("list(self.json_obj.keys())[0] == Message  ")
                body_html = f"""<!DOCTYPE html>
                    <html>
                      <head></head>
                      <body>
                        <p style="font-size:20px">Job Status as follows:- </p>
                        <table style="border:1px solid black;width:100%">
                          <tr>
                            <th style="border:1px solid black">Message </th>
                            <td style="border:1px solid black">{self.json_obj['Message']}</td>
                          </tr>
                          <tr>
                            <th style="border:1px solid black">JOB ID </th>
                            <td style="border:1px solid black">{self.json_obj['Reports Name']}</td>
                          </tr>
                          <tr>
                            <th style="border:1px solid black">No. of Tables </th>
                            <td style="border:1px solid black">{len(self.json_obj['JobTableList'])}</td>
                          </tr>
                          <tr>
                            <th style="border:1px solid black">Table List </th>
                            <td style="border:1px solid black">{', '.join(self.json_obj['JobTableList'])}</td>
                          </tr>
                        </table>
                        <br>
                        <p>
                          <strong>NOTE:</strong>
                          <i>After completion of this Job, a confirmation mail will also arrive</i>
                        </p>
                        <p>
                          <small>**Auto-generated mail sent by the ETL framework</small>
                        </p>
                      </body>
                    </html>"""
                self.logger.info("body_html: ")
                self.logger.info(body_html)
            else:
                self.logger.info("list(self.json_obj.keys())[0] != Message   ")
                info_list = {"Parameter": "Value", "Total no. of tables": [0], "No. of tables Successfully pulled": [0],
                             "No. of tables Failed to pulled": [0], "List of tables Failed to pulled": [0]}
                # self.logger.info(" info_list: ")
                # self.logger.info(info_list)
                df_info = pd.DataFrame(info_list)
                df_info.set_index(['Parameter'], inplace=True)

                df_info['Total no. of tables'] = len(self.json_obj['Reports']) + len(
                    self.json_obj['FailedTableList'])
                df_info['No. of tables Successfully pulled'] = len(self.json_obj['Reports'])
                df_info['No. of tables Failed to pulled'] = len(self.json_obj['FailedTableList'])
                df_info['List of tables Failed to pulled'] = ', '.join(self.json_obj['FailedTableList'])

                df = pd.DataFrame()

                for index in range(len(self.json_obj['Reports'])):
                    df_temp = pd.json_normalize(self.json_obj['Reports'][index])
                    df = pd.concat([df, df_temp], ignore_index=True)
                self.logger.info(" Display Pandas DF.....")
                with pd.option_context('display.max_rows', None, 'display.max_columns', None):
                    print(df)
                '''
                if len(self.json_obj['Reports']) > 0:
                    self.logger.info(" json_obj['Reports']) > 0 ")
                    df['Start_Time'] = pd.to_datetime(df['Start_Time']).dt.strftime("%Y-%m-%d %H:%M:%S")
                    df['End_Time'] = pd.to_datetime(df['End_Time']).dt.strftime("%Y-%m-%d %H:%M:%S")
                '''
                df.index = df.index + 1

                body_html = f"""<!DOCTYPE html>
                    <html>
                      <head></head>
                      <body>
                        <p style="font-size:20px">-->Job Run Completed<-- </p>
                            <p>Some key details:-</p> {df_info.transpose().to_html()} <br>
                            <p>
                              <strong>Detailed information for all the tables are:- </strong>
                            </p> {df.to_html()} <br>
                            <p>
                              <i>This mail confirms that the Job is completed.</i>
                            </p>
                            <p>
                              <small>**Auto-generated mail sent by the ETL framework</small>
                            </p>
                      </body>
                    </html>"""

            char_set = "UTF-8"
            self.logger.info(" Creating MIMEMultipart ....")
            msg = MIMEMultipart()
            msg['From'] = self.sender
            recipients = self.recipients.split(",")
            msg['To'] = ",".join(recipients)
            if 'Message' in self.json_obj:
                self.logger.info("Message Found in json_obj")
                self.logger.info("Subject: ")
                self.logger.info(self.subject + ": GROUP_"+ str(self.json_obj['Reports Name']))
                msg['Subject'] = self.subject + ": GROUP_"+ str(self.json_obj['Reports Name'])
            else:
                self.logger.info("Message Not Found in json_obj")
                self.logger.info("Subject: ")
                self.logger.info(self.subject+ ': '+str(self.json_obj['Reports'][0]['Job_Name'].upper()))
                msg['Subject'] = self.subject+ ': '+str(self.json_obj['Reports'][0]['Job_Name'].upper())
            self.logger.info(" Attachment ...")
            msg.attach(MIMEText(body_html, 'html'))
            self.logger.info(" Attachment done ....")
            server = smtplib.SMTP_SSL(self.smtp_endpoint, 465, context=ssl.create_default_context())
            server.login(self.smtp_ses_user, self.smtp_ses_password)

            self.logger.info("********** Login into SMTP server: SUCCESS ********** ")
            text = msg.as_string()
            server.sendmail(self.sender, self.recipients.split(","), text)
            server.quit()
            my_dict = {1: 1}
            return my_dict, success

        except Exception as e:
            self.logger.error("ERROR!!  Email not sent ")
            self.logger.error(str(e))
            my_dict = None
            success = False
            return my_dict, success
