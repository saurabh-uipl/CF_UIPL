import paramiko
import logging

logger = logging.getLogger("my_logger")

class SftpUtility:

    def __init__(self):
        self.logger = logging.getLogger("my_logger")

    def get_sftp_conn(host, port, username, password):

        try:
            """ set sftp connection to get the files, using config.py """
            # connect to sftp
            transport = paramiko.Transport(host, int(port))
            logger.info("connecting to SFTP...")
            transport.connect(username=username, password=password)
            sftp = paramiko.SFTPClient.from_transport(transport)
            logger.info("connection established.")
            return sftp

        except Exception as e:
            logger.info("Exception While Connecting to SFTP Server : {} ".format(str(e)))
