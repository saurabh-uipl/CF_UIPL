import boto3
import json
import logging
from ..src.etl_config import ETLConfig


class SecretsManager:

    def __init__(self, secret_name, etl_config: ETLConfig):

        self.etl_config = etl_config
        self.secret_name = secret_name
        self.logger = logging.getLogger("my_logger")

        '''
        Args:
         redshift_secret_name:
         region_name
        '''

    sam_dict = {}

    def get_secret_name(self):

        """
        Returns:
            sam_dict
        """
        success = True
        self.logger.info('Executing get_secret_name')
        session = boto3.session.Session()
        client = session.client(service_name='secretsmanager', region_name=self.etl_config.region_name)
        secret = ''
        try:

            self.logger.info("----------Retrieving Secret Key .................")
            get_secret_value_response = client.get_secret_value(
                SecretId=self.secret_name)
            secret = json.loads(get_secret_value_response['SecretString'])

            self.logger.info("---------- Secret Key Retrieved Successfully by SAMUtility.................")
            sam_dict = {1: secret}
            return sam_dict, success

        except Exception as e:

            self.logger.error("*****ERROR Retrieving Secret Key ***********")
            self.logger.error(str(e))

            sam_dict = {1: secret}
            success = False

            return sam_dict, success
