CREATE TABLE ewa_lakehouse_etl_framework_db.etl_master (
  id int,
  groupid int,
  tablename string,
  business_unit string,
  schemaname string,
  source string,
  loadtype string,
  incrementalcolumn string,
  active int,
  createdate date,
  startdatetime timestamp,
  enddatetime timestamp,
  sql_query string,
  partition_column string,
  priority int,
  pk_columns string,
  merge_query string,
  bucket_name string,
  offset_value bigint,
  audit int,
  destination_type string,
  json_flatten int,
  sftp_file_path string,
  sftp_file_date_columns string,
  pk_col_list string,
  validation_rules string,
  part_col_int string,
  data_validation_date_column string,
  part_lower_bound bigint,
  part_upper_bound bigint,
  num_partitions int,
  data_validation_active int,
  data_validation_column string COMMENT 'Created to store a column value used for data validation.',
  data_validation_required int)
LOCATION 'S3_PATH'
TBLPROPERTIES (
  'table_type'='iceberg',
  'vacuum_max_snapshot_age_seconds'='258',
  'write_compression'='snappy',
  'optimize_rewrite_delete_file_threshold'='2',
  'write_target_data_file_size_bytes'='536870912',
  'optimize_rewrite_data_file_threshold'='10',
  'vacuum_min_snapshots_to_keep'='3'
);

CREATE TABLE ewa_lakehouse_etl_framework_db.audit_table (
  glue_job_name string,
  table_name string,
  business_unit string,
  job_runtime string,
  record_count bigint,
  insert_timestamp string,
  status string,
  exception_description string,
  jobconfig string,
  inventory_last_modified_date string,
  file_name string)
LOCATION 'S3_PATH'
TBLPROPERTIES (
  'table_type'='iceberg',
  'vacuum_max_snapshot_age_seconds'='258',
  'write_compression'='snappy',
  'optimize_rewrite_delete_file_threshold'='2',
  'write_target_data_file_size_bytes'='536870912',
  'optimize_rewrite_data_file_threshold'='10',
  'vacuum_min_snapshots_to_keep'='3'
);

============================ Full Load =============================

INSERT INTO etl_framework.etl_master (id,groupid,tablename,business_unit,schemaname,source,loadtype,incrementalcolumn,active,createdate,startdatetime,enddatetime,sql_query,partition_column,priority,
 pk_columns,merge_query,bucket_name,offset_value,audit)
 VALUES
 (1,1,'TABLE_NAME','business_unit','SCHEMA_NAME','mysql','Full Load',NULL,1,DATE '2022-03-08',TIMESTAMP '2022-03-08 11:55:18.428',NULL,'select * , SYSDATE() pull_time, SYSDATE() updatetime from SCHEMA_NAME.TABLE_NAME',NULL,1,NULL,NULL,'BUCKET_NAME',NULL,1);
 

========================= Incremental Load ===========================

 INSERT INTO etl_framework.etl_master (id,groupid,tablename,schemaname,source,loadtype,incrementalcolumn,active,createdate,startdatetime,enddatetime,sql_query,partition_column,priority,
 pk_columns,merge_query,bucket_name,offset_value,audit)
 VALUES
 (2,1,'TABLE_NAME','business_unit','SCHEMA_NAME','mysql','incremental','product_id',1,DATE '2022-03-08',TIMESTAMP '2022-03-08 11:55:18.428',NULL,'select * , SYSDATE() pull_time, SYSDATE() updatetime from SCHEMA_NAME.TABLE_NAME where INCR_ID >{offset_value}',NULL,1,NULL,NULL,'BUCKET_NAME',1,1);

=========================== Merge Load ================================

 INSERT INTO etl_framework.etl_master (id,groupid,tablename,business_unit,schemaname,source,loadtype,incrementalcolumn,active,createdate,startdatetime,enddatetime,sql_query,partition_column,priority,
pk_columns,merge_query,bucket_name,offset_value,audit)
VALUES
(503,503,'TABLE_NAME','business_unit','SCHEMA_NAME','mysql','merge','order_date',1,DATE '2022-03-08',TIMESTAMP '2021-08-29 17:59:00.000',NULL,'select * , substring(order_date,1,7) as order_month ,SYSDATE() pull_time, SYSDATE() updatetime  from SCHEMA_NAME.TABLE_NAME where INCR_COL_TIMESTAMP > timestamp {startdatetime}','order_month',1,NULL,'select /*+ BROADCAST(delta) */ base.* from base LEFT OUTER JOIN delta ON base.order_id = delta.order_id where delta.order_id IS NULL','BUCKET_NAME',NULL,1);
