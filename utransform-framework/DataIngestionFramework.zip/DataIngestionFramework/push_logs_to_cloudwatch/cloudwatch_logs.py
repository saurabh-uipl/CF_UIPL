from cloudwatch import cloudwatch
import logging


def get_cloudwatch_logger(log_group_name, jobid):
    logger = logging.getLogger('my_logger')
    formatter = logging.Formatter(
        '%(asctime)s | %(levelname)s | %(filename)s | %(funcName)s | JobID:{jobid} | %(message)s'.format(jobid=jobid))

    handler = cloudwatch.CloudwatchHandler(log_group=log_group_name)
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    return logger
