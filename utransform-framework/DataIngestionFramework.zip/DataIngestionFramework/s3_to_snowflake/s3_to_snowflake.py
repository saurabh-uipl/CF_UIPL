from ..analytics_utilities.secrets_manager import SecretsManager
from py4j.java_gateway import java_import


class s3ToSnowflake:
    def __init__(self, spark, region_name='NA', job_dict='NA'):
        self.region_name = region_name
        self.spark = spark
        self.job_dict = job_dict
        '''
        Args:
        spark:
        region_name:
        job_dict:
        
        
        '''

    def s3ToSnowflake(self):


        SNOWFLAKE_SOURCE_NAME = "net.snowflake.spark.snowflake";
        java_import(self.spark._jvm, "net.snowflake.spark.snowflake")
        self.spark._jvm.net.snowflake.spark.snowflake.SnowflakeConnectorUtils.enablePushdownSession(
            self.spark._jvm.org.apache.spark.sql.SparkSession.builder().getOrCreate())
        self.spark.conf.set("spark.sql.session.timeZone", "UTC")
        destination_database = self.job_dict["schema_name"].split(".")[0]
        destination_schema = self.job_dict["schema_name"].split(".")[1]

        sam_utility_obj = SecretsManager(self.job_dict["SOURCE_SECRET_NAME"], self.job_dict["region_name"])


        d = sam_utility_obj.get_secret_name()
        snowflakeConnDetails = d[1]
        s3_file_path = "s3://" + self.job_dict["bucket_name"] + "/" + self.job_dict["source"] + "/" + str(self.job_dict[
                                                                                                              "JOBNAME"]) + "/" + \
                       self.job_dict["table_name"] + "/"

        if self.job_dict["load_type"] == "incremental":
            if (self.job_dict["incremental_value"] == "None" or self.job_dict["incremental_value"] == "nan" or
                    self.job_dict[
                        "incremental_value"] == "<NA>"):
                df = self.spark.read.parquet(s3_file_path).where(
                    "{0} > '{1}' ".format(self.job_dict["incremental_column"], self.job_dict["startdatetime"]))
            else:
                df = self.spark.read.parquet(s3_file_path).where(
                    "{0} > {1} ".format(self.job_dict["incremental_column"], self.job_dict["incremental_value"]))

            java_import(self.spark._jvm, "net.snowflake.self.spark.snowflake")
            self.spark._jvm.net.snowflake.self.spark.snowflake.SnowflakeConnectorUtils.enablePushdownSession(
                self.spark._jvm.org.apache.self.spark.sql.self.sparkSession.builder().getOrCreate())
            df.write.format(SNOWFLAKE_SOURCE_NAME).option("sfUser", str(snowflakeConnDetails['USERNAME'])).option(
                "sfURL", str(snowflakeConnDetails['URL'])).option("sfPassword",
                                                                  str(snowflakeConnDetails['PASSWORD'])).option(
                "sfDatabase", destination_database).option("sfSchema", destination_schema).option("sfWarehouse", str(
                snowflakeConnDetails['WAREHOUSE'])).option("dbtable", self.job_dict["table_name"]).mode("append").save()


        elif self.job_dict["load_type"] == 'merge':

            base_df = self.spark.read.format(SNOWFLAKE_SOURCE_NAME).option("sfUser",
                                                                           str(snowflakeConnDetails[
                                                                                   'USERNAME'])).option(
                "sfURL",
                str(
                    snowflakeConnDetails[
                        'URL'])).option(
                "sfPassword", str(snowflakeConnDetails['PASSWORD'])).option("sfDatabase", destination_database).option(
                "sfSchema", destination_schema).option("sfWarehouse", str(snowflakeConnDetails['WAREHOUSE'])).option(
                "tracing",
                str(
                    snowflakeConnDetails[
                        'TRACING'])).option(
                "insecureMode", str(snowflakeConnDetails['insecureMode'])).option("dbtable",
                                                                                  self.job_dict["table_name"]).load()
            base_df.createOrReplaceTempView("base")

            delta_df = self.spark.read.parquet(s3_file_path).where(
                "{0} > '{1}' ".format(self.job_dict["incremental_column"], self.job_dict["startdatetime"]))

            delta_df_ = delta_df.select(base_df.columns)
            delta_df_.createOrReplaceTempView("delta")

            merge_df = self.spark.sql(self.job_dict["merge_query"])
            df = merge_df.union(delta_df_)

            df.write.format(SNOWFLAKE_SOURCE_NAME).option("sfUser", str(snowflakeConnDetails['USERNAME'])).option(
                "sfURL", str(snowflakeConnDetails['URL'])).option("sfPassword",
                                                                  str(snowflakeConnDetails['PASSWORD'])).option(
                "sfDatabase", destination_database).option("sfSchema", destination_schema).option("sfWarehouse", str(
                snowflakeConnDetails['WAREHOUSE'])).option("dbtable", self.job_dict["table_name"]) \
                .mode("overwrite").save()


        else:
            df = self.spark.read.parquet(s3_file_path)

            df.write.format(SNOWFLAKE_SOURCE_NAME).option("sfUser", str(snowflakeConnDetails['USERNAME'])).option(
                "sfURL", str(snowflakeConnDetails['URL'])).option("sfPassword",
                                                                  str(snowflakeConnDetails['PASSWORD'])).option(
                "sfDatabase", destination_database).option("sfSchema", destination_schema).option("sfWarehouse", str(
                snowflakeConnDetails['WAREHOUSE'])).option("dbtable", self.job_dict["table_name"]) \
                .mode("overwrite").save()
