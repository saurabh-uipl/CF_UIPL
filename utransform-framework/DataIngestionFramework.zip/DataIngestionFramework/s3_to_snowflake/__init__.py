# s3_data_ingestion/__init__.py

from .s3_to_snowflake import s3ToSnowflake
