import awswrangler as wr
import pandas as pd
from pyspark.sql.functions import input_file_name, current_timestamp
from pyspark.sql import DataFrame
from ..common_utilities.Common_utility import CommonUtility
from ..audit_utilities.audit_utility import AuditUtility
import logging
from ..src.etl_config import ETLConfig
from .s3_inventory import update_sql_query_with_datetime_values, update_sql_query_for_table_filter, \
    perform_auditing_tasks, write_dataframes_to_s3_based_on_load_type, write_dataframes_to_s3, \
    process_and_persist_dataframe, deduplicate_with_s3_data, compare_and_merge_dataframes, process_and_merge_csv_data, \
    process_and_merge_json_data, merge_data


class S3DataIngestionInventory:
    def __init__(self, job_dict, etl_config: ETLConfig):

        self.tbl_name_flag = 0
        self.chunk_flag = 0
        self.job_dict = job_dict
        self.etl_config = etl_config
        self.logger = logging.getLogger("my_logger")

        '''
        Args:
         job_dict:
         glueContext:
         redshift_schema_name:
         redshift_audit_table_name:
         redshift_etl_master_table_name:
        athena_db_name:
     
        
        '''

    def s3_data_process(self):
        try:
            self.logger.info(" Execution Started For s3_data_process ......")
            self.logger.info("***TABLE_NAME******")
            self.logger.info(self.job_dict['table_name'])
            is_success = 0
            self.job_dict["records_count"] = 0

            spark = self.etl_config.glueContext

            schema_name = self.job_dict["schema_name"].split(",")

            startdatetime = "'" + self.job_dict["startdatetime"] + "'"
            sql_query_ = self.job_dict["SQL_Query"]
            sql_query_ = sql_query_.replace('"', "'")
            self.logger.info(" sql_query_: {}".format(sql_query_))

            if self.job_dict["load_type"] == "incremental" or self.job_dict["load_type"] == "merge":
                sql_query_ = update_sql_query_for_table_filter(self.job_dict, self.logger, sql_query_)

            else:
                sql_query_ = update_sql_query_with_datetime_values(self.job_dict, self.logger, sql_query_)

            self.logger.info(" Executing query to Athena .....")
            self.logger.info(" SQL Query:{} ".format(sql_query_))

            self.logger.info("database: ")
            self.logger.info('{}'.format(self.job_dict['inventory']))
            dp_pandas_ = wr.athena.read_sql_query(sql_query_, database=self.job_dict['inventory'])
            if dp_pandas_.empty:
                self.logger.info(" Athena Query Result Is Blank .... ")
                self.logger.info(" No data to process .....")
                is_success = 1
            else:
                self.logger.info(" Athena Query Result Is Not Blank ...")
                self.logger.info(" Display Athena Query Result: ")

                path_list = []
                value_ = 0
                chunk_list = []

                dp_pandas_ = dp_pandas_.astype({'last_modified_date': 'string'})
                tbl_dict = dict(zip(dp_pandas_["path"], dp_pandas_["size"]))

                for key, value in tbl_dict.items():
                    if value_ + value <= int(self.job_dict["chunk_size"]):
                        value_ = value_ + value
                        path_list.append(key)
                    elif len(path_list) != 0:
                        chunk_list.append(path_list)
                        value_ = value
                        path_list = []
                        path_list.append(key)
                    else:
                        path_list.append(key)
                        value_ = value
                chunk_list.append(path_list)
                self.logger.info(" pandas to Spark DF")
                df_1 = spark.createDataFrame(dp_pandas_)
                self.logger.info(" Display df_1: ")
                df_1.createOrReplaceTempView('df_1')

                df_1 = spark.sql(
                    'select path, last_modified_date from (SELECT *,ROW_NUMBER() '
                    'OVER (PARTITION BY path ORDER BY last_modified_date DESC) '
                    'as row_num from df_1) as d where row_num = 1')

                self.job_dict["chunk_list_length"] = len(chunk_list)

                for data_chunk in chunk_list:

                    source = self.job_dict["source"].split('_')[-1]

                    if source == "csv":
                        df = process_and_merge_csv_data(self.job_dict, self.logger, data_chunk, df_1, schema_name,
                                                        source, spark)

                    elif source == "json":
                        df = process_and_merge_json_data(self.job_dict, self.logger, data_chunk, df_1, source, spark, self.etl_config)

                    else:
                        df = merge_data(self.job_dict, self.logger, data_chunk, df_1, source, spark)

                    df.createOrReplaceTempView('temp')
                    df_2 = spark.sql(
                        'select count(*) as df_count, file_name,cast(last_modified_date as string) '
                        'from temp group by file_name,last_modified_date')

                    file_name_list = [r[0] for r in df_2.select('file_name').collect()]
                    self.job_dict["file_name_list"] = file_name_list

                    df_count_list = [r[0] for r in df_2.select('df_count').collect()]
                    self.job_dict["df_count_list"] = df_count_list
                    last_modified_date = [r[0] for r in df_2.select('last_modified_date').collect()]
                    self.job_dict["last_modified_date"] = last_modified_date

                    self.job_dict["max_last_modified_date"] = dp_pandas_['last_modified_date'].max()
                    self.logger.info(" TABLE_NAME: *****")
                    self.logger.info(self.job_dict["table_name"])
                    # self.job_dict["inventory_table_name"] = self.job_dict["table_name"]
                    if self.tbl_name_flag == 0:
                        self.logger.info(" tbl_name_flag: {}".format(self.tbl_name_flag))

                        self.job_dict["inventory_table_name"] = self.job_dict["table_name"]
                        tbl_name = self.job_dict["table_name"].split('/')[-2]
                        # self.job_dict["table_name"] = tbl_name
                        self.job_dict["table_name"] = self.job_dict["inventory_table_name"]

                        self.tbl_name_flag = self.tbl_name_flag + 1
                    else:
                        self.job_dict["inventory_table_name"] = self.job_dict["table_name"]
                    self.logger.info("***********UPDATED TABLE NAME*********************")
                    self.logger.info(self.job_dict["table_name"])
                    if 'inventory' not in self.job_dict['source'].lower():
                        d = CommonUtility.remove_special_character(self.job_dict["table_name"])
                        table_names3_suported = d[1]
                        self.logger.info(" ***table_names3_suported: ****")
                        self.logger.info(table_names3_suported)

                        self.job_dict["table_name"] = table_names3_suported

                    if 'inventory' in self.job_dict['source']:
                        new_table_name = self.job_dict["table_name"].split('/')[-2]
                        staging_table = new_table_name + "_staging"
                    else:
                        staging_table = self.job_dict["table_name"] + "_staging"

                    df.createOrReplaceTempView(staging_table)

                    sql_query_staging = "select *, from_utc_timestamp(current_timestamp(), "+"'"+self.etl_config.timezone_param+"'"+") as bdl_created," + "'" + self.job_dict[
                        "JOBNAME"] + "'" + " AS  pipelineid from " + staging_table

                    df = spark.sql(sql_query_staging)

                    if len(self.job_dict["Partition_Column"]) > 0:
                        Partition_Column_new = self.job_dict["Partition_Column"]
                        a = dict(df.dtypes)
                        for k1 in self.job_dict["Partition_Column"]:
                            k = k1.lower()
                            column_type = [a[key] for key in a if key.lower() == k]

                            if "timestamp" in column_type:
                                new_name = k1 + "_dt"
                                Partition_Column_new = [new_name if x == k1 else x for x in Partition_Column_new]

                                df = df.withColumn(new_name, df[k1].cast('date'))

                        self.job_dict["Partition_Column_new"] = Partition_Column_new

                    self.logger.info("Fetching data for table: {}".format(self.job_dict["table_name"]))

                    if self.job_dict["load_type"] == "merge":
                        # Logic to get latest partition
                        Partition_Column = self.job_dict["Partition_Column"]
                        if 'None' in Partition_Column: Partition_Column.remove('None')
                        if '<NA>' in Partition_Column: Partition_Column.remove('<NA>')

                        self.job_dict["Partition_Column"] = Partition_Column

                        if len(self.job_dict["Partition_Column"]) > 1:
                            df_final = compare_and_merge_dataframes(self.job_dict, self.logger, df, spark)
                        else:

                            df_final = deduplicate_with_s3_data(self.job_dict, self.logger, df, spark)
                    else:

                        df_final = process_and_persist_dataframe(self.job_dict, self.logger, df)

                    for col in df_final.columns:
                        df_final = df_final.withColumnRenamed(col, col.lower())
                    df_final = df_final.drop("file_name", "last_modified_date", "path", "size")

                    df_final.printSchema()

                    if len(self.job_dict["Partition_Column"]) > 0:

                        write_dataframes_to_s3(self.job_dict, self.logger, self.chunk_flag, df, df_final, spark)

                    else:
                        write_dataframes_to_s3_based_on_load_type(self.job_dict, self.logger, self.chunk_flag, df,
                                                                  df_final, spark)

                    if self.job_dict["is_audit"] > 0:
                        perform_auditing_tasks(self.job_dict, self.logger, self.etl_config, df)

                if len(self.job_dict['redshiftConnDetails']) != 0:
                    self.logger.info("Update_ETL_Master_Entry call to redshift")
                    audit_utility_obj = AuditUtility(self.job_dict, self.etl_config)
                    d, success = audit_utility_obj.update_etl_master_entry()
                    is_success = d[1]
                else:
                    etl_master_entry_iceberg_obj = AuditUtility(self.job_dict, self.etl_config)
                    self.logger.info(" calling Update_ETL_Master_Entry_Iceberg: ***")
                    d, success = etl_master_entry_iceberg_obj.Update_ETL_Master_Entry_Iceberg()
                    self.logger.info(" calling Update_ETL_Master_Entry_Iceberg ends  here ")
                    self.logger.info("display d:**** {}".format(d))

                    is_success = d[1]
                    self.logger.info("Return is_success {}".format(is_success))
            is_error = None
            return is_success, is_error
        except Exception as e:
            self.logger.error(" Error :--")
            self.logger.error(str(e))
            is_success = False
            is_error = str(e)
            return is_success, is_error

