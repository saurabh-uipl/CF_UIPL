import awswrangler as wr
import pandas as pd
from pyspark.sql.functions import input_file_name, current_timestamp
from pyspark.sql import DataFrame
from ..common_utilities.Common_utility import CommonUtility
from ..audit_utilities.audit_utility import AuditUtility
import logging
from ..src.etl_config import ETLConfig


def update_sql_query_with_datetime_values(job_dict, logger, sql_query_):
    try:
        startdatetime = "'" + job_dict["startdatetime"] + "'"
        sql_query_ = sql_query_.lstrip('(').rstrip('as t )')
        sql_query_ = sql_query_.format(startdatetime=startdatetime,
                                       enddatetime=job_dict["enddatetime"])

        logger.info(" updated sql_query_ for Full Load:{} ".format(sql_query_))
        return sql_query_
    except Exception as e:
        logger.error(str(e))


def update_sql_query_for_table_filter(job_dict, logger, sql_query_):
    try:
        sql_query_ = sql_query_.lstrip('(').rstrip('as t )')
        query_sufix = f" and concat(bucket,'/',key) like ('%{job_dict['table_name']}%')"
        sql_query_ = sql_query_ + query_sufix
        logger.info(" updated sql_query_ for incremental/merge:{}".format(sql_query_))
        return sql_query_
    except Exception as e:
        logger.error(str(e))


def perform_auditing_tasks(job_dict, logger, etl_config, df):
    try:
        records_count = df.count()
        logger.info("records_count: {}".format(records_count))
        job_dict["individual_records_count"] = records_count
        job_dict["records_count"] = job_dict["individual_records_count"] + job_dict[
            "records_count"]
        if job_dict["load_type"] == "incremental" or job_dict["load_type"] == "merge":
            if records_count > 0:
                incremental_column = job_dict["incremental_column"]
                df_max_value = job_dict["max_last_modified_date"]
                str_df_max_value = "'" + str(df_max_value) + "'"
                job_dict["df_max_value"] = str_df_max_value
            elif job_dict["incremental_value"] == 'nan' or job_dict[
                "incremental_value"] == "None" or \
                    job_dict[
                        "incremental_value"] == "<NA>":
                job_dict["df_max_value"] = "'" + job_dict["max_last_modified_date"] + "'"
            else:
                offset_value_old = int(float(job_dict["incremental_value"]))
                job_dict["df_max_value"] = "'" + str(offset_value_old) + "'"
        '''
                        audit_entry_iceberg_obj = AuditUtility(self.job_dict, self.etl_config)
                        ### this needs to be changed

                        d, success = audit_entry_iceberg_obj.audit_entry_iceberg()
                        self.logger.info(" Display d: {}".format(d))

                        is_success = d[1]
                        self.logger.info(" is_success************* {}".format(is_success))
                        '''
        if len(job_dict['redshiftConnDetails']) != 0:
            logger.info("audit entry call to Redshift ...........")

            audit_utility_obj = AuditUtility(job_dict, etl_config)
            d, success = audit_utility_obj.audit_entry()
            is_success = d[1]
        else:
            logger.info("Write Execution detail in Audit Table in Iceberg ......")

            audit_utils = AuditUtility(job_dict, etl_config)

            iceberg_insert_audit_res = audit_utils.audit_entry_iceberg()
            logger.info(" iceberg_insert_audit_res: ***** {}".format(iceberg_insert_audit_res))

            is_success = iceberg_insert_audit_res[1]
    except Exception as e:
        logger.error(str(e))


def write_dataframes_to_s3_based_on_load_type(job_dict, logger, chunk_flag, df, df_final, spark):
    try:
        if job_dict["load_type"] == "incremental" and (
                job_dict["incremental_value"] != "" or job_dict["incremental_value"] != 'nan'):
            logger.info(
                "*****Writing to S3 : bucket_name {} source {} JOBNAME {} table_name {}".format(
                    job_dict["bucket_name"], job_dict["source"], str(job_dict["JOBNAME"]),
                    job_dict["table_name"]))
            df_final.coalesce(5).write.mode("append").parquet(
                "s3://" + job_dict["bucket_name"] + "/" + job_dict["source"] + "/" + str(
                    job_dict["JOBNAME"]) + "/" + job_dict["table_name"] + "/")
        else:
            if df.count() > 0:
                if job_dict["load_type"] == "merge":
                    df_final.persist()

                    logger.info(
                        "*****Writing to S3 : bucket_name {} source {} JOBNAME {} table_name {}".format(
                            job_dict["bucket_name"], job_dict["source"],
                            str(job_dict["JOBNAME"]),
                            job_dict["table_name"]))

                    spark.conf.set("spark.sql.sources.partitionOverwriteMode", "static")
                    df_final.write.mode("overwrite").parquet(
                        "s3://" + job_dict["bucket_name"] + "/" + job_dict["source"] + "/" + str(
                            job_dict["JOBNAME"]) + "/" + job_dict["table_name"] + "/")

                    df_final.unpersist()
                else:
                    logger.info("Start Writing FULL LOAD in S3")

                    if chunk_flag == 0:
                        df_final.persist()
                        spark.conf.set("spark.sql.sources.partitionOverwriteMode", "static")
                        df_final.write.mode("overwrite").parquet(
                            "s3://" + job_dict["bucket_name"] + "/" + job_dict[
                                "source"] + "/" + str(
                                job_dict["JOBNAME"]) + "/" + job_dict["table_name"] + "/")
                        chunk_flag = 1
                        df_final.unpersist()
                    else:
                        df_final.write.mode("append").parquet(
                            "s3://" + job_dict["bucket_name"] + "/" + job_dict[
                                "source"] + "/" + str(
                                job_dict["JOBNAME"]) + "/" + job_dict["table_name"] + "/")
            else:
                logger.info("Table is already updated")
    except Exception as e:
        logger.error(str(e))


def write_dataframes_to_s3(job_dict, logger, chunk_flag, df, df_final, spark):
    try:
        partition_step = job_dict["Partition_Column_new"]
        logger.info(
            "*****Writing to S3 : bucket_name {} source {} JOBNAME {} table_name {}".format(
                job_dict["bucket_name"], job_dict["source"], str(job_dict["JOBNAME"]),
                job_dict["table_name"]))
        logger.info(" incremental value: ")
        logger.info('{}'.format(job_dict["incremental_value"]))
        if job_dict["load_type"] == "incremental" and (
                job_dict["incremental_value"] != "" or job_dict["incremental_value"] != 'nan'):

            logger.info(
                "*****Writing to S3 : bucket_name {} source {} JOBNAME {} table_name {}".format(
                    job_dict["bucket_name"], job_dict["source"], str(job_dict["JOBNAME"]),
                    job_dict["table_name"]))

            logger.info(" Writing the data into S3 .....")

            df_final.coalesce(5).write.mode("append").partitionBy(partition_step).parquet(
                "s3://" + job_dict["bucket_name"] + "/" + job_dict["source"] + "/" + str(
                    job_dict["JOBNAME"]) + "/" + job_dict["table_name"] + "/")
        else:
            if df.count() > 0:
                if job_dict["load_type"] == "merge":
                    df_final.persist()

                    logger.info(
                        "*****Writing to S3 : bucket_name {} source {} JOBNAME {} table_name {}".format(
                            job_dict["bucket_name"], job_dict["source"],
                            str(job_dict["JOBNAME"]),
                            job_dict["table_name"]))

                    ###############################Need To check
                    # spark.conf.set("spark.sql.sources.partitionOverwriteMode", "static")
                    df_final.write.mode("overwrite").partitionBy(partition_step).parquet(
                        "s3://" + job_dict["bucket_name"] + "/" + job_dict["source"] + "/" + str(
                            job_dict["JOBNAME"]) + "/" + job_dict["table_name"] + "/")

                    df_final.unpersist()
                else:
                    logger.info("Start Writing FULL LOAD in S3")

                    if chunk_flag == 0:
                        df_final.persist()
                        spark.conf.set("spark.sql.sources.partitionOverwriteMode", "static")
                        df_final.write.mode("overwrite").partitionBy(partition_step).parquet(
                            "s3://" + job_dict["bucket_name"] + "/" + job_dict[
                                "source"] + "/" + str(
                                job_dict["JOBNAME"]) + "/" + job_dict["table_name"] + "/")
                        chunk_flag = 1
                        df_final.unpersist()
                    else:
                        df_final.write.mode("append").partitionBy(partition_step).parquet(
                            "s3://" + job_dict["bucket_name"] + "/" + job_dict[
                                "source"] + "/" + str(
                                job_dict["JOBNAME"]) + "/" + job_dict["table_name"] + "/")
            else:
                logger.info("Table is already updated")
    except Exception as e:
        logger.error(str(e))


def process_and_persist_dataframe(job_dict, logger, df):
    try:
        Partition_Column = job_dict["Partition_Column"]
        if 'None' in Partition_Column: Partition_Column.remove('None')
        if '<NA>' in Partition_Column: Partition_Column.remove('<NA>')
        logger.info("Partition_Column: {}".format(Partition_Column))
        job_dict["Partition_Column"] = Partition_Column
        df.persist()
        df_final = df
        logger.info(" Display df final .....")
        return df_final
    except Exception as e:
        logger.error(str(e))


def deduplicate_with_s3_data(job_dict, logger, df, spark):
    try:
        directory_name = job_dict["source"] + "/" + job_dict["JOBNAME"] + "/" + job_dict[
            "table_name"] + "/"
        d = CommonUtility.check_s3_path(job_dict["bucket_name"], directory_name)
        exists = d[1]
        if exists > 0:
            s3_file_path = "s3://" + job_dict["bucket_name"] + "/" + job_dict[
                "source"] + "/" + \
                           job_dict[
                               "JOBNAME"] + "/" + job_dict["table_name"] + "/"

            df_s3 = spark.read.parquet(s3_file_path)
            df_s3.createOrReplaceTempView("base")

            deltaDF = df.select(df_s3.columns)
            deltaDF.createOrReplaceTempView("delta")
            # logger.info(" Display job_dict:-----")
            # logger.info(job_dict)
            dedup_sql_query = ''' 
                                select /*+ BROADCAST(delta) */ base.* from base LEFT OUTER JOIN delta ON base.{PK_COL} = delta.{PK_COL} where delta.{PK_COL} IS NULL
                                '''
            logger.info(" dedup_sql_query: ")
            logger.info(dedup_sql_query)
            dedup_sql_query = dedup_sql_query.format(PK_COL=job_dict["pk_column"])
            logger.info("Updated dedup_sql_query:--")
            logger.info(dedup_sql_query)
            '''
            df_final = spark.sql(
                f'select /*+ BROADCAST(delta) */ base.* from base LEFT OUTER JOIN delta ON base.'
                f'{job_dict["pk_column"]} = delta.{job_dict["pk_column"]}'
                f' where delta.{job_dict["pk_column"]} IS NULL')
            '''
            df_final = spark.sql(dedup_sql_query)
            df_final = df_final.drop('row_num')
            df_final = df_final.union(deltaDF)

        else:
            df_final = df
        return df_final
    except Exception as e:
        logger.error(str(e))


def compare_and_merge_dataframes(job_dict, logger, df, spark):
    try:
        first_Parttion = str(job_dict["Partition_Column"][0])
        latest_Parttion_s3 = first_Parttion + "=" + job_dict["Partition_Year"]
        directory_name = job_dict["source"] + "/" + job_dict["JOBNAME"] + "/" + job_dict[
            "table_name"] + "/" + latest_Parttion_s3 + "/"
        d = CommonUtility.check_s3_path(job_dict["bucket_name"], directory_name)
        exists = d[1]
        if exists > 0:
            df_s3 = spark.read.parquet(
                "s3://" + job_dict["bucket_name"] + "/" + job_dict["source"] + "/" +
                job_dict[
                    "JOBNAME"] + "/" + job_dict["table_name"] + "/" + latest_Parttion_s3 + "/")
            df_s3.createOrReplaceTempView(job_dict["table_name"])
            sql_query_s3 = "select *," + "'" + job_dict[
                "Partition_Year"] + "'" + " AS " + first_Parttion + " from " + job_dict[
                               "table_name"]

            df_s3 = spark.sql(sql_query_s3)
            df_s3.createOrReplaceTempView("base")

            deltaDF = df.select(df_s3.columns)
            deltaDF.createOrReplaceTempView("delta")

            df_final = spark.sql(
                f'select /*+ BROADCAST(delta) */ base.* from base LEFT OUTER JOIN delta ON base.'
                f'{job_dict["pk_column"]} = delta.{job_dict["pk_column"]} '
                f'where delta.{job_dict["pk_column"]} IS NULL')

            df_final = df_final.drop('row_num')
            df_final = df_final.union(deltaDF)

        else:
            df_final = df
        return df_final
    except Exception as e:
        logger.error(str(e))


def process_and_merge_json_data(job_dict, logger, data_chunk, df_1, source, spark, etl_config: ETLConfig):
    try:
        json_df = spark.read.option("multiline", "true").format(source).load(data_chunk)

        json_df = spark.read.format(source).load(data_chunk)
        df = CommonUtility.json_flatten(json_df)
        spark.conf.set('spark.sql.session.timeZone', etl_config.timezone_param)
        df = df.withColumn('file_name', input_file_name()).withColumn('pulled_time',
                                                                      current_timestamp()).withColumn(
            'update_time', current_timestamp())
        df.createOrReplaceTempView('table')
        df = spark.sql(job_dict["merge_query"])
        df = df.join(df_1, df.file_name == df_1.path, "inner")
        return df
    except Exception as e:
        logger.error(str(e))


def merge_data(job_dict, logger, data_chunk, df_1, source, spark):
    try:
        df = spark.read.format(source).load(data_chunk)
        df = df.withColumn('file_name', input_file_name()).withColumn('pulled_time',
                                                                      current_timestamp()).withColumn(
            'update_time', current_timestamp())
        df.createOrReplaceTempView('table')
        df = spark.sql(job_dict["merge_query"])
        df = df.join(df_1, df.file_name == df_1.path, "inner")
        return df
    except Exception as e:
        logger.error(str(e))


def process_and_merge_csv_data(job_dict, logger, data_chunk, df_1, schema_name, source, spark):
    try:
        logger.info(" Source is csv .......")
        logger.info(" Display df: ....")
        df = spark.read.format(source).load(data_chunk)
        df = df.where(~df['_c0'].isin(schema_name))
        logger.info(" filtered df: ")
        df = df.toDF(*schema_name)
        logger.info(" dipslay df.toDF(*schema_name) ")
        df = df.withColumn('file_name', input_file_name()).withColumn('pulled_time',
                                                                      current_timestamp()).withColumn(
            'update_time', current_timestamp())
        logger.info(" display df with columns")
        df.createOrReplaceTempView('table')
        df = spark.sql(job_dict["merge_query"])
        logger.info(" Display after merge query")
        df = df.join(df_1, df.file_name == df_1.path, "inner")
        logger.info(" Display Joined DF: ")
        return df

    except Exception as e:
        logger.error(str(e))
