# s3_data_ingestion_inventory/__init__.py

from .s3_dataIngestion_inventory import S3DataIngestionInventory
