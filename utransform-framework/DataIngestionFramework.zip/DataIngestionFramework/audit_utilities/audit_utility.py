import boto3
import json
import datetime
import pg8000 as dbapi
import pytz
import logging
from DataIngestionFramework.src.etl_config import ETLConfig
import time


class AuditUtility:
    def __init__(self, job_dict, etl_config: ETLConfig):

        self.etl_config = etl_config
        self.logger = logging.getLogger("my_logger")
        self.job_dict = job_dict
        '''
        Args:
        redshift_schema_name:
        redshift_audit_table_name:
        redshift_etl_master_table_name:
      
        job_dict:
        athena_db_name:     
        
        '''

    def audit_entry(self):
        """
        Returns:
            audit_dict:
        """

        try:
            success = True
            job_config_flag = 'FALSE'
            # self.logger.info("Executing Audit_Entry")

            # self.logger.info('Get Redshift Connection')

            conn = self.job_dict["conn_pg8000"]
            conn.autocommit = True
            final_time_stamp = datetime.datetime.now(pytz.timezone(self.etl_config.timezone_param))
            self.logger.info('final_time_stamp: {}'.format(str(final_time_stamp)))
            result_time_stamp = final_time_stamp - self.job_dict["initial_time_stamp"]

            # self.logger.info('result time_stamp:'.format(str(result_time_stamp)))

            current_time_stamp = str(datetime.datetime.now(pytz.timezone(self.etl_config.timezone_param)))[0:19]
            self.logger.info('current_time_stamp: {}'.format(str(current_time_stamp)))

            curr = conn.cursor()
            # self.logger.info('job_config_flag')

            if job_config_flag == 'TRUE':
                if 'table_status' in self.job_dict and 'table_error' in self.job_dict:
                    self.logger.info(" Write Error Details In Audit Table ")
                    value_type = [self.job_dict["JOBNAME"], self.job_dict["table_name"],
                                  str(current_time_stamp), 'Failed', self.job_dict['table_error']]
                    self.logger.info('value type: {}'.format(value_type))

                    query = "insert into {redshift_schema_name}.{redshift_audit_table_name}" \
                            "(glue_job_name,table_name," \
                            "insert_timestamp,status,exception_description) values(%s,%s, %s, %s, " \
                            "%s);"
                    query = query.format(redshift_schema_name=self.etl_config.redshift_schema_name,
                                         redshift_audit_table_name=self.etl_config.redshift_audit_table_name)
                    self.logger.info('{}'.format(query))
                else:
                    value_type = [self.job_dict["JOBNAME"], self.job_dict["table_name"], str(result_time_stamp),
                                  self.job_dict["records_count"],
                                  str(current_time_stamp), self.job_dict["status"], self.job_dict["exception_description"],
                                  self.job_dict["jobconfig"]]
                    self.logger.info('value type: {}'.format(value_type))

                    query = "insert into {redshift_schema_name}.{redshift_audit_table_name}" \
                            "(glue_job_name,table_name,job_runtime," \
                            "record_count,insert_timestamp,status,exception_description,jobconfig) values(%s,%s, %s, %s, " \
                            "%s,%s,%s,%s);"
                    query = query.format(redshift_schema_name=self.etl_config.redshift_schema_name,
                                         redshift_audit_table_name=self.etl_config.redshift_audit_table_name)
                    self.logger.info('{}'.format(query))
            else:
                if 'table_status' in self.job_dict and 'table_error' in self.job_dict:
                    self.logger.info(" Write Error In Audit Table ")
                    self.logger.info(" Write Error Details In Audit Table ")
                    value_type = [self.job_dict["JOBNAME"], self.job_dict["table_name"],
                                  str(current_time_stamp), 'Failed', self.job_dict['table_error']]
                    self.logger.info('value type: {}'.format(value_type))

                    query = "insert into {redshift_schema_name}.{redshift_audit_table_name}" \
                            "(glue_job_name,table_name," \
                            "insert_timestamp,status,exception_description) values(%s,%s, %s, %s, " \
                            "%s);"
                    query = query.format(redshift_schema_name=self.etl_config.redshift_schema_name,
                                         redshift_audit_table_name=self.etl_config.redshift_audit_table_name)
                    self.logger.info('{}'.format(query))
                else:
                    self.job_dict["jobconfig"] = ""
                    value_type = [self.job_dict["JOBNAME"], self.job_dict["table_name"], str(result_time_stamp),
                                  self.job_dict["records_count"],
                                  str(current_time_stamp), self.job_dict["status"], self.job_dict["exception_description"],
                                  self.job_dict["jobconfig"]]
                    self.logger.info('value type: {}'.format(value_type))
                    query = " insert into {redshift_schema_name}.{redshift_audit_table_name}" \
                            "(glue_job_name,table_name,job_runtime,record_count," \
                            "insert_timestamp,status,exception_description,jobconfig)" \
                            " values(%s,%s, %s, %s, %s,%s,%s,%s);".format(
                        redshift_schema_name=self.etl_config.redshift_schema_name,
                        redshift_audit_table_name=self.etl_config.redshift_audit_table_name)
                    self.logger.info('{}'.format(query))
            redshift_query_response = curr.execute(query, value_type)
            self.logger.info('Redshift Audit Query Response: {}'.format(redshift_query_response))
            conn.commit()

            self.logger.info(
                "*****Audit Entry added into the table for this job : {} ***********".format(self.job_dict["JOBNAME"]))
            audit_dict = {1: True}
            return audit_dict, success
        except Exception as e:
            self.logger.error("*****ERROR While Writing Data Into Audit Table***********")
            self.logger.error(str(e))
            audit_dict = {1: False}

            success = False

            return audit_dict, success

    def update_etl_master_entry(self):
        """
        Returns:
            audit_dict:
        """
        try:
            success = True
            self.logger.info("Executing Update_ETL_Master_Entry ")

            conn = dbapi.connect(database=str(self.job_dict["redshiftConnDetails"]['database']),
                                 host=str(self.job_dict["redshiftConnDetails"]['host']),
                                 port=int(self.job_dict["redshiftConnDetails"]['port']),
                                 user=str(self.job_dict["redshiftConnDetails"]['user']),
                                 password=str(self.job_dict["redshiftConnDetails"]['password']))
            conn.autocommit = True
            curr = conn.cursor()

            if self.job_dict["load_type"] in ["incremental", "merge"]:

                if self.job_dict["incremental_value"] in ["None", 'nan']:

                    update_query = "update {redshift_schema_name}.{redshift_etl_master_table_name} set startdatetime = " + \
                                   self.job_dict[
                                       "df_max_value"] + ", enddatetime = NULL where tablename = " + "'" + \
                                   self.job_dict[
                                       "table_name"] + "' and id = " + str(self.job_dict["id"])
                    update_query = update_query.format(redshift_schema_name=self.etl_config.redshift_schema_name,
                                                       redshift_etl_master_table_name=self.etl_config.
                                                       redshift_etl_master_table_name)
                    self.logger.info('update_query: {}'.format(update_query))
                    response_update = curr.execute(update_query)
                    self.logger.info(" Update Query On Redshift Executed  Successfully ")
                    conn.commit()
                    self.logger.info("*****response_update {} ***********".format(response_update))
                else:

                    update_query = "update {redshift_schema_name}.{redshift_etl_master_table_name} set offset_value = " + \
                                   self.job_dict[
                                       "df_max_value"] + ", enddatetime = NULL where tablename = " + "'" + \
                                   self.job_dict[
                                       "table_name"] + "' and id = " + str(self.job_dict["id"])
                    update_query = update_query.format(redshift_schema_name=self.etl_config.redshift_schema_name,
                                                       redshift_etl_master_table_name=self.etl_config.
                                                       redshift_etl_master_table_name)
                    self.logger.info('update_query for Etl Master : {}'.format(update_query))
                    response_update = curr.execute(update_query)
                    self.logger.info(" Update Query On Redshift Executed  Successfully ")
                    conn.commit()
                    self.logger.info("*****response_update {} ***********".format(response_update))
            conn.commit()

            self.logger.info(
                "*****Audit Entry added into the table for this job : {} ***********".format(self.job_dict["JOBNAME"]))
            audit_dict = {1: True}
            return audit_dict, success
        except Exception as e:

            self.logger.error("ERROR Retrieving Secret Key ")
            self.logger.error(str(e))
            audit_dict = {1: False}

            success = False
            return audit_dict, success

    def audit_table_iceberg_query_response(self, insert_query, bucket_name):
        """
        Returns:
            response:
        """

        self.logger.info('Executing audit_table_iceberg_query_response')
        self.logger.info("Writing data in Audit Table in "+str(self.etl_config.iceberg_db))
        self.logger.info("Temp path For Iceberg Query result is : "+str(bucket_name))
        client = boto3.client('athena')
        athena_query_response = client.start_query_execution(QueryString=insert_query,
                                                             QueryExecutionContext={
                                                                 'Database': self.etl_config.iceberg_db
                                                             },
                                                             ResultConfiguration={
                                                                 'OutputLocation': bucket_name}
                                                             )

        self.logger.info("*****response {} ***********".format(athena_query_response))
        return athena_query_response



    def audit_entry_iceberg(self):
        """
        Returns:
            audit_dict:

        """

        try:
            success = True
            # self.logger.info("Executing audit_entry_iceberg")
            job_config_flag = 'FALSE'
            client = boto3.client('athena')
            listOfStatus = ['SUCCEEDED', 'FAILED', 'CANCELLED']
            listOfInitialStatus = ['RUNNING', 'QUEUED']

            self.logger.info("*****Audit_Entry ***********")
            final_time_stamp = datetime.datetime.now(pytz.timezone(self.etl_config.timezone_param))
            result_time_stamp = final_time_stamp - self.job_dict["initial_time_stamp"]
            current_time_stamp = str(datetime.datetime.now(pytz.timezone(self.etl_config.timezone_param)))[0:19]
            self.logger.info('{}'.format(job_config_flag))
            self.logger.info('updated job_dict')

            response = {}
            self.job_dict["jobconfig"] = ''
            if self.job_dict["inventory"] == 'NA' and self.job_dict["chunk_size"] == 'NA':
                self.logger.info('inventory = NA and  chunk_size = NA')
                last_modified_date_s3 = ""
                file_name_s3 = ""
                if 'table_status' in self.job_dict and 'table_error' in self.job_dict:
                    self.logger.info(" Add an entry to Iceberg audit table ....")
                    status = 'Failed'
                    insert_query = '''insert into {}.{}(glue_job_name,table_name,load_type,business_unit,
                                        insert_timestamp,status,exception_description) 
                                        values({}, {}, {}, {},{},{},{} ) '''

                    insert_query = insert_query.format(self.etl_config.iceberg_db, self.etl_config.iceberg_audit_table_name,
                                                       "'" + self.job_dict["JOBNAME"] + "'",
                                                       "'" + self.job_dict["table_name"] + "'",
                                                       "'" + self.job_dict["load_type"] + "'",
                                                       "'" + self.job_dict["business_unit"] + "'",
                                                       "'" + str(current_time_stamp) + "'",
                                                       "'" + str(status) + "'",
                                                       "'" + self.job_dict["table_error"] + "'")

                    self.logger.info("*****Audit Entry insert query : {} ***********".format(insert_query))

                    bucket_name = self.job_dict['bucket_name']
                    temp_bucket_path = self.etl_config.rs_temp_bucket_uri
                    response = self.audit_table_iceberg_query_response(insert_query, temp_bucket_path)
                    self.logger.info('audit query response : {}'.format(response))

                else:
                    self.logger.info(" Audit Insert Query: ...")
                    insert_query = '''insert into {}.{}(glue_job_name,table_name,business_unit,job_runtime,
                    record_count,load_type,insert_timestamp,status,exception_description,jobconfig,inventory_last_modified_date,file_name) 
                    values({}, {}, {}, {},{},{},{},{},{},{},{},{} ) '''
                    logging.info(insert_query)
                    self.logger.info("table_name: " + self.job_dict["table_name"])
                    table_name_last_char = self.job_dict["table_name"][len(self.job_dict["table_name"]) - 1]
                    self.logger.info("table_name_last_char: "+str(table_name_last_char))
                    if table_name_last_char == '/':
                        updated_table_name = self.job_dict["table_name"].split('/')[-2]
                    else:
                        updated_table_name = self.job_dict["table_name"].split('/')[-1]
                    self.logger.info(" updated_table_name: " + str(updated_table_name))
                    insert_query = insert_query.format(self.etl_config.iceberg_db, self.etl_config.iceberg_audit_table_name,
                                                       "'" + self.job_dict["JOBNAME"] + "'",
                                                       "'" + updated_table_name + "'",
                                                       "'" + self.job_dict["business_unit"] + "'",
                                                       "'" + str(result_time_stamp) + "'",
                                                       self.job_dict["records_count"],
                                                       "'" + self.job_dict["load_type"] + "'",
                                                       "'" + str(current_time_stamp) + "'",
                                                       "'" + self.job_dict["status"] + "'",
                                                       "'" + self.job_dict["exception_description"] + "'",
                                                       "'" + str(self.job_dict["jobconfig"]).replace("'", "''").replace('[',
                                                                                                                        '').replace(
                                                           ']',
                                                           '') + "'",
                                                       "'" + last_modified_date_s3 + "'",
                                                       "'" + file_name_s3 + "'")
                    logging.info("Updated insert_query: ")
                    logging.info(insert_query)

                    self.logger.info("*****Audit Entry insert query : {} ***********".format(insert_query))

                    # bucket_name = self.job_dict['bucket_name']
                    temp_bucket_path = self.etl_config.rs_temp_bucket_uri

                    response = self.audit_table_iceberg_query_response(insert_query, temp_bucket_path)
                    self.logger.info('audit query response : {}'.format(response))

            else:
                if 'table_status' in self.job_dict and 'table_error' in self.job_dict:
                    self.logger.info(" Write Failed Table Details in Audit Table ....")
                    status = 'Failed'
                    insert_query = '''insert into {}.{}(glue_job_name,table_name,business_unit,
                                                                                    insert_timestamp,status,exception_description
                                                                                    ) values({}, {}, {}, {},{},{} ) '''
                    self.logger.info('query: {}'.format(insert_query))
                    insert_query = insert_query.format(self.etl_config.iceberg_db, self.etl_config.
                                                       iceberg_audit_table_name,
                                                       "'" + self.job_dict["JOBNAME"] + "'",
                                                       "'" + self.job_dict["table_name"] + "'",
                                                       "'" + self.job_dict["business_unit"] + "'",
                                                       "'" + str(current_time_stamp) + "'",
                                                       "'" + str(status) + "'",
                                                       "'" + self.job_dict["table_error"] + "'")
                    self.logger.info('formatted query: {}'.format(insert_query))

                    self.logger.info(
                        "*****Audit Entry insert statement : {} ***********".format(insert_query))

                    bucket_name = self.job_dict['bucket_name']
                    response = self.audit_table_iceberg_query_response(insert_query, bucket_name)
                    self.logger.info('{}'.format(response))
                else:
                    if self.job_dict["chunk_list_length"] > 0:
                        if len(self.job_dict["file_name_list"]) > 0:
                            self.logger.info('file_name_list is not empty ')
                            for i in range(len(self.job_dict["file_name_list"])):
                                file_name_s3 = self.job_dict["file_name_list"][i]
                                records_count_s3 = self.job_dict["df_count_list"][i]
                                last_modified_date_s3 = self.job_dict["last_modified_date"][i]

                                insert_query = '''insert into {}.{}(glue_job_name,table_name,business_unit.
                                job_runtime,record_count,insert_timestamp,status,exception_description,
                                jobconfig,inventory_last_modified_date,file_name) values({}, {}, {}, {},{},{},{},{},{},{}, {} ) '''
                                self.logger.info('query: {}'.format(insert_query))
                                insert_query = insert_query.format(self.etl_config.iceberg_db, self.etl_config.
                                                                   iceberg_audit_table_name,
                                                                   "'" + self.job_dict["JOBNAME"] + "'",
                                                                   "'" + self.job_dict["table_name"] + "'",
                                                                   "'" + self.job_dict["business_unit"] + "'",
                                                                   "'" + str(result_time_stamp) + "'", records_count_s3,
                                                                   "'" + str(current_time_stamp) + "'",
                                                                   "'" + self.job_dict["status"] + "'",
                                                                   "'" + self.job_dict["exception_description"] + "'",
                                                                   "'" + str(self.job_dict["jobconfig"]).replace("'",
                                                                                                                 "''").replace(
                                                                       '[', '').replace(']',
                                                                                        '') + "'",
                                                                   "'" + last_modified_date_s3 + "'",
                                                                   "'" + file_name_s3 + "'")
                                self.logger.info('formatted query: {}'.format(insert_query))

                                self.logger.info(
                                    "*****Audit Entry insert statement : {} ***********".format(insert_query))

                                bucket_name = self.job_dict['bucket_name']
                                response = self.audit_table_iceberg_query_response(insert_query, bucket_name)
                                self.logger.info('{}'.format(response))
                        else:
                            self.logger.info('file list is not empty')
                            response = None
                    else:
                        last_modified_date_s3 = ''
                        file_name_s3 = ''
                        records_count_s3 = 0
                        if 'table_status' in self.job_dict and 'table_error' in self.job_dict:
                            self.logger.info(" Writing Failed Table  Details in Audit Table ....")
                            status = 'Failed'
                            insert_query = '''insert into {}.{}(glue_job_name,table_name,business_unit,
                                                    insert_timestamp,status,exception_description
                                                    ) values( {}, {}, {}, {},{},{} ) '''

                            self.logger.info('{}'.format(insert_query))
                            insert_query = insert_query.format(self.etl_config.iceberg_db, self.etl_config.
                                                               iceberg_audit_table_name,
                                                               "'" + self.job_dict["JOBNAME"] + "'",
                                                               "'" + self.job_dict["table_name"] + "'",
                                                               "'" + self.job_dict["business_unit"] + "'",
                                                               "'" + str(current_time_stamp) + "'",
                                                               "'" + str(status) + "'",
                                                               "'" + self.job_dict["table_error"] + "'")

                            self.logger.info(
                                "*****Audit Entry insert statement : {} ***********".format(insert_query))

                            bucket_name = self.job_dict['bucket_name']
                            response = self.audit_table_iceberg_query_response(insert_query, bucket_name)
                            self.logger.info(" Response of Audit Query Run: {} ".format(response))

                        else:
                            insert_query = '''insert into {}.{}(glue_job_name,table_name,business_unit,
                            job_runtime,record_count,insert_timestamp,status,exception_description,
                            jobconfig,inventory_last_modified_date,file_name) values( {}, {}, {}, {},{},{},{},{},{},{} ) '''

                            self.logger.info('{}'.format(insert_query))
                            insert_query = insert_query.format(self.etl_config.iceberg_db, self.etl_config.
                                                               iceberg_audit_table_name,
                                                               "'" + self.job_dict["JOBNAME"] + "'",
                                                               "'" + self.job_dict["table_name"] + "'",
                                                               "'" + self.job_dict["business_unit"] + "'",
                                                               "'" + str(result_time_stamp) + "'", records_count_s3,
                                                               "'" + str(current_time_stamp) + "'",
                                                               "'" + self.job_dict["status"] + "'",
                                                               "'" + self.job_dict["exception_description"] + "'",
                                                               "'" + str(self.job_dict["jobconfig"]).replace("'", "''").replace(
                                                                   '[', '').replace(']',
                                                                                    '') + "'",
                                                               "'" + last_modified_date_s3 + "'", "'" + file_name_s3 + "'")

                            self.logger.info(
                                "*****Audit Entry insert statement : {} ***********".format(insert_query))

                            bucket_name = self.job_dict['bucket_name']
                            response = self.audit_table_iceberg_query_response(insert_query, bucket_name)
                            self.logger.info(" Response of Audit Query Run: {} ".format(response))

            queryExecutionId = response['QueryExecutionId']

            status = client.get_query_execution(QueryExecutionId=queryExecutionId)['QueryExecution']['Status'][
                'State']
            num_of_executions = 0
            while status in listOfInitialStatus:
                if num_of_executions >= 5:
                    break
                status = \
                    client.get_query_execution(QueryExecutionId=queryExecutionId)['QueryExecution']['Status'][
                        'State']
                if status in listOfStatus:
                    num_of_executions = num_of_executions + 1
                    if status == 'SUCCEEDED':
                        self.logger.info('Query Succeeded! 1')
                        self.logger.info(" calling get_paginator ....")
                        paginator = client.get_paginator('get_query_results')
                        self.logger.info(" calling paginate ...")
                        query_results = paginator.paginate(
                            QueryExecutionId=queryExecutionId,
                            PaginationConfig={'PageSize': 1000}
                        )
                        self.logger.info("query_results : {}".format(query_results))
                        break
                    elif status == 'FAILED':

                        response = self.audit_table_iceberg_query_response(insert_query, bucket_name)
                        queryExecutionId = response['QueryExecutionId']
                        status = \
                            client.get_query_execution(QueryExecutionId=queryExecutionId)['QueryExecution'][
                                'Status']['State']
                    elif status == 'CANCELLED':

                        response = self.audit_table_iceberg_query_response(insert_query, bucket_name)
                        queryExecutionId = response['QueryExecutionId']
                        status = \
                            client.get_query_execution(QueryExecutionId=queryExecutionId)['QueryExecution'][
                                'Status']['State']

            results = []
            rows = []

            audit_dict = {1: True}
            return audit_dict, success
        except Exception as e:
            self.logger.error("*****ERROR ********")
            self.logger.error(str(e))
            audit_dict = {1: False}
            self.logger.error(" Exception :")
            self.logger.error(str(e))

            success = False
            return audit_dict, success

    def Update_Entry_Iceberg_Query_Response(self, update_query, bucket_name):
        """
        Returns:
            response:
        """
        self.logger.info('Executing update_entry_iceberg_query_response')
        self.logger.info("update_query: ")
        self.logger.info(update_query)
        client = boto3.client('athena')
        self.logger.info("Updating ETL MASTER table In "+str(self.etl_config.iceberg_db))
        self.logger.info("Temp Path Specified for Iceberg Query Results is : "+str(bucket_name))

        response = client.start_query_execution(QueryString=update_query,
                                                QueryExecutionContext={
                                                    'Database': self.etl_config.iceberg_db
                                                },
                                                ResultConfiguration={
                                                    'OutputLocation': bucket_name}
                                                )
        self.logger.info("*****response_update {} ***********".format(response))
        return response

    def Update_ETL_Master_Entry_Iceberg(self):
        """
        Returns:
            audit_dict:
        """
        try:
            success = True
            client = boto3.client('athena')
            listOfStatus = ['SUCCEEDED', 'FAILED', 'CANCELLED']
            listOfInitialStatus = ['RUNNING', 'QUEUED']

            self.logger.info("*****ETL_Master_Entry_Iceberg ***********")

            if self.job_dict["load_type"] in ["incremental", "merge"]:

                if self.job_dict["incremental_value"] in ["None", 'nan', '<NA>']:
                    if self.job_dict["inventory"] == 'NA' and self.job_dict["chunk_size"] == 'NA' and 's3_' not in \
                            self.job_dict["source"]:

                        update_query = "update {iceberg_db}.{iceberg_etl_master_table_name}" \
                                       " set startdatetime = timestamp " + \
                                       self.job_dict[
                                           "df_max_value"] + ", enddatetime = NULL where tablename = " + "'" + \
                                       self.job_dict[
                                           "table_name"] + "' and id = " + self.job_dict["id"]

                        update_query = update_query.format(iceberg_db=self.etl_config.iceberg_db,
                                                           iceberg_etl_master_table_name=self.etl_config.
                                                           iceberg_etl_master_table_name)
                        self.logger.info(" update_query: ************* : {} ".format(update_query))

                    else:
                        update_query = "update {iceberg_db}." \
                                       "{iceberg_etl_master_table_name} set startdatetime = timestamp " + \
                                       self.job_dict[
                                           "df_max_value"] + ", enddatetime = NULL where tablename = " + "'" + \
                                       self.job_dict[
                                           "inventory_table_name"] + "' and id = " + self.job_dict["id"]

                        update_query = update_query.format(iceberg_db=self.etl_config.iceberg_db,
                                                           iceberg_etl_master_table_name=self.etl_config.
                                                           iceberg_etl_master_table_name)

                        self.logger.info(" ***update_query: *** : {}".format(update_query))

                    self.logger.info(
                        "*****ETL_Master_Entry_Iceberg update statement : {} ***********".format(update_query))

                    bucket_name = self.job_dict['bucket_name']
                    temp_bucket_path = self.etl_config.rs_temp_bucket_uri

                    response = self.Update_Entry_Iceberg_Query_Response(update_query, temp_bucket_path)
                    self.logger.info(" ETL Master Update Table Response: {}".format(response))

                    queryExecutionId = response['QueryExecutionId']

                    self.logger.info(client.get_query_execution(QueryExecutionId=queryExecutionId))

                    status = client.get_query_execution(QueryExecutionId=queryExecutionId)['QueryExecution']['Status'][
                        'State']
                    no_of_failed_executions = 0
                    while status in listOfInitialStatus:
                        if no_of_failed_executions < 10:
                            time.sleep(10)
                            status = \
                                client.get_query_execution(QueryExecutionId=queryExecutionId)['QueryExecution'][
                                    'Status'][
                                    'State']
                            if status in listOfStatus:
                                if status == 'SUCCEEDED':

                                    paginator = client.get_paginator('get_query_results')
                                    query_results = paginator.paginate(
                                        QueryExecutionId=queryExecutionId,
                                        PaginationConfig={'PageSize': 1000}
                                    )
                                    break
                                elif status == 'FAILED':
                                    self.logger.info('Query Failed!')
                                    self.logger.info('Retrying again')
                                    response = self.Update_Entry_Iceberg_Query_Response(update_query, bucket_name)
                                    queryExecutionId = response['QueryExecutionId']
                                    status = \
                                        client.get_query_execution(QueryExecutionId=queryExecutionId)['QueryExecution'][
                                            'Status']['State']
                                    no_of_failed_executions = no_of_failed_executions + 1
                                elif status == 'CANCELLED':
                                    self.logger.info('Query Cancelled!')
                                    self.logger.info('Retrying again')
                                    response = self.Update_Entry_Iceberg_Query_Response(update_query, bucket_name)
                                    queryExecutionId = response['QueryExecutionId']
                                    status = \
                                        client.get_query_execution(QueryExecutionId=queryExecutionId)['QueryExecution'][
                                            'Status']['State']
                                    no_of_failed_executions = no_of_failed_executions + 1
                        else:
                            self.logger.info(
                                " No Of Retries Exceeded to Threshold i.e. 10 , cancelling the Athena Query Update..")
                            break
                    results = []
                    rows = []

                else:
                    if self.job_dict["inventory"] == 'NA' and self.job_dict["chunk_size"] == 'NA':
                        update_query = "update {iceberg_db}." \
                                       "{iceberg_etl_master_table_name} set offset_value = bigint " + \
                                       self.job_dict[
                                           "df_max_value"] + ", enddatetime = NULL where tablename = " + "'" + \
                                       self.job_dict[
                                           "table_name"] + "' and id = " + self.job_dict["id"]
                        update_query = update_query.format(iceberg_db=self.etl_config.iceberg_db,
                                                           iceberg_etl_master_table_name=self.
                                                           etl_config.iceberg_etl_master_table_name)
                        self.logger.info(" update_query: {}".format(update_query))

                    else:
                        update_query = "update {iceberg_db}." \
                                       "{iceberg_etl_master_table_name} set offset_value = bigint " + \
                                       self.job_dict[
                                           "df_max_value"] + ", enddatetime = NULL where tablename = " + "'" + \
                                       self.job_dict[
                                           "inventory_table_name"] + "' and id = " + self.job_dict["id"]
                        update_query = update_query.format(iceberg_db=self.etl_config.iceberg_db,
                                                           iceberg_etl_master_table_name=self.etl_config.
                                                           iceberg_etl_master_table_name)
                        self.logger.info(" ::: ****update_query: {}".format(update_query))

                    self.logger.info(
                        "*****ETL_Master_Entry_Iceberg update statement : {} ***********".format(update_query))
                    response = client.start_query_execution(QueryString=update_query,
                                                            QueryExecutionContext={
                                                                'Database': '{iceberg_db}'.format(
                                                                    iceberg_db=self.etl_config.iceberg_db, )
                                                            },
                                                            ResultConfiguration={
                                                                'OutputLocation': 's3://{bucket_name}/iceberg/'
                                                                                  '{iceberg_etl_master}'.format(
                                                                    bucket_name=self.job_dict['bucket_name'],
                                                                    iceberg_etl_master=self.etl_config.
                                                                    iceberg_etl_master_table_name
                                                                )

                                                            }
                                                            )
                    self.logger.info("*****response_update {} ***********".format(response))

                    queryExecutionId = response['QueryExecutionId']

                    status = client.get_query_execution(QueryExecutionId=queryExecutionId)['QueryExecution']['Status'][
                        'State']
                    no_of_failed_executions = 0
                    while status in listOfInitialStatus:
                        if no_of_failed_executions < 10:
                            time.sleep(10)
                            status = \
                                client.get_query_execution(QueryExecutionId=queryExecutionId)['QueryExecution']['Status'][
                                    'State']
                            if status in listOfStatus:
                                if status == 'SUCCEEDED':

                                    paginator = client.get_paginator('get_query_results')
                                    query_results = paginator.paginate(
                                        QueryExecutionId=queryExecutionId,
                                        PaginationConfig={'PageSize': 1000}
                                    )
                                    break
                                elif status == 'FAILED':
                                    self.logger.info('Query Failed!!!!')
                                    self.logger.info("Re-Run The Query .....")

                                    response = client.start_query_execution(QueryString=update_query,
                                                                            QueryExecutionContext={
                                                                                'Database': '{iceberg_db}'.format(
                                                                                    iceberg_db=self.etl_config.iceberg_db, )
                                                                            },
                                                                            ResultConfiguration={
                                                                                'OutputLocation': 's3://{bucket_name}/iceberg/'
                                                                                                  '{iceberg_etl_master}'.format(
                                                                                    bucket_name=self.job_dict['bucket_name'],
                                                                                    iceberg_etl_master=self.etl_config.
                                                                                    iceberg_etl_master_table_name
                                                                                )

                                                                            }
                                                                            )

                                    queryExecutionId = response['QueryExecutionId']

                                    status = client.get_query_execution(QueryExecutionId=queryExecutionId)['QueryExecution']['Status'][
                                        'State']

                                    no_of_failed_executions = no_of_failed_executions + 1
                                elif status == 'CANCELLED':
                                    self.logger.info('Query Cancelled!')
                                    self.logger.info(" Re-Run the query ........")

                                    response = client.start_query_execution(QueryString=update_query,
                                                                            QueryExecutionContext={
                                                                                'Database': '{iceberg_db}'.format(
                                                                                    iceberg_db=self.etl_config.iceberg_db, )
                                                                            },
                                                                            ResultConfiguration={
                                                                                'OutputLocation': 's3://{bucket_name}/iceberg/'
                                                                                                  '{iceberg_etl_master}'.format(
                                                                                    bucket_name=self.job_dict['bucket_name'],
                                                                                    iceberg_etl_master=self.etl_config.
                                                                                    iceberg_etl_master_table_name
                                                                                )

                                                                            }
                                                                            )

                                    queryExecutionId = response['QueryExecutionId']

                                    status = client.get_query_execution(QueryExecutionId=queryExecutionId)['QueryExecution']['Status'][
                                        'State']

                                    no_of_failed_executions = no_of_failed_executions + 1
                                break
                        else:
                            self.logger.info(
                                " No Of Retries Exceeded to Threshold i.e. 10 , cancelling the Athena Query Update..")
                            break
                    results = []
                    rows = []

                self.logger.info("*****response {} ***********".format(response))

            audit_dict = {1: True}
            self.logger.info(" return audit_dict : {}".format(audit_dict))

            return audit_dict, success
        except Exception as e:

            self.logger.error("*****ERROR ***********")
            self.logger.error(str(e))

            audit_dict = {1: False}

            success = False
            return audit_dict, success
