from pyspark.sql import DataFrame
from pyspark.rdd import RDD

def check_is_dataframe(df):
    if isinstance(df, RDD):
        return False
    if isinstance(df, DataFrame):
        return True
