import logging

logger = logging.getLogger('my_logger')


def create_partition_column(job_dict, incoming_source_df):
    """
    Args:
        incoming_source_df:
        job_dict:
        df:

    Returns:
        job_dict:
        df:

    """
    logger.info(" Executing create_partition_column ...")
    try:
        success = True
        if len(job_dict["Partition_Column"]) > 0:

            partition_column_new = job_dict["Partition_Column"]
            a = dict(incoming_source_df.dtypes)
            for k1 in job_dict["Partition_Column"]:
                k = k1.lower()
                column_type = [a[key] for key in a if key.lower() == k]

                if "timestamp" in column_type:
                    new_name = k1 + "_dt"
                    partition_column_new = [new_name if x == k1 else x for x in partition_column_new]

                    incoming_source_df = incoming_source_df.withColumn(new_name, incoming_source_df[k1].cast('date'))

            job_dict["Partition_Column_New"] = partition_column_new
        is_error = None
        return job_dict, incoming_source_df, success, is_error
    except Exception as e:
        logger.error(str(e))
        success = False
        is_error = str(e)
        return job_dict, incoming_source_df, success, is_error
