from ..audit_utilities.audit_utility import AuditUtility


def add_failed_table_entry(job_dict, etl_config, logger, is_error):
    logger.info("Executing  add_failed_table_entry ...")
    job_dict['table_status'] = 'FAIL'
    job_dict['table_error'] = str(is_error).replace("'", '').replace('`', '').replace('"', '')
    if len(job_dict['redshiftConnDetails']) != 0:

        logger.info("audit entry call to Redshift ...........")

        audit_utility_obj = AuditUtility(job_dict, etl_config)
        d, success = audit_utility_obj.audit_entry()
        is_success = d[1]
        logger.info(" Response of audit_entry .... ")
        logger.info(is_success)

    else:
        logger.info("Write Execution detail in Audit Table ......")

        audit_utils = AuditUtility(job_dict, etl_config)

        iceberg_insert_audit_res, success = audit_utils.audit_entry_iceberg()
        is_success = iceberg_insert_audit_res[1]
        logger.info(" Response of audit_entry_iceberg ....")
        logger.info(is_success)
    job_dict['table_status'] = None
    job_dict['table_error'] = None