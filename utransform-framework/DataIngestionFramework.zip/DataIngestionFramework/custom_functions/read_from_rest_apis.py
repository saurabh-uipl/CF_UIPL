import requests
import json
import pandas as pd
import logging
import pytz
import datetime
from ..src.etl_config import ETLConfig
logger = logging.getLogger("my_logger")


def read_from_rest_api(spark,job_dict, source_conn_details,etl_config: ETLConfig):
    try:
        url = source_conn_details['url']
        headers = json.loads(source_conn_details['headers'])
        data = json.loads(str(source_conn_details['data']))

        if job_dict['load_type'].lower() in ['merge', 'incremental']:
            logger.info(" Load Type Is ")
            logger.info(job_dict['load_type'])
            logger.info(" Update Start and End Date For Rest APIs")
            logger.info("data: ")
            logger.info(data)
            logger.info(type(data))
            fromUpdatedDate = str(job_dict['startdatetime'])[0:10]
            logger.info("fromUpdatedDate ")
            logger.info(fromUpdatedDate)

            toUpdatedDate = str(datetime.datetime.now(pytz.timezone(etl_config.timezone_param)))[0:10]
            logger.info("toUpdatedDate ")
            logger.info(toUpdatedDate)
            data["toUpdatedDate"] = toUpdatedDate
            data["fromUpdatedDate"] = fromUpdatedDate
            logger.info(" data :: ")
            logger.info(data)
            logger.info("Calling get_employee_data ....")
        else:
            logger.info("Use Default Start and End date for Rest APIs")
            logger.info(" Load Type Is ")
            logger.info(job_dict['load_type'])

        length_of_res, union_df = get_employee_data(spark, url, headers, str(data))
        while True:
            if length_of_res == 0:
                break
            else:
                data["pagination"]["pageNumber"] = data["pagination"]["pageNumber"] + 1
                page_num = data["pagination"]["pageNumber"]
                print(" Fetching PageNumber: " + str(page_num))
                length_of_res, employee_df = get_employee_data(spark, url, headers, str(data))
                if length_of_res == 0:
                    print(" employee_df is  empty ....")
                else:
                    union_df = union_df.union(employee_df)

        new_columns = (column.replace(' ', '_') for column in union_df.columns)
        union_df = union_df.toDF(*new_columns)


        union_df.show(2)
        union_df_count = union_df.count()
        logger.info(" count: ")
        logger.info(str(union_df_count))
        return union_df,job_dict, True, None

    except Exception as e:
        logger.error(" Error....***")
        logger.error(str(e))
        return None, job_dict, False, str(e)


def get_employee_data(spark, url, headers, data):
    logger.info("Executing get_employee_data ....")
    try:
        response = requests.post(url, headers=headers, data=data)
        json_response = json.loads(response.text)
        length_of_res = len(json_response)
        if length_of_res == 0:
            logger.info(" No More Data Found...")
            employee_df = None
            return length_of_res, employee_df
        else:
            employeeInfoArray = json_response['employeeInfo']
            pandasDF = pd.DataFrame(employeeInfoArray)
            employee_df = spark.createDataFrame(pandasDF)
            return length_of_res, employee_df
    except Exception as e:
        logger.error("Error Occurred ...")
        logger.error(str(e))
        employee_df = None
        return 0, employee_df
