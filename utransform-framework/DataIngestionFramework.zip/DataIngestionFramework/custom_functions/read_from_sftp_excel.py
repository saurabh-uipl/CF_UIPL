import paramiko
import pandas
import pandas as pd
import os
import json
import pyspark.sql.functions as F
import re
import logging
from ..src.etl_config import ETLConfig
from datetime import datetime
from pyspark.sql.functions import col, lit
from ..analytics_utilities.notification_utility import NotificationUtility, SimpleEmailService
from ..analytics_utilities.secrets_manager import SecretsManager
from ..analytics_utilities.sftp_utility import SftpUtility
from pyspark.sql.types import StructType, StructField, LongType, IntegerType, StringType, DoubleType, TimestampType
import json

logger = logging.getLogger("my_logger")

#spark = SparkSession.builder.appName("Python Spark SQL basic example").config("spark.some.config.option", "some-value").getOrCreate()

#source_conn_details={"host":"sftp.herofincorp.com","username":"umbrella data lake prod","password":"Umbr#0224","port":22}
#job_dict={"table_name":"fc","validation_rules":{'filesizeinbytes':'10240','importantcolumnlist':['cust ID','S.No','lob','foreclosure_auth_date','unique']},"sftp_file_path":"/users/Umbrella Data lake Prod/PowerBI_Dashboards/ServiceRequestDashboard/","startdatetime":"2023-10-19 12:08:29.000000","SQL_Query":"select 'S.No' as sno,APPLICATION_ID as application_id,agreementno,customername,branchid,branch_name,disbursaldate,first_disbursal_date,ltd_disbursal,productflag,scheme_desc,vc_source_cd,dsa_id,dsa_name,roi,loan_amount,foreclosure_date,billed_emi_pos,foreclosure_pos,date_add('1900-01-01',cast(foreclosure_auth_date as int)) as foreclosure_auth_date,reason,lrn,constitution,applicant_type,no_of_corporate_co_app,'Fixed/Floating' as fixed_floating,'Restructrued Status' as restructrued_status,lob,cast('cust ID' as integer) as cust_id,unique,cast('Pos in Cr' as double) as pos_in_cr,outlayer,'Company Induced' as company_induced,dpd,'BT Bank' as bt_bank,'BT offer ROI' as bt_offer_roi,'BT ROI Offer Bkt' as bt_roi_offer_bkt,'Difference of HHFL and BT Bank RoI' as difference_of_hhfl_and_bt_bank_roi,'Difference of HHFL and BT Bank ROI Bkt' as difference_of_hhfl_and_bt_bank_roi_bkt,mob,'MOB Bkt' as mob_bkt,source,substring(date_add('1900-01-01',cast(foreclosure_auth_date as int)),1,7) as foreclosure_auth_month,'{}' as source_file_name,'{}' as modified_timestamp from fc","schema_name":StructType([StructField('sno',StringType(),True), StructField('application_id',StringType(),True), StructField('agreementno',StringType(),True), StructField('customername',StringType(),True), StructField('branchid',StringType(),True), StructField('branch_name',StringType(),True), StructField('disbursaldate',StringType(),True), StructField('first_disbursal_date',StringType(),True), StructField('ltd_disbursal',StringType(),True), StructField('productflag',StringType(),True), StructField('scheme_desc',StringType(),True), StructField('vc_source_cd',StringType(),True), StructField('dsa_id',StringType(),True), StructField('dsa_name',StringType(),True), StructField('roi',StringType(),True), StructField('loan_amount',StringType(),True), StructField('foreclosure_date',StringType(),True), StructField('billed_emi_pos',StringType(),True), StructField('foreclosure_pos',StringType(),True), StructField('foreclosure_auth_date',TimestampType(),True), StructField('reason',StringType(),True), StructField('lrn',StringType(),True), StructField('constitution',StringType(),True), StructField('applicant_type',StringType(),True), StructField('no_of_corporate_co_app',StringType(),True), StructField('fixed_floating',StringType(),True), StructField('restructrued_status',StringType(),True), StructField('lob',StringType(),True), StructField('cust_id',IntegerType(),True), StructField('unique',StringType(),True), StructField('pos_in_cr',DoubleType(),True), StructField('outlayer',StringType(),True), StructField('company_induced',StringType(),True), StructField('dpd',StringType(),True), StructField('bt_bank',StringType(),True), StructField('bt_offer_roi',StringType(),True), StructField('bt_roi_offer_bkt',StringType(),True), StructField('difference_of_hhfl_and_bt_bank_roi',StringType(),True), StructField('difference_of_hhfl_and_bt_bank_roi_bkt',StringType(),True), StructField('mob',StringType(),True), StructField('mob_bkt',StringType(),True), StructField('source',StringType(),True), StructField('foreclosure_auth_month',StringType(),True), StructField('source_file_name',StringType(),True), StructField('modified_timestamp',StringType(),True)])}
#etl_config={}

def isFileValid(sftp, file_path,file, job_dict, pandas_df, etl_config):

    try:

        ##Convert All Column Names to Lower For Easy Match
        pandas_df.columns = pandas_df.columns.str.lower()

        validation_rules = json.loads(job_dict['validation_rules'].replace('\'','"'))

        ##Check if size of file is greater than a threshold value
        if(sftp.stat(file_path).st_size > int(validation_rules['filesizeinbytes'])):
            logger.info("The File Size is Greater Than {} & hence proceeding further with file : {}".format(validation_rules['filesizeinbytes'],file))
        else:
            raise Exception('The File {} Size is Lesser than 10 KB, stopping processing of the file and throwing alert'.format(file))

        ##Check if the File Contains All The Important Columns & Their DataTypes Match
        columns_to_check_set = set(column.lower() for column in validation_rules['importantcolumnlist'])
        logger.info("The Following Columns Must Mandatorily Exist in the File ::: {}".format(str(columns_to_check_set)))

        if(columns_to_check_set.issubset(pandas_df.columns)):

            logger.info("All the Important Columns {} Exists & hence proceeding further with file : {}".format(validation_rules['importantcolumnlist'],file))

            ##Check If Columns Are Not Empty Completely
            for column in columns_to_check_set:
                if not pandas_df[column].empty:
                    logger.info("The Column {} Is Not Empty".format(column))
                else:
                    raise Exception('The Column {} is Empty Within The File {}'.format(column,file))

        else:
            raise Exception('The File {} is Missing Some Important Columns'.format(file))

    except Exception as e:

        handleExceptionAndAlerts(repr(e),etl_config)


def handleExceptionAndAlerts(msg,etl_config):

    print(msg)

    # Send email notification
    notification_msg = {
        "Message": str(msg),
        "Reports Name": etl_config.job_id,
        "JobTableList": job_dict["table_name"]
    }

    logger.info('Inside exception block ')

    send_notification_msg = json.dumps({"default": json.dumps(notification_msg)})

    logger.info(type(send_notification_msg))

    if etl_config.sns_topic != 'NA':
        logger.info('Notification will sent to sns topic ')
        notification_utility_obj = NotificationUtility(send_notification_msg, etl_config)
        notification_utility_obj.send_sns()
    elif etl_config.smtp_ses_secret_name != 'NA':
        logger.info('Notification will sent to ses ')
        sam_utility = SecretsManager(etl_config.smtp_ses_secret_name, etl_config)
        smtp_ses_dict, success = sam_utility.get_secret_name()
        smtp_conn_details = smtp_ses_dict[1]
        smtp_ses_user = smtp_conn_details['user']
        smtp_ses_password = smtp_conn_details['password']
        smtp_endpoint = smtp_conn_details['endpoint']
        sender = smtp_conn_details['sender']
        recipients = smtp_conn_details['recipients']
        subject = "Error in read_from_sftp_excel"
        send_ses_obj = SimpleEmailService(notification_msg, sender, recipients, subject, etl_config,
                                          smtp_ses_user, smtp_ses_password, smtp_endpoint)
        send_ses_obj.send_ses()
    else:
        logger.info('Notification is not enabled ....')
        pass
    # incoming_source_df, job_dict, success, is_error


def read_from_sftp_excel(spark, job_dict, source_conn_details, etl_config: ETLConfig):

    try:

        sftp = SftpUtility.get_sftp_conn(source_conn_details['host'], source_conn_details['port'],
                                         source_conn_details['username'], source_conn_details['password'])

        excel_file_path = job_dict['sftp_file_path']
        logger.info("Processing " + str(excel_file_path))

        ##Get All Files In The Directory
        #files = sftp.listdir(excel_file_path)
        files = [x.filename for x in sorted(sftp.listdir_attr(excel_file_path), key=lambda f: f.st_mtime)]

        logger.info("Found Files : {} Within Directory : {}".format(files,excel_file_path))

        ###List & Process All Files After the below Timestamp
        file_offset_time = datetime.strptime(job_dict['startdatetime'][0:18], '%Y-%m-%d %H:%M:%S')
        logger.info("Finding & Processing all Files After Time ::: " + str(file_offset_time))

        ##Initialize the Final Dataframe
        ##We need to union multiple file DF's since we might receive multiple files within End Of Month
        excel_sheet_spark_df = spark.createDataFrame([],eval(job_dict['schema_name']))

        # check for new files above date limit
        try:
            for f in files:

                # get last modified date/timestamp from file metadata
                file_path = excel_file_path + f
                last_modified = sftp.stat(file_path).st_mtime
                last_modified_ts = datetime.fromtimestamp(last_modified)

                if last_modified_ts > file_offset_time:

                    logger.info("Processing File :: {} With Last Modified Date ::: {}, since it is greater than {}".format(f,last_modified_ts,file_offset_time))

                    sftp_excel_file = sftp.open(file_path)
                    pandas_excel_file = pandas.ExcelFile(sftp_excel_file)
                    logger.info("The File :: {} Contains the Following Sheets {}".format(f,pandas_excel_file.sheet_names))

                    ###Check & loop the filenames expected
                    logger.info("Fetching Sheet Name : {}".format(job_dict['table_name']))
                    sheet_to_find = job_dict['table_name']

                    # Get all the sheetnames as a list
                    sheet_names = pandas_excel_file.sheet_names

                    logger.info("The Sheet Names Available Within Excel Are ::: {}".format(sheet_names))

                    # Format the list of sheet names
                    sheet_names = [name.lower()
                                   .replace('jan','')
                                   .replace('feb','')
                                   .replace('mar','')
                                   .replace('apr','')
                                   .replace('may','')
                                   .replace('jun','')
                                   .replace('jul','')
                                   .replace('aug','')
                                   .replace('sep','')
                                   .replace('oct','')
                                   .replace('nov','')
                                   .replace('dec','')
                                   .replace(' ','') for name in sheet_names]

                    logger.info(sheet_names)

                    # Get the index that matches our sheet to find
                    index = sheet_names.index(sheet_to_find.lower())

                    # Feed this index into pandas
                    logger.info("The Sheet : {} exists at Index : {}".format(sheet_to_find.lower(),index))

                    pd.set_option('display.max_columns', None)
                    pd.set_option('display.max_rows', 500)
                    pd.set_option('display.width', 1000)

                    excel_sheet_pandas_df = pandas_excel_file.parse(index)

                    ##Applying Some File Validation Rules
                    logger.info("Applying Some File Validation Rules To File : {}".format(f))
                    isFileValid(sftp,file_path,f,job_dict,excel_sheet_pandas_df,etl_config)

                    logger.info(" Pandas DF has been created ....")
                    logger.info(" Converting columns to string ...")

                    for col_name in excel_sheet_pandas_df.columns:
                            excel_sheet_pandas_df[col_name] = excel_sheet_pandas_df[col_name].astype(str)

                    df_spark = spark.createDataFrame(excel_sheet_pandas_df)

                    #Create a Temp Table For Executing Spark SQL Queries to Manipuate the Dataframe
                    df_spark.createOrReplaceTempView(job_dict['table_name'])

                    logger.info("Writing Final Dataframe")
                    sql_query = "select * from " + job_dict['SQL_Query'].format(str(f), str(last_modified_ts))
                    excel_sheet_spark_df = excel_sheet_spark_df.union(spark.sql('{}'.format(sql_query)))

                excel_sheet_spark_df.show()

            return excel_sheet_spark_df, job_dict, True, None

        except Exception as e:
            logger.info("File Processing Failed : {} ".format(repr(e)))

    except Exception as e:
        logger.info("Exception While Processing SFTP Files: {} ".format(repr(e)))


#read_from_sftp_excel(spark, job_dict, source_conn_details, job_dict)
