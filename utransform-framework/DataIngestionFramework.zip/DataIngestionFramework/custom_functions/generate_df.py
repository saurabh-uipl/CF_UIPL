from ..common_utilities.Common_utility import CommonUtility

import logging

logger = logging.getLogger("my_logger")


def generate_merged_df(job_dict, spark, df):
    """
    Args:
        job_dict:
        spark:
        df:

    Returns:
        job_dict:
        df_final:
        df_s3:


    """
    try:
        logger.info(" Executing generate_merged_df ......")
        success = True
        partition_column = job_dict["Partition_Column"]
        logger.info("partition_column: ")
        logger.info(partition_column)
        if 'None' in partition_column:
            partition_column.remove('None')
            logger.info("Removed None")
        if '<NA>' in partition_column:
            partition_column.remove('<NA>')
            logger.info("Removed <NA>")
        job_dict["Partition_Column"] = partition_column
        logger.info("updated partition_column: ")
        logger.info(partition_column)
        logger.info("Len(partition_column) : ")
        logger.info(len(partition_column))
        df_s3 = None
        if len(job_dict["Partition_Column"]) > 1:
            logger.info(" Number of partitions is > 1 .......")
            first_partition = str(job_dict["Partition_Column"][0])
            latest_partition_s3 = first_partition + "=" + job_dict["Partition_Year"]

            directory_name = job_dict["source"] + "/" + job_dict["JOBNAME"] + "/" + job_dict[
                "table_name"] + "/" + latest_partition_s3 + "/"
            logger.info(" Calling check_s3_path ....")
            logger.info(str(directory_name))
            d = CommonUtility.check_s3_path(
                job_dict["bucket_name"], directory_name)
            exists = d[1]
            logger.info(" Exists: ")
            logger.info(str(exists))
            if exists > 0:
                logger.info(" Exists > 0 ")
                df_s3 = spark.read.parquet(
                    "s3://" + job_dict["bucket_name"] + "/" + job_dict["source"] + "/" + job_dict[
                        "JOBNAME"] + "/" + job_dict["table_name"] + "/" + latest_partition_s3 + "/")
                df_s3.createOrReplaceTempView(job_dict["table_name"])
                sql_query_s3 = "select *," + "'" + job_dict[
                    "Partition_Year"] + "'" + " AS " + first_partition + " from " + job_dict["table_name"]
                df_s3 = spark.sql(sql_query_s3)

                df_s3.createOrReplaceTempView("base")

                delta_df = df.select(df_s3.columns)

                delta_df.createOrReplaceTempView("delta")
                logger.info(" Running Merge Query For De-dup .......")
                df_final = spark.sql(job_dict["merge_query"])
                logger.info(" De-dup query ran successfully ....")
                df_final = df_final.drop('row_num')
                df_final = df_final.union(delta_df)

            else:
                logger.info(" Table Path Not Found On S3 ....No need to run de-dup query ....")
                df_final = df
        else:
            logger.info(" Number of Partition is <= 1")
            directory_name = job_dict["source"] + "/" + job_dict["JOBNAME"] + "/" + job_dict[
                "table_name"] + "/"
            logger.info(" Check Path On S3...")
            logger.info(str(directory_name))
            d = CommonUtility.check_s3_path(
                job_dict["bucket_name"], directory_name)
            exists = d[1]
            logger.info(" exists: ")
            logger.info(str(exists))
            if exists > 0:
                logger.info(" Path Found On S3 ....")
                s3_file_path = "s3://" + job_dict["bucket_name"] + "/" + job_dict["source"] + "/" + job_dict[
                    "JOBNAME"] + "/" + job_dict["table_name"] + "/"

                df_s3 = spark.read.parquet(s3_file_path)

                df_s3.createOrReplaceTempView("base")

                delta_df = df.select(df_s3.columns)

                delta_df.createOrReplaceTempView("delta")
                logger.info(" Run De-dup query .....")
                df_final = spark.sql(job_dict["merge_query"])
                logger.info(" Remove row_num column ...")
                df_final = df_final.drop('row_num')
                df_final_cnt = df_final.count()
                logger.info(" No Of Records After De-dup")
                logger.info(str(df_final_cnt))
                df_final = df_final.union(delta_df)
                df_final_cnt = df_final.count()
                logger.info(" No Of Records After De-dup")
                logger.info(str(df_final_cnt))

            else:
                logger.info(" Table Not Found On S3 ....")
                df_final = df
        is_error = None
        return job_dict, df_final, df_s3, success, is_error
    except Exception as e:
        logger.error(str(e))
        df_final = None
        success = None
        df_s3 = None
        is_error = str(e)
        return job_dict, df_final, df_s3, success, is_error


def generate_incr_df(job_dict, df):
    """
    Args:
        job_dict:
        df:

    Returns:
        job_dict:
        df_final
    """
    try:
        success = True
        partition_column = job_dict["Partition_Column"]
        if 'None' in partition_column:
            partition_column.remove('None')
        if '<NA>' in partition_column:
            partition_column.remove('<NA>')

        logger.info("partition_column: {}".format(partition_column))
        job_dict["Partition_Column"] = partition_column
        df.persist()
        df_final = df
        is_error = None
        return job_dict, df_final, success, is_error
    except Exception as e:
        logger.error(" Error Occurred In generate_incr_df .....:::")
        logger.error(str(e))
        df_final = None
        success = False
        is_error = str(e)
        return job_dict, df_final, success, is_error
