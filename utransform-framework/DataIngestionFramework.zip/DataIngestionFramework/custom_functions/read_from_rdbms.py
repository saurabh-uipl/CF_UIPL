from .insert_failed_tables import add_failed_table_entry
from ..common_utilities.Common_utility import CommonUtility
import logging
from ..src.etl_config import ETLConfig

logger = logging.getLogger('my_logger')


def read_from_rdbms(spark, source_conn_details, job_dict, etl_config: ETLConfig):
    """
    Args:
        spark:
        source_conn_details:
        job_dict:
        etl_config:

    Returns:
        df:
        job_dict:

    """
    try:
        success = True
        if job_dict["source"].lower() == 'oracle':

            if job_dict['part_col_int'] is None or str(job_dict['part_col_int']) == 'None' or str(job_dict['part_col_int']) == '<NA>':
                logger.info(" Fetching Data From Oracle without partitioning ")
                logger.info(job_dict["source"])
                job_dict["SQL_Query"] = job_dict["SQL_Query"].rstrip('as t')
                logger.info("sql_query : ")
                logger.info(job_dict["SQL_Query"])
                df = etl_config.glueContext.read.format("jdbc").option("driver", str(source_conn_details['driver'])).option(
                    "url",
                    str(
                        source_conn_details[
                            'url'])).option(
                    "dbtable", job_dict["SQL_Query"]).option("user",
                                                             str(source_conn_details['user'])).option(
                    "password", str(source_conn_details['password'])).option("fetchsize", "100000").load()

                logger.info("Display Oracle DF: ----")
                is_error = None
                return df, job_dict, success, is_error

            else:
                logger.info(" Fetching Data From Oracle with partitioning ")
                logger.info(job_dict["source"])
                job_dict["SQL_Query"] = job_dict["SQL_Query"].rstrip('as t')
                logger.info(str(job_dict["SQL_Query"] ))
                if job_dict['part_lower_bound'] == 0 and job_dict['part_upper_bound'] == 0:
                    logger.info("*************** part_lower_bound = 0 and part_upper_bound = 0  ***********")
                    df = (etl_config.glueContext.read.format("jdbc")
                          .option("driver", str(source_conn_details['driver']))
                          .option("url",str(source_conn_details['url']))
                          .option("dbtable", job_dict["SQL_Query"])
                          .option("user", str(source_conn_details['user']))
                          .option("password", str(source_conn_details['password']))
                          .option("partitionColumn", job_dict['part_col_int'])
                          .option("lowerBound", 1)
                          .option("upperBound", 2000000000)
                          .option("numPartitions", 5)
                          .option("fetchsize", "100000").load())

                    logger.info("Display Oracle DF: ----")
                    is_error = None
                    return df, job_dict, success, is_error

                else:
                    logger.info("*************** part_lower_bound != 0 and part_upper_bound != 0  ***********")
                    logger.info(" Fetching Data From Oracle with partitioning ")
                    logger.info(job_dict["source"])
                    job_dict["SQL_Query"] = job_dict["SQL_Query"].rstrip('as t')
                    logger.info(str(job_dict["SQL_Query"]))

                    df = (etl_config.glueContext.read.format("jdbc")
                          .option("driver", str(source_conn_details['driver']))
                          .option("url", str(source_conn_details['url']))
                          .option("dbtable", job_dict["SQL_Query"])
                          .option("user", str(source_conn_details['user']))
                          .option("password", str(source_conn_details['password']))
                          .option("partitionColumn", job_dict['part_col_int'])
                          .option("lowerBound", int(job_dict['part_lower_bound']))
                          .option("upperBound", int(job_dict['part_upper_bound']))
                          .option("numPartitions", int(job_dict['num_partitions']))
                          .option("fetchsize", "100000").load())

                    logger.info("Display Oracle DF: ----")
                    is_error = None
                    return df, job_dict, success, is_error

        else:

            logger.info("SQL_Query: ")
            if job_dict['part_col_int'] is None or str(job_dict['part_col_int']) == 'None' or str(job_dict['part_col_int'])  == '<NA>':
                logger.info("part_col_int is None")
                mysql_df = (etl_config.glueContext.read.format("jdbc")
                            .option("driver", str(source_conn_details['driver']))
                            .option("url", str(source_conn_details['url']))
                            .option("dbtable", job_dict["SQL_Query"])
                            .option("user", str(source_conn_details['user']))
                            .option("password", str(source_conn_details['password']))
                            .option("fetchsize", "1000000").load()
                            )

            else:
                logger.info("part_col_int is not none ")
                logger.info("Using multi partition for fetching the data from source")
                logger.info(job_dict['part_col_int'])
                if job_dict['part_lower_bound'] == 0  and  job_dict['part_upper_bound'] == 0:
                    logger.info("Lower/Upper bounds are not defined , will use default lower(1) and upper(2000000000)")
                    mysql_df = (etl_config.glueContext.read.format("jdbc")
                                .option("driver", str(source_conn_details['driver']))
                                .option("url", str(source_conn_details['url']))
                                .option("dbtable", job_dict["SQL_Query"])
                                .option("user", str(source_conn_details['user']))
                                .option("password", str(source_conn_details['password']))
                                .option("partitionColumn", job_dict['part_col_int'])
                                .option("lowerBound", 1)
                                .option("upperBound", 2000000000)
                                .option("numPartitions", 5)
                                .option("fetchsize", "100").load())
                else:
                    logger.info("Lower/Upper bounds are defined")
                    logger.info("part_lower_bound")
                    logger.info(job_dict['part_lower_bound'])
                    logger.info("part_upper_bound")
                    logger.info(job_dict['part_upper_bound'])
                    logger.info("num_partitions")
                    logger.info(job_dict['num_partitions'])
                    mysql_df = (etl_config.glueContext.read.format("jdbc")
                                .option("driver", str(source_conn_details['driver']))
                                .option("url", str(source_conn_details['url']))
                                .option("dbtable", job_dict["SQL_Query"])
                                .option("user", str(source_conn_details['user']))
                                .option("password", str(source_conn_details['password']))
                                .option("partitionColumn", job_dict['part_col_int'])
                                .option("lowerBound", int(job_dict['part_lower_bound']) )
                                .option("upperBound", int(job_dict['part_upper_bound']))
                                .option("numPartitions", int(job_dict['num_partitions']))
                                .option("fetchsize", "100").load())

            logger.info("Query Ran Successfully on Source .....")
            logger.info("No Of Partitions in DF")
            logger.info(mysql_df.rdd.getNumPartitions())
            no_of_partitions = mysql_df.rdd.getNumPartitions()
            mysql_df = mysql_df.toDF(*[c.lower() for c in mysql_df.columns])
            if no_of_partitions > 20:
                repart_df = mysql_df.coalesce(20)
            else:
                repart_df = mysql_df
            logger.info("No Of Partitions in DF After re-partitioning")
            logger.info(repart_df.rdd.getNumPartitions())
            repart_df.cache()
            if str(job_dict['json_flatten']) == '1':
                logger.info("Json Flatten Is Enabled......")
                df = CommonUtility.json_string_to_struct(etl_config.glueContext, repart_df, logger)
            else:
                logger.info("Json Flatten Is not Enabled .......")
                df = repart_df
            is_error = None

            logger.info(" Return the df ....")
            return df, job_dict, success, is_error
    except Exception as e:
        logger.error(" Error Occurred in read_from_rdbms function.......")
        logger.error(str(e))
        df = None
        success = False
        is_error = str(e)
        add_failed_table_entry(job_dict, etl_config, logger, is_error)
        return df, job_dict, success, is_error
