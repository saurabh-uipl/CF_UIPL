from py4j.java_gateway import java_import
import logging

from DataIngestionFramework.custom_functions.insert_failed_tables import add_failed_table_entry

logger = logging.getLogger('my_logger')


def read_from_snowflake(spark, job_dict, source_conn_details):
    """"
    Args:
        spark:
        job_dict:
        source_conn_details:

    Returns:
        df:
        job_dict:
    """
    try:
        success = True
        snowflake_source_name = "net.snowflake.spark.snowflake"
        java_import(spark._jvm, "net.snowflake.spark.snowflake")
        spark._jvm.net.snowflake.spark.snowflake.SnowflakeConnectorUtils.enablePushdownSession(
            spark._jvm.org.apache.spark.sql.SparkSession.builder().getOrCreate())

        database = job_dict["SQL_Query"].split('.')[0].split()[-1]
        schema = job_dict["SQL_Query"].split('.')[1]

        job_dict["SQL_Query"] = job_dict["SQL_Query"].replace('as t', '')
        df = spark.read.format(snowflake_source_name).option("sfUser", str(source_conn_details['USERNAME'])).option(
            "sfURL", str(source_conn_details['URL'])).option("sfPassword", str(source_conn_details['PASSWORD'])).option(
            "sfDatabase", database).option("sfSchema", schema).option(
            "sfWarehouse", str(source_conn_details['WAREHOUSE'])).option("tracing",
                                                                         str(source_conn_details['TRACING'])).option(
            "insecureMode", str(source_conn_details['insecureMode'])).option("dbtable", job_dict["SQL_Query"]).load()
        is_error = None
        return df, job_dict, success, is_error
    except Exception as e:
        logger.error(str(e))
        df = None
        success = False
        is_error = str(e)
        return df, job_dict, success, is_error
