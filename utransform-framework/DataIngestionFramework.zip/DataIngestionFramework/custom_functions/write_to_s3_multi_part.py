import boto3
from ..common_utilities.Common_utility import CommonUtility
from pyspark.sql.functions import *
import logging

logger = logging.getLogger("my_logger")
from ..src.etl_config import ETLConfig


def write_to_s3_multi_part(job_dict, spark, df_final, df_s3, etl_config: ETLConfig, is_table_present_flag=0):
    """
    Args:
        etl_config:
        job_dict:

        spark:
        df_final:
        df_s3:
        is_table_present_flag:

    Returns:
        job_dict:

    """
    try:
        logger.info(" Executing write_to_s3_multi_part ............")
        success = True
        Partition_Column_TABLE = str(job_dict["Partition_Column"])[
                                 1:-1].replace("'", '').lower()
        logger.info("Partition_Column_TABLE: ")
        logger.info(Partition_Column_TABLE)

        partition_step = job_dict["Partition_Column"]
        logger.info("type(partition_step)")
        logger.info(type(partition_step))
        logger.info("partition_step: ")
        logger.info(partition_step)
        logger.info("len(partition_step)")
        logger.info(len(partition_step))

        logger.info("partition_step: ")
        logger.info(partition_step)

        logger.info("Writing to S3 ")

        df_final.createOrReplaceTempView("df_final")
        if job_dict["destination_type"] == 'iceberg':
            if job_dict["load_type"] == "merge":
                logger.info(" Load Type Is ")
                logger.info(str(job_dict["load_type"]))
                logger.info(" Merge Into Existing Iceberg Table .....")
                query = f"""
                            MERGE INTO uipl.{etl_config.athena_db_name}.{job_dict["table_name"]} t
                            USING (SELECT * FROM df_final) s
                            ON t.{job_dict["pk_column"]} = s.{job_dict["pk_column"]}
                            WHEN MATCHED THEN UPDATE SET * 
                            WHEN NOT MATCHED THEN INSERT * """

                spark.sql(query)
                logger.info(str(query))
                logger.info(" Merge Query Ran Successfully .....")

            elif job_dict["load_type"] == "incremental":
                logger.info(" Load Type Is ")
                logger.info(str(job_dict["load_type"]))
                logger.info(" Insert Into Existing Table ....")
                query = f'INSERT INTO uipl.{etl_config.athena_db_name}.{job_dict["table_name"]} SELECT * FROM df_final ORDER BY {Partition_Column_TABLE}'

                spark.sql(query)
                logger.info(str(query))
                logger.info(" Insert Query Ran Successfully .....")

            else:
                if is_table_present_flag == 1:
                    pass
                else:
                    logger.info(f'START WRITING FULL LOAD DATA IN ICEBERG')
                    logger.info(" Load Type Is ")
                    logger.info(str(job_dict["load_type"]))
                    logger.info(" Insert Overwrite Into Existing Table ....")
                    query = f"""INSERT OVERWRITE uipl.{etl_config.athena_db_name}.{job_dict["table_name"]} SELECT * FROM 
                    df_final ORDER BY {Partition_Column_TABLE}"""
                    spark.sql(query)
                    logger.info(str(query))
                    logger.info(" Overwrite Query Ran Successfully .....")

        if job_dict["destination_type"] != 'iceberg':
            if job_dict["load_type"] == "incremental" and (job_dict["incremental_value"] not in ("", 'nan')):
                logger.info("Load type is icremental and incremental value is not none")
                # job_dict["incremental_value"] != "" or job_dict["incremental_value"] != 'nan'):

                '''
                df_final.repartition(5, partition_step).write.mode("append").partitionBy(
                    partition_step).parquet(
                    "s3://" + job_dict["bucket_name"] + "/" + job_dict["source"] + "/" + str(
                        job_dict["JOBNAME"]) + "/" + job_dict["table_name"] + "/")
                '''
                df_final.coalesce(5).write.mode("append").partitionBy(
                    partition_step).parquet(
                    "s3://" + job_dict["bucket_name"] + "/" + job_dict["source"] + "/" + str(
                        job_dict["JOBNAME"]) + "/" + job_dict["table_name"] + "/")

            else:
                logger.info("Load type is merge ")
                logger.info("DF repartitioning")
                df_final = df_final.coalesce(5)

                try:
                    if df_s3 is not None and isinstance(df_s3, DataFrame):

                        # lst_final = df_final.select(job_dict["Partition_Column"][0]).distinct().rdd.map(lambda x: x[0]).collect()

                        lst_final = df_final.select(date_format(job_dict["Partition_Column"][0], "yyyy-MM-dd")).distinct().rdd.map(
                            lambda x: x[0]).collect()

                        # logger.info("lst_final: ")
                        # logger.info(lst_final)

                        s3_date_part = df_s3.select(
                            date_format(job_dict["Partition_Column"][0], "yyyy-MM-dd")).distinct()

                        lst_s3 = s3_date_part.rdd.map(lambda x: x[0]).collect()
                        # logger.info("lst_s3: ")
                        # logger.info(lst_s3)

                        s3_path = "s3://" + job_dict["bucket_name"] + "/" + job_dict["source"] + "/" + str(
                            job_dict["JOBNAME"]) + "/" + job_dict["table_name"] + "/"
                        logger.info("Writing the data in S3......")
                        if '<NA>' in partition_step :
                            df_final.write.mode("overwrite").parquet(s3_path)
                        else:
                            df_final.write.mode("overwrite").partitionBy(partition_step[0]).parquet(s3_path)

                        logger.info("Data Has Been Written in S3.....")
                        s3 = boto3.resource('s3')
                        bucket = s3.Bucket(job_dict["bucket_name"])

                        directory_name = job_dict["source"] + "/" + job_dict["JOBNAME"] + "/" + job_dict[
                            "table_name"] + "/"
                        logger.info("Checking folder in S3 ....")
                        logger.info(directory_name)
                        d = CommonUtility.check_s3_path(
                            job_dict["bucket_name"], directory_name)
                        exists = d[1]

                        if exists > 0:
                            logger.info("comparing the partition")

                            # lst = [x for x in lst_s3 if x not in lst_final and x is not None]
                            lst = [x for x in lst_s3 if x not in lst_final and x is not None]
                            # logger.info("lst: ")
                            # logger.info(lst)

                            for old_partition in lst:
                                # logger.info("old_partition: ")
                                # logger.info(old_partition)
                                # logger.info("Deleting old partition ....")

                                bucket.objects.filter(
                                    Prefix=job_dict["source"] + "/" + str(job_dict["JOBNAME"]) + "/" + job_dict[
                                        "table_name"] + "/" + job_dict["Partition_Column"][
                                               0] + "=" + old_partition).delete()

                        bucket.objects.filter(
                            Prefix=job_dict["source"] + "/" + str(job_dict["JOBNAME"]) + "/" + job_dict[
                                "table_name"] + "/" + job_dict["Partition_Column"][0] + "=2099-01-01").delete()

                    else:
                        logger.info(" S3 file does not exist ....")
                        if '<NA>' in partition_step:
                            df_final.write.mode("overwrite").parquet(
                                "s3://" + job_dict["bucket_name"] + "/" + job_dict["source"] + "/" + str(
                                    job_dict["JOBNAME"]) + "/" + job_dict["table_name"] + "/")
                        else:
                            df_final.write.mode("overwrite").partitionBy(partition_step[0]).parquet(
                                "s3://" + job_dict["bucket_name"] + "/" + job_dict["source"] + "/" + str(
                                    job_dict["JOBNAME"]) + "/" + job_dict["table_name"] + "/")


                except NameError as error:
                    logger.error(error)
        is_error = None
        return job_dict, success, is_error
    except Exception as e:
        logger.error(str(e))
        success = False
        is_error = str(e)
        return job_dict, success, is_error


def write_to_s3_non_part(job_dict, df_final, df, spark, etl_config: ETLConfig, is_table_present_flag=0):
    """
    Args:
        job_dict:
        df_final:
        df:
        spark:

        is_table_present_flag:

    Returns:
        job_dict:
    """
    logger.info(" Executing write_to_s3_non_part .....")
    try:
        success = True
        if job_dict["destination_type"] != 'iceberg':
            if job_dict["load_type"] == "incremental" and (
                    job_dict["incremental_value"] != "" or job_dict["incremental_value"] != 'nan'):
                logger.info(
                    " Writing to S3 ")
                df_final.coalesce(5).write.mode("append").parquet(
                    "s3://" + job_dict["bucket_name"] + "/" + job_dict["source"] + "/" + str(
                        job_dict["JOBNAME"]) + "/" + job_dict["table_name"] + "/")

            else:
                if df.count() > 0:
                    if job_dict["load_type"] == "merge":
                        df_final.persist()

                        logger.info(
                            "*****Writing to S3 ")

                        df_final.coalesce(1).write.mode("overwrite").parquet(
                            "s3://" + job_dict["bucket_name"] + "/" + job_dict["source"] + "/" + str(
                                job_dict["JOBNAME"]) + "/" + job_dict["table_name"] + "/")

                    else:
                        logger.info("Start Writing in S3")

                        df_final.coalesce(5).write.mode("overwrite").parquet(
                            "s3://" + job_dict["bucket_name"] + "/" + job_dict["source"] + "/" + str(
                                job_dict["JOBNAME"]) + "/" + job_dict["table_name"] + "/")

                else:
                    logger.info("Table is already updated")
        if job_dict["destination_type"] == 'iceberg':
            logger.info(" creating temp view of df_final ....")
            df_final.createOrReplaceTempView("df_final")
            if job_dict["load_type"] == "merge":
                logger.info(" Load Type is merge ......")
                query = f"""
                            MERGE INTO uipl.{etl_config.athena_db_name}.{job_dict["table_name"]} t
                            USING (SELECT * FROM df_final) s
                            ON t.{job_dict["pk_column"]} = s.{job_dict["pk_column"]}
                            WHEN MATCHED THEN UPDATE SET * 
                            WHEN NOT MATCHED THEN INSERT * """

                spark.sql(query)
                logger.info(" Merge Query Ran Successfully .....")

            elif job_dict["load_type"] == "incremental":

                query = f'INSERT INTO uipl.{etl_config.athena_db_name}.{job_dict["table_name"]} SELECT * FROM df_final'

                spark.sql(query)
                logger.info(" Insert Query Ran Successfully ......")

            else:
                if is_table_present_flag == 1:
                    pass
                else:
                    logger.info(f'START WRITING FULL LOAD DATA IN ICEBERG')

                    query = f"""INSERT OVERWRITE uipl.{etl_config.athena_db_name}.{job_dict["table_name"]}
                     SELECT * FROM df_final"""
                    spark.sql(query)
        is_error = None
        return job_dict, success, is_error
    except Exception as e:
        logger.error(str(e))
        success = False
        is_error = str(e)
        return job_dict, success, is_error
