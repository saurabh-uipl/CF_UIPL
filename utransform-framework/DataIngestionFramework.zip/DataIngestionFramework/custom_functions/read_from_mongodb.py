from datetime import datetime as dt
from datetime import datetime, timedelta
from ..common_utilities.Common_utility import CommonUtility
import logging
from ..src.etl_config import ETLConfig
from pyspark.sql.functions import col

logger = logging.getLogger('my_logger')


def read_from_mongodb(job_dict, database, collection, source_conn_details, etl_config: ETLConfig):
    """
    Args:
        job_dict:
        database:
        collection:
        source_conn_details:
        etl_config:

    Returns:
        df:
        job_dict:

    """
    try:
        logger.info("incremental_value: ")
        logger.info(job_dict["incremental_value"])
        if str(job_dict["incremental_value"]) in ['None', 'NaN', 'NaT', 'nan']:
            logger.info("incremental_value is null....")
            success = True
            incremental_column = "'" + job_dict["incremental_column"] + "'"
            logger.info(" preparing startdatetime: ")
            startdatetime_format = '%Y-%m-%d %H:%M:%S'
            startdatetime_obj = datetime.strptime(str(job_dict["startdatetime"]), startdatetime_format)
            startdatetime_obj_new = startdatetime_obj + timedelta(days=-1)
            logger.info("startdatetime_obj_new: "+str(startdatetime_obj_new))
            '''
            startdatetime = "'" + dt.strptime(str(job_dict["startdatetime"]).split('.')[0],
                                              '%Y-%m-%d %H:%M:%S').isoformat() + ".000Z" + "'"
            '''
            startdatetime = "'" + dt.strptime(str(startdatetime_obj_new).split('.')[0],
                                              '%Y-%m-%d %H:%M:%S').isoformat() + ".000Z" + "'"
            logger.info(" startdatetime ")
            logger.info(str(startdatetime))
            pipeline = "{'$match': {%s:{$gt: {$date: %s}}}}" % (
                incremental_column, startdatetime)
            '''
            if job_dict['source'].lower() == 'mongodb':
                startdatetime = startdatetime.replace(' ', 'T') + 'Z'
            logger.info("updated startdatetime")
            '''
            logger.info(startdatetime)
            pipeline = "[{'$match': {%s: {'$gte': {'$date': %s}}}}]" % (
                str(incremental_column), str(startdatetime))

            logger.info(" MongoDB pipeline: ")
            logger.info(pipeline)

            df = (etl_config.glueContext.read.format(str(source_conn_details['driver']))
                  .option("uri", str(source_conn_details['url']))
                  .option("sampleSize", 70067900)
                  .option("database", str(database))
                  .option("collection", str(collection))
                  .option("pipeline", pipeline).load()
                  )
            if str(job_dict['json_flatten']) == '1':
                logger.info("Json Flatten Is Enabled......")
                df = CommonUtility.json_string_to_struct(etl_config.glueContext, df, logger)
            else:
                logger.info("Json Flatten Is not Enabled .......")
                df = df

            logger.info(" Display Mongo Data ....")
            is_error = None
            return df, job_dict, success, is_error
        else:
            logger.info("incremental_value is not null")
            success = True
            incremental_column = "'" + job_dict["incremental_column"] + "'"
            offset_value = int(job_dict["incremental_value"])

            pipeline = "{'$match': {%s:{$gt: %s}}}}" % (
                incremental_column, offset_value)

            logger.info(" MongoDB pipeline: ")
            logger.info(pipeline)
            df = etl_config.glueContext.read.format(str(source_conn_details['driver'])).option("uri", str(
                source_conn_details['url'])).option("database", str(database)).option("collection",
                                                                                      str(collection)).option(
                "pipeline", pipeline).option('sampleSize', 126790060).option("spark.mongodb.input.partitioner", "MongoPaginateBySizePartitioner").load()
            if str(job_dict['json_flatten']) == '1':
                logger.info("Json Flatten Is Enabled......")
                df = CommonUtility.json_string_to_struct(etl_config.glueContext, df, logger)
            else:
                logger.info("Json Flatten Is not Enabled .......")
                df = df

            logger.info(" Display Mongo Data ....")
            is_error = None
            return df, job_dict, success, is_error

    except Exception as e:
        df = None
        job_dict = None
        success = False
        is_error = str(e)
        logger.error(str(e))
        return df, job_dict, success, is_error


def mongo_db_full_load(source_conn_details, database, collection, etl_config: ETLConfig, job_dict):
    """
    Args:
        source_conn_details:
        database:
        collection:
        etl_config:
    Returns:
         df:
         :param collection:
         :param etl_config:
         :param source_conn_details:
         :param database:
         :param job_dict:

    """
    try:
        success = True
        pipeline = "[]"
        '''
        mongo_df = etl_config.glueContext.read.format(str(source_conn_details['driver'])).option("uri", str(
            source_conn_details['url'])).option("database", str(database)).option("collection",
                                                                                  str(collection)).option(
                "pipeline", pipeline).option('sampleSize', 1006790060).option("spark.mongodb.input.partitioner", "MongoPaginateBySizePartitioner").load()
        '''
        mongo_df = etl_config.glueContext.read.format(str(source_conn_details['driver'])).option("uri", str(
            source_conn_details['url'])).option("database", str(database)).option("collection",
                                                                                  str(collection)).option(
            "pipeline", pipeline).option('sampleSize', 10067900).load()



        '''
        mongo_df = etl_config.glueContext.read \
            .format(str(source_conn_details['driver'])) \
            .options(uri=str(source_conn_details['url']), database=str(database),collection=str(collection)) \
            .option("sampleSize", 1006790060) \
            .option("partitioner", "com.mongodb.spark.sql.connector.read.partitioner.PaginateBySizePartitioner") \
            .load()
        '''
        # mongo_df = mongo_df.select([col(c).cast("string") for c in mongo_df.columns])
        if job_dict['json_flatten'] == 1:
            logger.info("json_flatten is enabled ....")
            df = CommonUtility.json_flatten(mongo_df)
            is_error = None
            return df, success, is_error
        else:
            logger.info("json_flatten is disabled.....")
            return  mongo_df, success, None
    except Exception as e:
        logger.error(str(e))
        df = None
        success = False
        is_error = str(e)
        return df, success, is_error


def mongo_staging_query(job_dict, staging_table, etl_config: ETLConfig):
    """
    Args:
        job_dict:
        staging_table:

    Returns:
        sql_query_staging:
        :param etl_config:
    """
    try:
        success = True
        sql_query_staging = "select *, " \
        "from_utc_timestamp(current_timestamp(), " + "'" + etl_config.timezone_param + "'" + ") as pull_time, " \
        "from_utc_timestamp(current_timestamp(), " + "'" + etl_config.timezone_param + "'" + ") as  updatetime," \
        "from_utc_timestamp(current_timestamp(), " + "'" + etl_config.timezone_param + "'" + ") AS bdl_created, " \
        "'"+job_dict["JOBNAME"] + "'" + " AS  pipelineid from " + staging_table
        is_error = None
        logger.info("sql_query_staging: ")
        logger.info(sql_query_staging)
        return sql_query_staging, success, is_error
    except Exception as e:
        logger.error(str(e))
        sql_query_staging = None
        success = False
        is_error = str(e)
        return sql_query_staging, success, is_error


def rdbms_staging_query(staging_table, job_dict, etl_config: ETLConfig):
    """
    Params:
        staging_table:
        job_dict:

    Returns:
        sql_query_staging:
    """
    try:
        print(etl_config.timezone_param)
        logger.info(" Executing  rdbms_staging_query ......")
        success = True
        sql_query_staging = "select *, from_utc_timestamp(current_timestamp()," + "'" + etl_config.timezone_param + "'" + ") AS bdl_created," + "'" + job_dict[
            "JOBNAME"] + "'" + " AS  pipelineid from " + staging_table
        is_error = None
        return sql_query_staging, success, is_error

    except Exception as e:
        logger.error(str(e))
        sql_query_staging = None
        success = False
        is_error = str(e)
        return sql_query_staging, success, is_error
