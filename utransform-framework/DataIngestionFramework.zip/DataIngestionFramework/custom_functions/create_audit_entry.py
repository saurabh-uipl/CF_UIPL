from pg8000 import dbapi
import datetime
import pytz
from ..audit_utilities.audit_utility import AuditUtility
import awswrangler as wr
from ..src.etl_config import ETLConfig
from datetime import timedelta

import logging

logger = logging.getLogger("my_logger")


def create_audit_entry(row, redshiftConnDetails, etl_config: ETLConfig, e=None):
    """
    Args:
        row:
        redshiftConnDetails:
        etl_config:
        e
    Returns:
        exception_dict:
    """

    try:
        exception_dict = {
            "JOBNAME": etl_config.job_name,
            "records_count": 0,
            "status": "EXCEPTION",
            "bucket_name": str(row['bucket_name']),
            "initial_time_stamp": datetime.datetime.now(pytz.timezone(etl_config.timezone_param)),
            "redshiftConnDetails": redshiftConnDetails,
            "table_name": str(row['tablename']),
            "exception_description": str(e),
            "jobconfig": etl_config.glueContext.sparkContext.getConf().getAll()
        }
        logger.info('{}'.format(exception_dict))
        return exception_dict
    except Exception as e:
        logger.error(str(e))


def create_connection(exception_dict, etl_config: ETLConfig):
    """
    Params:
        exception_dict:
        redshift_schema_name:
        redshift_audit_table_name:
        redshift_etl_master_table_name:
        athena_db_name:

    Returns:
        exception_dict:
    """
    conn_pg8000 = dbapi.connect(database=str(exception_dict["redshiftConnDetails"]['database']),
                                host=str(
                                    exception_dict["redshiftConnDetails"]['host']),
                                port=int(
                                    exception_dict["redshiftConnDetails"]['port']),
                                user=str(
                                    exception_dict["redshiftConnDetails"]['user']),
                                password=str(exception_dict["redshiftConnDetails"]['password']))
    exception_dict["conn_pg8000"] = conn_pg8000

    audit_utility_obj = AuditUtility(exception_dict, etl_config)
    exception_dict = audit_utility_obj.audit_entry()
    return exception_dict


def exception_records_process(exception_dict, etl_config: ETLConfig, e=None):
    """
    Params:
    exception_dict:
    redshift_schema_name:
    redshift_audit_table_name:
    redshift_etl_master_table_name:
    athena_db_name:

    job_id:
    glueContext:
    db_name:
    job_name:
    """
    try:
        sql_query = '''select id,groupid,tablename,schemaname,source,loadtype,incrementalcolumn,active,createdate,
                    cast(startdatetime as timestamp(3)) as startdatetime,cast(enddatetime as timestamp(3)) as enddatetime,sql_query,
                    partition_column,priority,pk_columns,merge_query,bucket_name,offset_value,audit from {iceberg_db}.{iceberg_etl_master_table_name}  
                    where groupid = {job_id} and active = 1 order by Priority'''

        sql_query = sql_query.format(job_id=etl_config.job_id, iceberg_db=etl_config.iceberg_db,
                                     iceberg_etl_master_table_name=etl_config.iceberg_etl_master_table_name)

        exception_pandas = wr.athena.read_sql_query(
            sql_query, database=etl_config.iceberg_db)
        for index, row in exception_pandas.iterrows():
            logger.info(" row: **** {}".format(row))

            exception_dict = {
                "JOBNAME": etl_config.job_name,
                "records_count": 0,
                "status": "EXCEPTION",
                "initial_time_stamp": datetime.datetime.now(pytz.timezone(etl_config.timezone_param)),
                "bucket_name": str(row['bucket_name']),
                "table_name": str(row['tablename']),
                "inventory_table_name": str(row['tablename']),
                "exception_description": str(e),
                "jobconfig": etl_config.glueContext.sparkContext.getConf().getAll(),
                "chunk_list_length": 0,
                "id": row['id'],
                "startdatetime": str(datetime.datetime.now(pytz.timezone(etl_config.timezone_param)) + timedelta(days=1))
            }
        logger.info(" exception_dict: ***********: {}".format(exception_dict))

        audit_utility_obj = AuditUtility(exception_dict, etl_config)

        iceberg_audit_entry_res = audit_utility_obj.audit_entry_iceberg()

        logger.info(" iceberg_audit_entry_res: : {}".format(str(iceberg_audit_entry_res)))

        '''
        audit_entry_iceberg_obj = AuditUtility(exception_dict,etl_config)
        iceberg_etl_master_entry_res = audit_entry_iceberg_obj.Update_ETL_Master_Entry_Iceberg()
        print(" iceberg_etl_master_entry_res: "+str(iceberg_etl_master_entry_res))
        logger.info("*****ERROR *********** 9 {}".format(e))
        '''
    except Exception as e:
        logger.error('error occurred ')
        logger.error(str(e))
