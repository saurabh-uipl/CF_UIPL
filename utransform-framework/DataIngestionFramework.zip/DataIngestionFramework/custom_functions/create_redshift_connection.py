from pg8000 import dbapi
import logging
from ..src.etl_config import ETLConfig

logger = logging.getLogger('my_logger')


def create_redshift_connection(redshift_conn_details, redshift_secret_name):
    """
    Establishes a connection to Redshift based on the provided job details.

    Args:
    redshift_conn_details:
    redshift_secret_name

    Returns:
    None: If the connection to Redshift could not be established.

    """
    try:
        success = True
        if redshift_secret_name != 'NA':

            conn_pg8000 = dbapi.connect(database=str(redshift_conn_details['database']),
                                        host=str(
                                            redshift_conn_details['host']),
                                        port=int(
                                            redshift_conn_details['port']),
                                        user=str(
                                            redshift_conn_details['user']),
                                        password=str(redshift_conn_details['password']))

            return conn_pg8000, success
        else:
            conn_pg8000 = None
            return conn_pg8000, success
    except Exception as e:
        logger.error(str(e))
        conn_pg8000 = None
        success = False
        return conn_pg8000, success
