import datetime
import pytz
from ..start_ingestion.start_ingestion import start_ingestion
import logging
from ..src.etl_config import ETLConfig
from .insert_failed_tables import add_failed_table_entry

logger = logging.getLogger("my_logger")


def full_load(job_dict, source_conn_details, etl_config: ETLConfig):
    """
    Args:
        job_dict:
       source_conn_details
       etl_config


    """
    try:
        sql_query = "(" + job_dict["SQL_Query"] + ") as t"
        job_dict["SQL_Query"] = sql_query



        res, is_error = start_ingestion(job_dict, source_conn_details, etl_config)
        logger.info(" res: *** {}".format(res))

        if res > 0:
            logger.info(" res > 0 ")
            table_name_last_char = job_dict["table_name"][len(job_dict["table_name"]) - 1]
            logger.info("table_name_last_char: " + str(table_name_last_char))
            if table_name_last_char == '/':
                updated_table_name = job_dict["table_name"].split('/')[-2]
            else:
                updated_table_name = job_dict["table_name"].split('/')[-1]

            sns_dict = {
                "Jod_Id": job_dict["JOBID"],
                "Job_Name": job_dict["JOBNAME"],
                "Load_Type": job_dict["load_type"],
                "status": "succeed",
                "Table_Name": updated_table_name,
                "Start_Time": str(job_dict["initial_time_stamp"]),
                "End_Time": str(datetime.datetime.now(pytz.timezone(etl_config.timezone_param))),
                "Execution_Time": str(
                    datetime.datetime.now(pytz.timezone(etl_config.timezone_param)) - job_dict["initial_time_stamp"]),
                "Total_Records_Pulled": job_dict["records_count"],
                "Source_Data_Pulled_From": "",
                "Source_Data_Pulled_Until": ""
            }

            # logger.info('sns_list_success: {}'.format(etl_config.sns_list_success))
            etl_config.sns_list_success.append(sns_dict)
            # logger.info("sns_list_success: ****** {}".format(etl_config.sns_list_success))

        else:
            logger.info(" res is 0 ")
            logger.info(" sns_list_failure : ***** {}".format(etl_config.sns_list_failure))
            etl_config.sns_list_failure.append(job_dict["table_name"])
            #### Add Failed Table Details in Audit Table
            add_failed_table_entry(job_dict, etl_config, logger, is_error)

        return {
            "success": etl_config.sns_list_success,
            "failure": etl_config.sns_list_failure,
            "job_dict": job_dict
        }
    except Exception as e:
        logger.error('Error in full load ')
        logger.error(str(e))

        return {
            "success": etl_config.sns_list_success,
            "failure": etl_config.sns_list_failure,
            "job_dict": job_dict
        }
