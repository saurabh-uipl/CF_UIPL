#import pysftp
import re
from datetime import datetime
from ..src.etl_config import ETLConfig
import json
import logging
import paramiko
import pandas
from pyspark.sql.functions import col, lit

logger = logging.getLogger("my_logger")


def create_sftp_df(spark, source_conn_details, files_and_timestamp, job_dict):
    logger.info(" Executing create_sftp_df ......")
    try:
        host, port = source_conn_details['host'], 22
        transport = paramiko.Transport((host, port))

        username, password = source_conn_details['username'], source_conn_details['password']
        transport.connect(None, username, password)

        sftp = paramiko.SFTPClient.from_transport(transport)

        sftp_file = sftp.open(files_and_timestamp['file_path'])

        sftp_pandas_df = pandas.read_csv(sftp_file)
        sftp_df = spark.createDataFrame(sftp_pandas_df)
        sftp_df = sftp_df.withColumn("modified_timestamp", lit(files_and_timestamp['mtimestamp']))
        sftp_df.show(1, False)
        return sftp_df
    except Exception as e:
        logger.error(str(e))
        logger.error(" Errro Occurred In create_sftp_df")
        return None


def get_incremental_files(job_dict, source_conn_details):
    '''
    try:
        start_date_time_obj = None
        if job_dict['load_type'].lower() in ['merge', 'incremental']:
            start_date_time_str = job_dict['startdatetime'][0:19]
            start_date_time_obj = datetime.strptime(start_date_time_str, '%Y-%m-%d %H:%M:%S')
            logger.info("start_date_time_str:  ")
            logger.info(start_date_time_obj)

        cnopts = pysftp.CnOpts()
        cnopts.hostkeys = None
        incr_file_list_and_time = []
        table_name = job_dict['table_name']
        host = source_conn_details['host']
        username = source_conn_details['username']
        password = source_conn_details['password']

        with pysftp.Connection(host=host, username=username, password=password, cnopts=cnopts) as sftp:
            logger.info(" Changing Dir ...")
            logger.info(table_name)
            sftp.chdir(table_name)
            list_dir = sftp.listdir()
            for fileName in list_dir:
                filteredFileName = re.search("\.csv$", fileName)
                logger.info("filteredFileName: ")
                logger.info(filteredFileName)
                if filteredFileName:
                    filePath = table_name + fileName
                    logger.info("fileName: " + str(fileName))
                    mtime = sftp.stat(filePath).st_mtime
                    file_modify_timestamp = datetime.utcfromtimestamp(mtime)
                    logger.info("fileModifyDate: ")
                    logger.info(str(file_modify_timestamp))
                    if job_dict['load_type'].lower() in ['merge', 'incremental']:
                        if file_modify_timestamp > start_date_time_obj:
                            logger.info(" Adding This File In List ....")
                            filePath = table_name + fileName
                            logger.info(" Final FilePath: ")
                            logger.info(filePath)
                            file_details = {'file_path': filePath, "mtimestamp": file_modify_timestamp}
                            incr_file_list_and_time.append(file_details)
                        else:
                            logger.info(" Skip This File ......")
                    else:
                        logger.info(" Adding This File In List ....")
                        filePath = table_name + fileName
                        logger.info(" Final FilePath: ")
                        logger.info(filePath)
                        file_details = {'file_path': filePath, "mtimestamp": file_modify_timestamp}
                        incr_file_list_and_time.append(file_details)

        return incr_file_list_and_time
    except Exception as e:
        logger.error(str(e))
        return None
    '''
    return []

def read_from_sftp_csv(spark, job_dict, source_conn_details, etl_config: ETLConfig):
    logger.info(" Executing read_from_sftp")
    try:
        union_df = None
        i = 1
        incr_file_list_and_time = get_incremental_files(job_dict, source_conn_details)
        for files_and_timestamp in incr_file_list_and_time:
            logger.info(" i = " + str(i))
            logger.info("Processing file: " + str(files_and_timestamp))
            if i == 1:
                df = create_sftp_df(spark, source_conn_details, files_and_timestamp, job_dict)
                union_df = df
            else:
                df = create_sftp_df(spark, source_conn_details, files_and_timestamp, job_dict)
                union_df = union_df.union(df)
            i = i + 1

        logger.info("Updating Table Name ......")
        job_dict['sftp_table_name'] = job_dict['table_name']
        table_name_values = job_dict['table_name'].split('/')
        table_name = table_name_values[-1]
        if len(table_name) < 2:
            table_name = table_name_values[-2]
        logger.info(" Updated Table Name: ")
        logger.info(table_name)
        job_dict['table_name'] = table_name

        return union_df, job_dict, True, None
    except Exception as e:
        logger.error(str(e))
        return None, job_dict, False, str(e)
