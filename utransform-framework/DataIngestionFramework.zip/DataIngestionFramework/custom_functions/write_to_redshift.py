import boto3
import json
import pyspark
from pyspark.conf import SparkConf
# from pyspark.context import SparkContext
# from awsglue.context import GlueContext
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import StructField, StructType, StringType, LongType, IntegerType, ArrayType, DataType
from .insert_failed_tables import add_failed_table_entry
from ..src.etl_config import ETLConfig
import logging
import pg8000 as dbapi
from ..analytics_utilities.secrets_manager import SecretsManager
import time
import json

logger = logging.getLogger('my_logger')


def get_existing_table_col_order(df_final, job_dict, etl_config, spark, redshift_conn_details):
    try:
        logger.info("Executing get_existing_table_col_order")
        rs_existing_table_query = " ( select * from {DEST_RS_SCHEMA}.{DEST_RS_TABLE} where 1 <> 1 ) t"
        rs_existing_table_query = rs_existing_table_query.format(DEST_RS_SCHEMA=etl_config.redshift_dest_schema, DEST_RS_TABLE=job_dict["table_name"])
        logger.info("rs_existing_table_query: ")
        logger.info(rs_existing_table_query)
        rs_existing_table_df = spark.read \
            .format("jdbc") \
            .option("url", redshift_conn_details["jdbcURL"]) \
            .option("dbtable", rs_existing_table_query) \
            .option("user", redshift_conn_details["user"]) \
            .option("password", redshift_conn_details["password"]) \
            .load()
        col_list = rs_existing_table_df.columns
        col_comm_sep_list = ' , '.join(col_list)
        logger.info("col_comm_sep_list: ")
        logger.info(col_comm_sep_list)
        return col_comm_sep_list
    except Exception as e:
        logger.error("Error in get_existing_table_col_order")
        logger.error(str(e))
        return None


def rs_add_columns_from_list(col_name_list, col_type_list, non_matched_col_list, etl_config, job_dict, operation):
    try:
        logger.info("Executing rs_add_columns_from_list")
        conn = job_dict["conn_pg8000"]
        conn.autocommit = True
        curr = conn.cursor()
        if operation == 'ADD':
            alter_add_col_base_sql = "alter table {DEST_RS_SCHEMA}.{DEST_RS_TABLE} add column {COL_NAME}  {DATA_TYPE} default NULL ;"
            # alter_add_col_staging_sql = "alter table {DEST_RS_SCHEMA}.{DEST_RS_TABLE}_staging add column {COL_NAME}  {DATA_TYPE} default NULL ;"
            for col_name in non_matched_col_list:
                logger.info("Adding columns")
                # get index of col_name in col_name_list and type in col_type_list
                col_name_index = col_name_list.index(col_name)
                col_type = col_type_list[col_name_index]
                if col_type.lower() == 'string':
                    col_type = 'varchar(max)'
                alter_add_col_base_sql = alter_add_col_base_sql.format(DEST_RS_SCHEMA=etl_config.redshift_dest_schema, DEST_RS_TABLE=job_dict["table_name"], COL_NAME=col_name, DATA_TYPE=col_type)
                logger.info(alter_add_col_base_sql)
                curr.execute(alter_add_col_base_sql)
                # alter_add_col_staging_sql = alter_add_col_staging_sql.format(DEST_RS_SCHEMA=etl_config.redshift_dest_schema, DEST_RS_TABLE=job_dict["table_name"], COL_NAME=col_name, DATA_TYPE=col_type)
                # logger.info(alter_add_col_staging_sql)
                # curr.execute(alter_add_col_staging_sql)
                logger.info("Query ran successfully on Redshift")
        if operation == 'DROP':
            drop_col_base_sql = "alter table {DEST_RS_SCHEMA}.{DEST_RS_TABLE} drop column {COL_NAME};"
            # drop_col_staging_sql = "alter table {DEST_RS_SCHEMA}.{DEST_RS_TABLE}_staging drop column {COL_NAME};"
            for col_name in non_matched_col_list:
                logger.info("Dropping columns")
                drop_col_base_sql = drop_col_base_sql.format(DEST_RS_SCHEMA=etl_config.redshift_dest_schema, DEST_RS_TABLE=job_dict["table_name"], COL_NAME=col_name)
                logger.info(drop_col_base_sql)
                curr.execute(drop_col_base_sql)

                # drop_col_staging_sql = drop_col_staging_sql.format(DEST_RS_SCHEMA=etl_config.redshift_dest_schema, DEST_RS_TABLE=job_dict["table_name"], COL_NAME=col_name)
                # logger.info(drop_col_staging_sql)
                # curr.execute(drop_col_staging_sql)

                logger.info("Query ran successfully on Redshift")
    except Exception as e:
        logger.error("Error in rs_add_columns_from_list")
        logger.error(str(e))


def rs_df_columns_to_list(json_schema):
    column_name_list = []
    column_data_type_list = []
    fields = json.loads(json_schema)['fields']
    for field in fields:
        col_name = field['name']
        col_data_type = field["type"]
        column_name_list.append(col_name)
        column_data_type_list.append(col_data_type)
    logger.info(column_name_list)
    logger.info(column_data_type_list)
    return column_name_list, column_data_type_list


def redshift_add_missing_columns(df_final, job_dict, etl_config, spark, redshift_conn_details):
    try:
        logger.info("Executing redshift_add_missing_columns")
        rs_existing_table_query = " ( select * from {DEST_RS_SCHEMA}.{DEST_RS_TABLE} where 1 <> 1 ) t"
        rs_existing_table_query = rs_existing_table_query.format(DEST_RS_SCHEMA=etl_config.redshift_dest_schema, DEST_RS_TABLE=job_dict["table_name"])
        logger.info("rs_existing_table_query: ")
        logger.info(rs_existing_table_query)
        rs_existing_table_df = spark.read \
            .format("jdbc") \
            .option("url", redshift_conn_details["jdbcURL"]) \
            .option("dbtable", rs_existing_table_query) \
            .option("user", redshift_conn_details["user"]) \
            .option("password", redshift_conn_details["password"]) \
            .load()
        logger.info("columns of existing table")
        exist_table_col_name_list, exist_table_col_type_list = rs_df_columns_to_list(rs_existing_table_df.schema.json())
        logger.info("columns of incoming data")
        incoming_df_col_name_list, incoming_df_col_type_list = rs_df_columns_to_list(df_final.schema.json())

        newly_added_column_list = list(set(incoming_df_col_name_list).difference(exist_table_col_name_list))
        logger.info("newly_added_column_list: ")
        logger.info(newly_added_column_list)

        rs_add_columns_from_list(incoming_df_col_name_list, incoming_df_col_type_list, newly_added_column_list, etl_config, job_dict, operation='ADD')

        deleted_column_list = list(set(exist_table_col_name_list).difference(incoming_df_col_name_list))
        logger.info("column list which has/have been deleted from source: ")
        logger.info(deleted_column_list)

        rs_add_columns_from_list(exist_table_col_name_list, exist_table_col_type_list, deleted_column_list, etl_config, job_dict, operation='DROP')
    except Exception as e:
        logger.error("Error in redshift_add_missing_columns")
        logger.error(str(e))


def execute_redshift_sql_statement(job_dict, sql_query):
    try:
        conn = job_dict["conn_pg8000"]
        conn.autocommit = True
        curr = conn.cursor()
        curr.execute(sql_query)
        logger.info("Query ran successfully on Redshift")
        return True
    except Exception as e:
        logger.error("Error in execute_redshift_sql_statement")
        logger.error(str(e))
        return False


def create_redshift_staging_table(job_dict, etl_config):
    try:
        conn = job_dict["conn_pg8000"]
        conn.autocommit = True
        curr = conn.cursor()
        create_table_sql = "CREATE TABLE {REDSHIFT_DEST_SCHEMA}.{REDSHIFT_DEST_TABLE}_staging (LIKE {REDSHIFT_DEST_SCHEMA}.{REDSHIFT_DEST_TABLE});"
        create_table_sql = create_table_sql.format(REDSHIFT_DEST_SCHEMA=etl_config.redshift_dest_schema, REDSHIFT_DEST_TABLE=job_dict["table_name"])
        logger.info("create_table_sql: ")
        logger.info(create_table_sql)
        create_table_res = curr.execute(create_table_sql)
        logger.info("create_table_res: ")
        logger.info(create_table_res)
        return True
    except Exception as e:
        logger.error("Error while creating staging table in Redshift")
        logger.error(str(e))
        return False


def redshift_table_exist(job_dict, etl_config, rs_table_name):
    try:
        row_count = 0
        conn = job_dict["conn_pg8000"]
        conn.autocommit = True
        curr = conn.cursor()
        rs_table_check_query = ''' SELECT count(*) row_count FROM pg_tables  where schemaname = '{RS_DEST_SCHEMA_NAME}'  and upper(tablename) = '{RS_DEST_TABLE_NAME}'  '''
        rs_table_check_query = rs_table_check_query.format(RS_DEST_SCHEMA_NAME=etl_config.redshift_dest_schema, RS_DEST_TABLE_NAME=rs_table_name.upper())
        logger.info("rs_table_check_query: ")
        logger.info(rs_table_check_query)
        redshift_table_check_query_response = curr.execute(rs_table_check_query)
        row = curr.fetchone()
        row_count = row[0]
        logger.info("row_count: ")
        logger.info(row_count)
        if row_count > 0:
            return True
        else:
            return False
    except Exception as e:
        logger.error("Error while checking redshift table exist or not ")
        logger.error(str(e))
        return False


def write_to_redshift(df_final, job_dict, etl_config: ETLConfig, spark):
    try:
        rs_secrets = SecretsManager(etl_config.redshift_secret_name, etl_config)
        secret_value, success = rs_secrets.get_secret_name()
        redshift_conn_details = secret_value[1]
        df_final = df_final.dropDuplicates()
        redshift_table_exist_res = redshift_table_exist(job_dict, etl_config, job_dict["table_name"])
        logger.info("redshift_table_exist_res: ")
        logger.info(redshift_table_exist_res)
        if job_dict['load_type'].lower() == 'full load':
            logger.info("Load Type Is Full Load")
            df_final.write \
                .format("jdbc") \
                .option("url", redshift_conn_details["jdbcURL"]) \
                .option("dbtable", str(etl_config.redshift_dest_schema) + "." + job_dict["table_name"]) \
                .option("user", redshift_conn_details["user"]) \
                .option("password", redshift_conn_details["password"]) \
                .option("aws_iam_role", etl_config.rs_iam_role_arn) \
                .option("tempdir", etl_config.rs_temp_bucket_uri) \
                .mode("overwrite") \
                .save()
            logger.info("Data has been written into Redshift table.....")
            logger.info(job_dict["table_name"])
            return True, None
        else:
            if job_dict['load_type'].lower() == 'merge':
                logger.info("load type is merge load ...")
                staging_table = job_dict["table_name"] + "_staging"
                # redshift_staging_table_exist_res = redshift_table_exist(job_dict, etl_config, staging_table)
                redshift_base_table_exist_res = redshift_table_exist(job_dict, etl_config, job_dict["table_name"])

                if redshift_base_table_exist_res is False:
                    logger.info("Base table does not exist in Redshift, so create base table and write the data into base table")
                    logger.info("An empty staging table also need to be created ")
                    df_final.write \
                        .format("jdbc") \
                        .option("url", redshift_conn_details["jdbcURL"]) \
                        .option("dbtable", str(etl_config.redshift_dest_schema) + "." + job_dict["table_name"]) \
                        .option("user", redshift_conn_details["user"]) \
                        .option("password", redshift_conn_details["password"]) \
                        .option("aws_iam_role", etl_config.rs_iam_role_arn) \
                        .option("tempdir", etl_config.rs_temp_bucket_uri) \
                        .mode("overwrite") \
                        .save()
                    logger.info("Data has been written into Redshift table ")
                    logger.info("Creating an empty staging table")

                    create_redshift_staging_table_res = create_redshift_staging_table(job_dict, etl_config)
                    if create_redshift_staging_table_res:
                        logger.info("An empty staging table has been created")
                    else:
                        logger.info("An issue while creating an empty staging table")

                    return True, None
                else:
                    logger.info("Base table exists in Redshift....")
                    logger.info("check staging table exist or not ")
                    redshift_staging_table_exist_res = redshift_table_exist(job_dict, etl_config, staging_table)
                    if redshift_staging_table_exist_res is True:
                        logger.info("Staging table also exists in Redshift")
                        # Call add missing column function
                        redshift_add_missing_columns(df_final, job_dict, etl_config, spark, redshift_conn_details)
                        # First write the data into Staging and then merge into base table
                        # post_query_sql = "MERGE INTO {RS_DEST_SCHEMA_NAME}.{RS_DEST_TABLE_NAME}  USING {RS_DEST_SCHEMA_NAME}.{RS_DEST_TABLE_NAME}_staging ON {RS_DEST_TABLE_NAME}.{PKEY} = {RS_DEST_TABLE_NAME}_staging.{PKEY} REMOVE DUPLICATES; "
                        post_query_sql = " delete from {RS_DEST_SCHEMA_NAME}.{RS_DEST_TABLE_NAME} where {PKEY} in (select {PKEY} from  {RS_DEST_SCHEMA_NAME}.{RS_DEST_TABLE_NAME}_staging ); insert into {RS_DEST_SCHEMA_NAME}.{RS_DEST_TABLE_NAME}  select * from {RS_DEST_SCHEMA_NAME}.{RS_DEST_TABLE_NAME}_staging; "
                        post_query_sql = post_query_sql.format(RS_DEST_SCHEMA_NAME=etl_config.redshift_dest_schema, RS_DEST_TABLE_NAME=job_dict["table_name"], PKEY=job_dict["pk_column"])
                        logger.info("post_query_sql: ")
                        logger.info(post_query_sql)
                        logger.info("Writing data into redshift staging table")
                        df_final.write \
                            .format("jdbc") \
                            .option("url", redshift_conn_details["jdbcURL"]) \
                            .option("dbtable", str(etl_config.redshift_dest_schema) + "." + job_dict["table_name"] + "_staging") \
                            .option("user", redshift_conn_details["user"]) \
                            .option("password", redshift_conn_details["password"]) \
                            .option("aws_iam_role", etl_config.rs_iam_role_arn) \
                            .option("tempdir", etl_config.rs_temp_bucket_uri) \
                            .option("postactions", post_query_sql) \
                            .mode("overwrite") \
                            .save()
                        logger.info("Data has been written successfully in Redshift staging table.......")
                        logger.info("delete old data from base table and write update data into base table")
                        delete_base_table_query = "delete from {RS_DEST_SCHEMA_NAME}.{RS_DEST_TABLE_NAME} where {PKEY} in (select {PKEY} from  {RS_DEST_SCHEMA_NAME}.{RS_DEST_TABLE_NAME}_staging )"
                        delete_base_table_query = delete_base_table_query.format(RS_DEST_SCHEMA_NAME=etl_config.redshift_dest_schema, RS_DEST_TABLE_NAME=job_dict["table_name"],
                                                                                 PKEY=job_dict["pk_column"])
                        logger.info("delete_base_table_query: ")
                        logger.info(delete_base_table_query)
                        execute_redshift_sql_statement_res = execute_redshift_sql_statement(job_dict, delete_base_table_query)
                        logger.info("execute_redshift_sql_statement_res: ")
                        logger.info(execute_redshift_sql_statement_res)
                        # Get Order Of Redshift Table Columns
                        rs_table_order = get_existing_table_col_order(df_final, job_dict, etl_config, spark, redshift_conn_details)
                        insert_base_table_query = "insert into {RS_DEST_SCHEMA_NAME}.{RS_DEST_TABLE_NAME} select {COL_LIST} from {RS_DEST_SCHEMA_NAME}.{RS_DEST_TABLE_NAME}_staging"
                        insert_base_table_query = insert_base_table_query.format(RS_DEST_SCHEMA_NAME=etl_config.redshift_dest_schema, RS_DEST_TABLE_NAME=job_dict["table_name"], COL_LIST = rs_table_order)
                        logger.info("insert_base_table_query: ")
                        logger.info(insert_base_table_query)
                        execute_redshift_sql_statement(job_dict, insert_base_table_query)
                        return True, None
                    else:
                        logger.info("Staging table does not exist in Redshift, need to create ")
                        create_redshift_staging_table_res = create_redshift_staging_table(job_dict, etl_config)
                        logger.info("create_redshift_staging_table_res: ")
                        logger.info(create_redshift_staging_table_res)
                        ## call add mising column function
                        redshift_add_missing_columns(df_final, job_dict, etl_config, spark, redshift_conn_details)
                        # First write the data into Staging and then merge into base table
                        # post_query_sql = "MERGE INTO {RS_DEST_SCHEMA_NAME}.{RS_DEST_TABLE_NAME}  USING {RS_DEST_SCHEMA_NAME}.{RS_DEST_TABLE_NAME}_staging ON {RS_DEST_TABLE_NAME}.{PKEY} = {RS_DEST_TABLE_NAME}_staging.{PKEY} REMOVE DUPLICATES; "
                        post_query_sql = " delete from {RS_DEST_SCHEMA_NAME}.{RS_DEST_TABLE_NAME} where {PKEY} in (select {PKEY} from  {RS_DEST_SCHEMA_NAME}.{RS_DEST_TABLE_NAME}_staging ); insert into {RS_DEST_SCHEMA_NAME}.{RS_DEST_TABLE_NAME}  select * from {RS_DEST_SCHEMA_NAME}.{RS_DEST_TABLE_NAME}_staging; "
                        post_query_sql = post_query_sql.format(RS_DEST_SCHEMA_NAME=etl_config.redshift_dest_schema, RS_DEST_TABLE_NAME=job_dict["table_name"], PKEY=job_dict["pk_column"])
                        logger.info("post_query_sql: ")
                        logger.info(post_query_sql)
                        logger.info("Writing data into redshift staging table")
                        df_final.write \
                            .format("jdbc") \
                            .option("url", redshift_conn_details["jdbcURL"]) \
                            .option("dbtable", str(etl_config.redshift_dest_schema) + "." + job_dict["table_name"] + "_staging") \
                            .option("user", redshift_conn_details["user"]) \
                            .option("password", redshift_conn_details["password"]) \
                            .option("aws_iam_role", etl_config.rs_iam_role_arn) \
                            .option("tempdir", etl_config.rs_temp_bucket_uri) \
                            .option("postactions", post_query_sql) \
                            .mode("overwrite") \
                            .save()
                        logger.info("Data has been written successfully in Redshift staging table...")

                        logger.info("delete old data from base table and write update data into base table")
                        delete_base_table_query = "delete from {RS_DEST_SCHEMA_NAME}.{RS_DEST_TABLE_NAME} where {PKEY} in (select {PKEY} from  {RS_DEST_SCHEMA_NAME}.{RS_DEST_TABLE_NAME}_staging )"
                        delete_base_table_query = delete_base_table_query.format(RS_DEST_SCHEMA_NAME=etl_config.redshift_dest_schema, RS_DEST_TABLE_NAME=job_dict["table_name"],
                                                                                 PKEY=job_dict["pk_column"])
                        logger.info("delete_base_table_query: ")
                        logger.info(delete_base_table_query)
                        execute_redshift_sql_statement_res = execute_redshift_sql_statement(job_dict, delete_base_table_query)
                        logger.info("execute_redshift_sql_statement_res: ")
                        logger.info(execute_redshift_sql_statement_res)
                        rs_table_order = get_existing_table_col_order(df_final, job_dict, etl_config, spark, redshift_conn_details)
                        insert_base_table_query = "insert into {RS_DEST_SCHEMA_NAME}.{RS_DEST_TABLE_NAME} select {COL_LIST} from {RS_DEST_SCHEMA_NAME}.{RS_DEST_TABLE_NAME}_staging"
                        insert_base_table_query = insert_base_table_query.format(RS_DEST_SCHEMA_NAME=etl_config.redshift_dest_schema, RS_DEST_TABLE_NAME=job_dict["table_name"], COL_LIST = rs_table_order)
                        logger.info("insert_base_table_query: ")
                        logger.info(insert_base_table_query)
                        execute_redshift_sql_statement(job_dict, insert_base_table_query)

                        return True, None
            else:
                logger.info("Load type is incremental")
                df_final.write \
                    .format("jdbc") \
                    .option("url", redshift_conn_details["jdbcURL"]) \
                    .option("dbtable", str(etl_config.redshift_dest_schema) + "." + job_dict["table_name"]) \
                    .option("user", redshift_conn_details["user"]) \
                    .option("password", redshift_conn_details["password"]) \
                    .option("aws_iam_role", etl_config.rs_iam_role_arn) \
                    .option("tempdir", etl_config.rs_temp_bucket_uri) \
                    .mode("append") \
                    .save()
                logger.info("Data has been written successfully in Redshift table.")
                return True, None

    except Exception as e:
        logger.error("Error while writing the data into Redshift table")
        logger.error(str(e))
        return False, str(e)
