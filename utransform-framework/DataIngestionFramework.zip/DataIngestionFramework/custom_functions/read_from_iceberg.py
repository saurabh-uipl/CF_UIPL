import awswrangler as wr
import pytz
import datetime
from ..src.etl_config import ETLConfig
import logging
import boto3


class IceBerg:
    def __init__(self, etl_config: ETLConfig):
        self.logger = logging.getLogger("my_logger")
        self.etl_config = etl_config

        '''
        Args:
        job_id:
        glueContext:
        redshift_secret_name:
        
        region_name:
        job_name:
        db_name:
        '''

    def read_from_iceberg(self):
        """
        Executes an ETL job in Iceberg mode
        This method performs the following steps:
        1. Generates a log message indicating the start of the job in Iceberg mode.
        2. Prints the log message to the console and appends it to a string builder.
        3. Executes a SQL query to retrieve data from the 'etl_master' table based on specified conditions.
        4. Reads the result of the SQL query into a pandas DataFrame.
        5. Prints the first few rows of the DataFrame.


        Returns:
            df_pandas:
        """

        try:
            success = True

            self.logger.info("*** job started")

            sql_query = '''SELECT id, groupid, tablename, business_unit,schemaname, source, loadtype, 
                        incrementalcolumn, active, createdate,
                        CAST(startdatetime AS timestamp(3)) AS startdatetime,
                        CAST(enddatetime AS timestamp(3)) AS enddatetime,
                        sql_query, partition_column, priority, pk_columns, merge_query,
                        bucket_name, offset_value, audit, destination_type, json_flatten, sftp_file_path, sftp_file_date_columns, pk_col_list, validation_rules, part_col_int, data_validation_date_column, part_lower_bound, part_upper_bound, num_partitions, data_validation_active
                        FROM {iceberg_db}.{iceberg_etl_master_table_name}
                        WHERE groupid = {job_id} AND active = 1
                        ORDER BY priority'''

            """
            sql_query = '''SELECT * 
                                    FROM {iceberg_db}.{iceberg_etl_master_table_name}
                                    WHERE groupid = {job_id} AND active = 1
                                    ORDER BY priority'''
            """

            sql_query = sql_query.format(iceberg_db=self.etl_config.iceberg_db,
                                         iceberg_etl_master_table_name=self.etl_config.iceberg_etl_master_table_name,
                                         job_id=self.etl_config.job_id)
            self.logger.info(" Query: ")
            self.logger.info(str(sql_query))
            self.logger.info("***********Executing query on athena ************************")
            boto3_session = boto3.Session(region_name= self.etl_config.region_name)
            df_pandas = wr.athena.read_sql_query(
                sql_query, database=self.etl_config.iceberg_db, boto3_session=boto3_session, s3_output = self.etl_config.rs_temp_bucket_uri  )
            self.logger.info("******************df_pandas: ")
            self.logger.info(df_pandas)

            return df_pandas, success
        except Exception as e:
            self.logger.error(str(e))
            df_pandas = None
            success = False
            return df_pandas, success
