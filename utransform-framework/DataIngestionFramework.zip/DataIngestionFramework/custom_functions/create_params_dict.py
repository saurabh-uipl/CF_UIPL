import datetime
import pytz
import pandas as pd
import logging
from ..src.etl_config import ETLConfig

logger = logging.getLogger("my_logger")

def safe_int(value, default=None):
    return default if pd.isna(value) else int(value)

def create_params_dict(row, redshift_conn_details, etl_config: ETLConfig):
    """
     Creates a job dictionary based on the provided row data.

    Args:
        redshift_conn_details:
        row:
       etl_config

    Returns:
        job_dict:
    """

    try:
        logger.info(" Display timezone ....")
        logger.info(etl_config.timezone_param)
        success = True
        logger.info(" Creating job_dict ......")
        logger.info(" Table Data Row: ")
        logger.info(str(row))
        bucket_uri = row.get("bucket_name")

        if pd.isna(bucket_uri):
            temp_bucket = None
        else:
            bucket_uri = str(bucket_uri)
            if bucket_uri.startswith("s3://"):
                bucket_uri = bucket_uri.replace("s3://", "")
            temp_bucket = bucket_uri.split("/")[0]

        job_dict = {
            "initial_time_stamp": datetime.datetime.now(pytz.timezone(etl_config.timezone_param)),
            "id": str(row['id']),
            "table_name": str(row['tablename']),
            "schema_name": str(row['schemaname']),
            "source": str(row['source']).lower(),
            "load_type": str(row['loadtype']).lower(),
            "startdatetime": str(row['startdatetime']),
            "enddatetime": str(row['enddatetime']),
            "SQL_Query": str(row['sql_query']).replace(str(row['tablename']).lower(),
                                                       str(row['tablename'])),
            "Partition_Column": str(row['partition_column']).split(","),
            "Partition_Year": str(row['startdatetime'].year),
            "merge_query": str(row['merge_query']),
            "JOBID": etl_config.job_id,
            "JOBNAME": etl_config.job_name,
            "redshiftConnDetails": redshift_conn_details,
            "SOURCE_SECRET_NAME": etl_config.source_secret_name,
            "bucket_name": str(row['bucket_name']),
            "temp_bucket": temp_bucket,  # ✅ correct placement
            "incremental_value": str(row['offset_value']),
            "is_audit": int(row['audit']),
            "incremental_column": row['incrementalcolumn'],
            "region_name": etl_config.region_name,
            "status": "SUCCESS",
            "exception_description": " ",
            "jobconfig": etl_config.glueContext.sparkContext.getConf().getAll(),
            "inventory": etl_config.inventory_database,
            "chunk_size": etl_config.data_chunk_size,
            "pk_column": str(row['pk_columns']),
            "iceberg_db": etl_config.iceberg_db,
            "destination_type": str(row['destination_type']),
            "business_unit": str(row['business_unit']),
            'json_flatten': str(row['json_flatten']),
            'sftp_file_path': str(row['sftp_file_path']),
            'sftp_file_date_columns': str(row['sftp_file_date_columns']),
            'pk_col_list': str(row['pk_col_list']),
            'part_col_int': str(row['part_col_int']),
            'validation_rules' : str(row['validation_rules']),
            'part_lower_bound' : safe_int(row['part_lower_bound']),
            'part_upper_bound': safe_int(row['part_upper_bound']),
            'num_partitions': safe_int(row['num_partitions'])
        }

        logger.info("table_name: "+str(row['tablename']))
        logger.info("load_type: " + str(row['loadtype']).lower())
        logger.info("startdatetime: " + str(row['startdatetime']))
        logger.info("SQL_Query: " + str(row['sql_query']).replace(str(row['tablename']).lower(),
                                                       str(row['tablename'])))
        logger.info("pk_column: " + str(row['pk_columns']))
        logger.info("json_flatten: " + str(row['json_flatten']))
        logger.info("merge_query: " + str(row['merge_query']))

        logger.info(" incremental_column: {}".format(job_dict['incremental_column']))

        logger.info(" incremental_value: {}".format(job_dict['incremental_value']))

        return job_dict, success
    except Exception as e:
        logger.error(str(e))
        job_dict = None
        success = False
        return job_dict, success
