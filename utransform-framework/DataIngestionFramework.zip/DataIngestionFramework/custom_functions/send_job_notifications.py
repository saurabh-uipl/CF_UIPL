import json
from ..analytics_utilities.notification_utility import NotificationUtility, SimpleEmailService
from ..analytics_utilities.secrets_manager import SecretsManager
from ..log_utilities.logs_utility import LogsUtility
import datetime
import pytz
import time
import logging
from ..src.etl_config import ETLConfig
#from datetime import datetime
import pytz
import boto3

logger = logging.getLogger("my_logger")


def send_job_notifications(table_list_pandas_df, etl_config: ETLConfig):
    """

    Returns:
        my_obj:

    """
    try:
        success = True
        for k, row in table_list_pandas_df.iterrows():
            etl_config.sns_list_tables.append(str(row['tablename']))

        json_obj = {
            "Message": "Job is started",
            "Reports Name": etl_config.job_id,
            "JobTableList": etl_config.sns_list_tables
        }

        my_obj = {}
        json_message_0 = json.dumps({"default": json.dumps(json_obj)})

        if etl_config.sns_topic != 'NA':
            logger.info(" sns topic is not blank .....")
            notification_utility_obj = NotificationUtility(json_message_0, etl_config)
            sns_dict0, success = notification_utility_obj.send_sns()

            logger.info("*****SNS******{}".format(json_message_0))

            my_obj['notification_type'] = 'SNS'
            return my_obj, success

        elif etl_config.smtp_ses_secret_name != 'NA':
            logger.info("SES is not blank ......")
            sam_utility = SecretsManager(etl_config.smtp_ses_secret_name, etl_config)
            smtp_ses_dict, success = sam_utility.get_secret_name()
            smtp_conn_details = smtp_ses_dict[1]
            smtp_ses_user = smtp_conn_details['user']
            smtp_ses_password = smtp_conn_details['password']
            smtp_endpoint = smtp_conn_details['endpoint']
            sender = smtp_conn_details['sender']
            recipients = smtp_conn_details['recipients']

            my_obj['sender'] = sender
            my_obj['recipients'] = recipients
            my_obj['smtp_ses_user'] = smtp_ses_user
            my_obj['smtp_ses_password'] = smtp_ses_password
            my_obj['smtp_endpoint'] = smtp_endpoint
            my_obj['notification_type'] = 'SES'

            # logger.info("*****SNS/SES******{}".format(json_message_0))
            logger.info(" ****SNS/SES****** ...")
            subject = "ETL Job Status Mail"
            logger.info("subject")
            send_ses_obj = SimpleEmailService(json_obj, sender, recipients, subject, etl_config,
                                              smtp_ses_user, smtp_ses_password, smtp_endpoint)
            ses_dict0, success = send_ses_obj.send_ses()

            return my_obj, success
        else:

            my_obj['notification_type'] = "Notification/E-Mail  is not required"
            logger.info(" Notification/E-Mail  is not required ")
            return my_obj, success
    except Exception as e:
        logger.error(" Error Occurred")
        logger.error(str(e))
        my_obj = {"notification_type": str(e)}
        success = False
        return my_obj, success


def job_notification(etl_config: ETLConfig,
                     job_dict, sender, recipients,
                     smtp_ses_user, smtp_ses_password
                     , smtp_endpoint):
    """
    Args:
    sns_topic:
    logger:
    job_name:
    sns_list_failure:
    sns_list_success:
    smtp_ses_secret_name:
    region_name:
    job_dict:
    sender:
    recipients:
    smtp_ses_user:
    smtp_ses_password:
    smtp_endpoint:
    """
    try:

        logger.info(
            "***************Job run successfully at {} for group {} ******************************".format(
                datetime.datetime.now(pytz.timezone(etl_config.timezone_param)), etl_config.job_name))

        log_utility_obj = LogsUtility(job_dict["JOBNAME"], job_dict["bucket_name"])
        d = log_utility_obj.write_logs()
        exists = d[1]

        json_object = {
            "FailedTableList": etl_config.sns_list_failure,
            "Reports": etl_config.sns_list_success
        }
        json_message = json.dumps({"default": json.dumps(json_object)})

        if etl_config.sns_topic != 'NA':
            notification_utl_obj = NotificationUtility(json_message, etl_config)
            sns_dict, success = notification_utl_obj.send_sns()
            logger.info(" Job Completion Alert Has Been Sent Successfully through SNS....")

        elif etl_config.smtp_ses_secret_name != 'NA':
            logger.info("*****SNS/SES******{}".format(json_message))

            subject = "ETL Job Status Mail"
            ses_utl_obj = SimpleEmailService(json_object, sender, recipients, subject, etl_config,
                                             smtp_ses_user, smtp_ses_password, smtp_endpoint)
            ses_dict, success = ses_utl_obj.send_ses()
            logger.info(" Job Completion Alert Has Been Sent Successfully through SES....")

        else:
            logger.info(" Notification/Mail is not required ")

        return "Job processed successfully"
    except Exception as e:
        logger.error(str(e))



def send_s3_iceberg_batch_only(etl_config, job_dict, status):

    if not (
        job_dict.get("inventory") == 'NA' and
        job_dict.get("chunk_size") == 'NA' and
        str(job_dict.get("source", "")).lower() == "s3_files" and
        str(job_dict.get("destination_type", "")).lower() == "iceberg"
    ):
        return False

    if etl_config.sns_topic == 'NA':
        return False

    try:
        sns_client = boto3.client("sns", region_name=etl_config.region_name)
        tz = pytz.timezone(etl_config.timezone_param)

        start_time = job_dict.get("start_time")

        # START
        if status == "STARTED":

            subject = f"Job: {etl_config.job_name} Started"

            message = {
                "job_name": etl_config.job_name,
                "start_time": str(start_time)
            }

            sns_client.publish(
                TopicArn=etl_config.sns_topic,
                Subject=subject,
                Message=json.dumps(message)
            )

            return True

        # COMPLETED
        elif status == "COMPLETED":
            #end_time = datetime.now(tz)
            end_time = datetime.datetime.now(tz)

            if start_time:
                diff = end_time - start_time
                total_seconds = int(diff.total_seconds())

                hours = total_seconds // 3600
                minutes = (total_seconds % 3600) // 60
                seconds = total_seconds % 60

                execution_time = f"{hours:02d} Hour {minutes:02d} Minutes {seconds:02d} Seconds"
            else:
                execution_time = "NA"

            subject = f" Job: {etl_config.job_name} Completed"

            message = {
                "job_name": etl_config.job_name,
                "start_time": str(start_time),
                "end_time": str(end_time),
                "execution_time": execution_time
            }

            sns_client.publish(
                TopicArn=etl_config.sns_topic,
                Subject=subject,
                Message=json.dumps(message)
            )

            return True

    except Exception as e:
        logger.error(f"S3 Iceberg Job Notification Error: {str(e)}")
        return False

    return False

