from ..analytics_utilities.secrets_manager import SecretsManager
import pytz
import datetime
from ..src.etl_config import ETLConfig
import logging


class ReadFromRedshift:

    def __init__(self, redshift_secret_name, etl_config: ETLConfig) -> None:

        self.etl_config = etl_config
        self.redshift_secret_name = redshift_secret_name
        self.logger = logging.getLogger("my_logger")

        '''
        Args:
            job_id:
            glueContext:
            redshift_secret_name:
            region_name:
            job_name:
            redshift_schema_name:
            redshift_etl_master_table_name:
            
        
        '''

    def read_from_redshift(self):
        """
        Retrieves the secret key from sam_utility based on the provided redshift_secret_name and region_name.
        .
        Logs the job start time and job name.
        Connects to Redshift using the retrieved connection details.
        Retrieves data from the specified table in the db database.
        Converts the data to a Pandas DataFrame.

        Returns:
            df_pandas:
        """

        try:
            logging.info('executing sam_utility')
            sam_util = SecretsManager(self.redshift_secret_name, self.etl_config)
            secret_value, success = sam_util.get_secret_name()

            redshift_conn_details = secret_value[1]

            # redshift_log_message = "*** job started at {} for job {} in Redshift mode  *** ".format(
            #    self.etl_config.current_time(), self.etl_config.job_name)

            # self.logger.info(redshift_log_message)

            table_name = """
                        (SELECT *
                        FROM {redshift_schema_name}.{redshift_etl_master_table_name}
                        WHERE groupid = {job_id} AND active = 1
                        ORDER BY Priority)
                        """.format(job_id=self.etl_config.job_id, redshift_schema_name=self.
                                   etl_config.redshift_schema_name,
                                   redshift_etl_master_table_name=self.etl_config.redshift_etl_master_table_name)

            redshift_connection_log = "\n*************** CONNECTING TO REDSHIFT ******************************\n"

            self.logger.info(redshift_connection_log)
            self.logger.info(" Redshift Query*****:: {}".format(table_name))
            df = self.etl_config.glueContext.read.format("jdbc") \
                .option("driver", str(redshift_conn_details['driver'])) \
                .option("url", str(redshift_conn_details['jdbcURL'])) \
                .option("dbtable", table_name) \
                .option("user", str(redshift_conn_details['user'])) \
                .option("password", str(redshift_conn_details['password'])) \
                .load()

            df_pandas = df.toPandas()
            return df_pandas, success

        except Exception as e:
            self.logger.error("Unable to read from Redshift. ")
            self.logger.error(str(e))

            df_pandas = None
            success = False
            return df_pandas, success
