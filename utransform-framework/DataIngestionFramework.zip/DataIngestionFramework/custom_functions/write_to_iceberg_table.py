import boto3
import json
import pyspark
from pyspark.conf import SparkConf
# from pyspark.context import SparkContext
# from awsglue.context import GlueContext
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import StructField, StructType, StringType, LongType, IntegerType, ArrayType, DataType
from .insert_failed_tables import add_failed_table_entry
from ..src.etl_config import ETLConfig
import logging


def write_to_iceberg_table(df_final, job_dict, etl_config: ETLConfig):
    logger = logging.getLogger("my_logger")
    is_table_present_flag = 0
    logger.info("Drop duplicates ...")
    df_final = df_final.dropDuplicates()
    try:
        logger.info("Executing write_to_iceberg_table ....")

        # conf = (
        #     pyspark.SparkConf()
        #     # SQL Extensions
        #     # can not set property dynamically ---
        #     # .set('spark.sql.extensions', 'org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions')
        #     # Configuring Catalog
        #     .set('spark.sql.catalog.uipl', 'org.apache.iceberg.spark.SparkCatalog')
        #     .set('spark.sql.catalog.uipl.catalog-impl', 'org.apache.iceberg.aws.glue.GlueCatalog')
        #     .set('spark.sql.catalog.uipl.warehouse', 's3://{0}/'.format(job_dict["bucket_name"]))
        #     .set('spark.sql.catalog.uipl.io-impl', 'org.apache.iceberg.aws.s3.S3FileIO')
        #     .set('spark.sql.iceberg.handle-timestamp-without-timezone', True)
        #     .set('spark.sql.iceberg.use-timestamp-without-timezone-in-new-tables', True)
        # )
        #
        # conf = (
        #     pyspark.SparkConf()
        #     # SQL Extensions
        #     # can not set property dynamically ---
        #     # .set('spark.sql.extensions', 'org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions')
        #     # Configuring Catalog
        #     .set('spark.sql.extensions', 'org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions')
        #     .set('spark.sql.catalog.uipl', 'org.apache.iceberg.spark.SparkCatalog')
        #     .set('spark.sql.catalog.uipl.type', 'hive')   ##### EMR MERGE Operation
        #     .set('spark.sql.catalog.uipl.warehouse', 's3://{0}/'.format(job_dict["bucket_name"]))
        # )
        #


        ########## EMR/GLUE  ICEBERG

        # conf = (
        #     pyspark.SparkConf()
        #     # SQL Extensions
        #     # can not set property dynamically ---
        #     # .set('spark.sql.extensions', 'org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions')
        #     # Configuring Catalog
        #     .set('spark.sql.catalog.uipl', 'org.apache.iceberg.spark.SparkCatalog')
        #     .set('spark.sql.catalog.uipl.catalog-impl', 'org.apache.iceberg.aws.glue.GlueCatalog')
        #     .set('spark.sql.catalog.uipl.warehouse', 's3://{0}/'.format(job_dict["bucket_name"]))
        #     .set('spark.sql.catalog.uipl.io-impl', 'org.apache.iceberg.aws.s3.S3FileIO')
        #     .set('spark.sql.iceberg.handle-timestamp-without-timezone', True)
        #     .set('spark.sql.iceberg.use-timestamp-without-timezone-in-new-tables', True)
        #
        #     .set("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions")
        #     )


        # spark = SparkSession.builder.config(conf=conf).getOrCreate()


        #################################################################################

        # logger.info("***CREATING SPARK ***********************")
        # spark = SparkSession.builder \
        #     .appName("IcebergWithGlue") \
        #     .config("spark.sql.catalog.uipl", "org.apache.iceberg.spark.SparkCatalog") \
        #     .config("spark.sql.catalog.uipl.catalog-impl", "org.apache.iceberg.aws.glue.GlueCatalog") \
        #     .config('spark.sql.catalog.uipl.warehouse', 's3://{0}/'.format(job_dict["bucket_name"])) \
        #     .config("spark.sql.catalog.uipl.io-impl", "org.apache.iceberg.aws.s3.S3FileIO") \
        #     .config("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions") \
        #     .config('spark.sql.iceberg.handle-timestamp-without-timezone', "true") \
        #     .config("spark.sql.session.timeZone", etl_config.timezone_param) \
        #     .getOrCreate()

        ##############################################################################

        conf = (
            pyspark.SparkConf()
            # SQL Extensions
            # can not set property dynamically ---
            # .set('spark.sql.extensions', 'org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions')
            # Configuring Catalog
            .set('spark.sql.catalog.uipl', 'org.apache.iceberg.spark.SparkCatalog')
            .set('spark.sql.catalog.uipl.catalog-impl', 'org.apache.iceberg.aws.glue.GlueCatalog')
            .set('spark.sql.catalog.uipl.warehouse', 's3://{0}/'.format(job_dict["bucket_name"]))
            .set('spark.sql.catalog.uipl.io-impl', 'org.apache.iceberg.aws.s3.S3FileIO')
            .set("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions")
            .set('spark.sql.iceberg.handle-timestamp-without-timezone', True)
            .set('spark.sql.iceberg.use-timestamp-without-timezone-in-new-tables', True)
        )

        spark = SparkSession.builder.config(conf=conf).getOrCreate()


        logger.info(" SPARK CREATED *******************************")
        logger.info("************Extensions:********************"+ spark.conf.get("spark.sql.extensions"))

        ##### Uncomment this
        # spark.conf.set('spark.sql.session.timeZone', etl_config.timezone_param)

        # logger.info("Timezone has been set to "+str(etl_config.timezone_param))

        is_table_present_flag, success, is_error = check_athena_table(etl_config, is_table_present_flag, job_dict, logger)
        is_table_present = check_table_present(logger, job_dict, etl_config)
        logger.info(" is_table_present_flag: ")
        logger.info(is_table_present_flag)
        # align_dataframe_schema_with_iceberg_table(job_dict, logger, df_final, spark, etl_config: ETLConfig):
        if is_table_present:
            logger.info("Table found for schema evolution")
            df_final = align_dataframe_schema_with_iceberg_table(job_dict, logger, df_final, spark, etl_config)
        else:
            logger.info("Table not found for schema evolution")
        #        for col in df_final.columns:
        #            df_final = df_final.withColumnRenamed(col, col.lower())
        #        df_final.createOrReplaceTempView("df_final")

        Partition_Column_TABLE = ''
        if len(job_dict["Partition_Column"]) > 0:
            logger.info(" Partition Column Exists ....")
            logger.info(" Create Partition Column ....")
            Partition_Column_TABLE = str(job_dict["Partition_Column"])[1:-1].replace("'", '').lower()
        else:
            pass
        df_final.createOrReplaceTempView('df_final')

        if is_table_present:
            logger.info(" Table Is Present .......")
            logger.info(" Table Found In Icberge .....")
            spark.sql(f'CREATE DATABASE IF NOT EXISTS uipl.{etl_config.athena_db_name}')
            if job_dict['load_type'].lower() == 'merge':
                logger.info(" Load Type Is Merge ..")
                query = f"""MERGE INTO uipl.{etl_config.athena_db_name}.{job_dict["table_name"]} t
                                                            USING (SELECT * FROM df_final) s
                                                            ON t.{job_dict["pk_column"]} = s.{job_dict["pk_column"]}
                                                            WHEN MATCHED THEN UPDATE SET * 
                                                            WHEN NOT MATCHED THEN INSERT * """
                logger.info(" Merge Query....")
                logger.info(query)
                spark.sql(query)
            elif job_dict['load_type'].lower() == 'incremental':
                logger.info(" Load Type Is Incremental ....")
                if len(job_dict["Partition_Column"]) > 0 and Partition_Column_TABLE != '<na>':
                    logger.info(" length of Partition_Column > 0 ")
                    query = f""" 
                                        INSERT INTO uipl.{etl_config.athena_db_name}.{job_dict["table_name"]} 
                                        SELECT * FROM df_final
                                        ORDER BY {Partition_Column_TABLE}
                                """
                    logger.info(" Query: ")
                    logger.info(query)
                    spark.sql(query)
                else:
                    logger.info("length of Partition_Column <= 0 ")
                    query = f""" 
                                 INSERT INTO uipl.{etl_config.athena_db_name}.{job_dict["table_name"]} 
                                 SELECT * FROM df_final
                                  """
                    logger.info("Query: ")
                    logger.info(query)
                    spark.sql(query)
            else:
                logger.info(" Load Type Is Full Load ....")
                if len(job_dict["Partition_Column"]) > 0 and Partition_Column_TABLE != '<na>':
                    query = f""" 
                                            INSERT OVERWRITE uipl.{etl_config.athena_db_name}.{job_dict["table_name"]} 
                                            SELECT * FROM df_final
                                            ORDER BY {Partition_Column_TABLE}
                                        """
                    logger.info(" Query: ")
                    logger.info(query)
                    spark.sql(query)
                else:
                    query = f""" 
                                INSERT OVERWRITE uipl.{etl_config.athena_db_name}.{job_dict["table_name"]} 
                                 SELECT * FROM df_final
                                """
                    logger.info(" Query: ")
                    logger.info(query)
                    spark.sql(query)

        else:
            logger.info(" Table Not Found in Iceberg, creating table .....")
            logger.info(" Creating Database: ")
            logger.info(str(etl_config.athena_db_name))
            spark.sql(f'CREATE DATABASE IF NOT EXISTS uipl.{etl_config.athena_db_name}')
            logger.info("Partition_Column: ")
            logger.info(job_dict["Partition_Column"])
            if len(job_dict["Partition_Column"]) > 0 and Partition_Column_TABLE != '<na>' and Partition_Column_TABLE != 'none':
                logger.info("Partition_Column_TABLE : {}".format(Partition_Column_TABLE))
                logger.info("Creating Iceberg table .........")
                logger.info(str(job_dict["table_name"]))
                query = f"""
                    CREATE OR REPLACE TABLE uipl.{etl_config.athena_db_name}.{job_dict["table_name"]}
                    USING iceberg TBLPROPERTIES ('format-version' = '2', 'write.target-file-size-bytes'='5242880')
                    PARTITIONED BY ({Partition_Column_TABLE})
                    AS SELECT * FROM df_final
                    ORDER BY {Partition_Column_TABLE}
                    """
                logger.info(str(query))
                spark.sql(query)
                logger.info(" Iceberg table has been created successfully .......")
            else:
                logger.info("Creating Iceberg table .........")
                logger.info(str(job_dict["table_name"]))
                query = f"""
                    CREATE OR REPLACE TABLE uipl.{etl_config.athena_db_name}.{job_dict['table_name']}
                    USING iceberg TBLPROPERTIES ('format-version' = '2', 'write.target-file-size-bytes'='5242880')
                    AS SELECT * FROM df_final
                    """
                logger.info(str(query))
                logger.info(" Iceberg table has been created successfully .......")
                spark.sql(query)

        iceberg_dict = {1: spark, 2: is_table_present_flag, 3: df_final}
        is_error = None
        return iceberg_dict, is_error
    except Exception as e:
        logger.info(" Error Occurred .....")
        logger.info(str(e))
        is_error = str(e)
        iceberg_dict = {}
        add_failed_table_entry(job_dict, etl_config, logger, is_error)
        return iceberg_dict, is_error


def check_athena_table(etl_config, is_table_present_flag, job_dict, logger):
    try:
        s3_client = boto3.client('athena')
        response = s3_client.get_table_metadata(
            CatalogName='awsdatacatalog',
            DatabaseName=f'{etl_config.athena_db_name}',
            TableName=f'{job_dict["table_name"]}'
        )
        success = True
        is_error = None
        return 1, success, is_error
    except Exception as e:
        logger.info(" Error Ocurred .....")
        logger.info(str(e))
        is_table_present_flag = 0
        success = False
        is_error = str(e)
        return 0, success, is_error


write_load_flag = 0


def write_to_iceberg_table_v1(df_final, job_dict, write_load_flag, etl_config: ETLConfig, table_name):
    logger = logging.getLogger("my_logger")
    try:
        is_table_present_flag = 0
        conf = (
            pyspark.SparkConf()
            # SQL Extensions
            # can not set property dynamically ---
            # .set('spark.sql.extensions', 'org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions')
            # Configuring Catalog
            .set('spark.sql.catalog.uipl', 'org.apache.iceberg.spark.SparkCatalog')
            .set('spark.sql.catalog.uipl.catalog-impl', 'org.apache.iceberg.aws.glue.GlueCatalog')
            .set('spark.sql.catalog.uipl.warehouse', 's3://{0}/'.format(job_dict["bucket_name"]))
            .set('spark.sql.catalog.uipl.io-impl', 'org.apache.iceberg.aws.s3.S3FileIO')
            .set('spark.sql.iceberg.handle-timestamp-without-timezone', True)
            .set('spark.sql.iceberg.use-timestamp-without-timezone-in-new-tables', True)
        )
        spark = SparkSession.builder.config(conf=conf).getOrCreate()
        spark.conf.set('spark.sql.session.timeZone', etl_config.timezone_param)

        #        for col in df_final.columns:
        #            df_final = df_final.withColumnRenamed(col, col.lower())
        #        df_final.createOrReplaceTempView("df_final")
        logger.info(" Display DF Before Writing .......")
        df_final.show(1, False)

        if len(job_dict["Partition_Column"]) > 0:
            Partition_Column_TABLE = str(job_dict["Partition_Column"])[1:-1].replace("'", '').lower()
        else:
            pass
        df_final.createOrReplaceTempView('df_final')
        logger.info(" calling  is_table_present ")
        logger.info(" Check If Iceberg table is already created or not ..")
        is_table_present = check_table_present(logger, job_dict, etl_config)

        is_success = True

        if is_table_present is True and write_load_flag != 0:
            if job_dict['load_type'].lower() == 'merge':
                logger.info(" Load Type Is Merge ..")
                logger.info(" is_table_present is True and write_load_flag != 0 ")
                query = f"""MERGE INTO uipl.{etl_config.athena_db_name}.{table_name} t
                                                USING (SELECT * FROM df_final) s
                                                ON t.{job_dict["pk_column"]} = s.{job_dict["pk_column"]}
                                                WHEN MATCHED THEN UPDATE SET * 
                                                WHEN NOT MATCHED THEN INSERT * """
                logger.info(" Merge Query....")
                logger.info(query)
            elif job_dict['load_type'].lower() == 'incremental':
                logger.info(" Load Type Is Incremental ....")
                if len(job_dict["Partition_Column"]) > 0 and Partition_Column_TABLE != '<na>':
                    logger.info(" length of Partition_Column > 0 ")
                    query = f""" 
                            INSERT INTO uipl.{etl_config.athena_db_name}.{table_name} 
                            SELECT * FROM df_final
                            ORDER BY {Partition_Column_TABLE}
                    """
                    logger.info(" Query: ")
                    logger.info(query)
                else:
                    logger.info("length of Partition_Column <= 0 ")
                    query = f""" 
                                                INSERT INTO uipl.{etl_config.athena_db_name}.{table_name} 
                                                SELECT * FROM df_final
                                        """
                    logger.info("Query: ")
                    logger.info(query)
            else:
                logger.info(" Load Type Is Full Load ....")
                if len(job_dict["Partition_Column"]) > 0 and Partition_Column_TABLE != '<na>':
                    query = f""" 
                                INSERT OVERWRITE uipl.{etl_config.athena_db_name}.{table_name} 
                                SELECT * FROM df_final
                                ORDER BY {Partition_Column_TABLE}
                            """
                    logger.info(" Query: ")
                    logger.info(query)
                else:
                    query = f""" 
                                                    INSERT OVERWRITE uipl.{etl_config.athena_db_name}.{table_name} 
                                                    SELECT * FROM df_final
                    """
                    logger.info(" Query: ")
                    logger.info(query)
            spark.sql(query)
            logger.info(" Data Has Been Written Successfully in Iceberg ....")

        elif is_table_present is False and write_load_flag != 0:
            logger.info("  is_table_present is False and write_load_flag != 0 ")
            print("CREATING DATABASE")
            spark.sql(f'CREATE DATABASE IF NOT EXISTS uipl.{etl_config.athena_db_name}')
            print("DATABASE CREATED")
            if len(job_dict["Partition_Column"]) > 0 and Partition_Column_TABLE != '<na>':
                logger.info(" length of Partition_Column > 0 ")
                query = f"""
                                    CREATE TABLE uipl.{etl_config.athena_db_name}.{table_name}
                                    USING iceberg TBLPROPERTIES ('format-version' = '2', 'write.target-file-size-bytes'='5242880')
                                    PARTITIONED BY ({Partition_Column_TABLE})
                                    AS SELECT * FROM df_final
                                    ORDER BY {Partition_Column_TABLE}
                """
                logger.info(" Query: ")
                logger.info(query)
            else:
                logger.info(" length of Partition_Column <= 0 ")
                query = f"""
                                                    CREATE TABLE uipl.{etl_config.athena_db_name}.{table_name}
                                                    USING iceberg TBLPROPERTIES ('format-version' = '2', 'write.target-file-size-bytes'='5242880')
                                                    AS SELECT * FROM df_final      
                """
                logger.info(" Query: ")
                logger.info(query)
            spark.sql(query)
            logger.info(" Table Created and Data Also Has Been Written Successfully in Iceberg ....")
        else:
            logger.info(" Skip Data Write In Iceerg ......")
        iceberg_dict = {1: spark, 2: is_success, 3: df_final}
        logger.info(" Return iceberg_dict ........")
        return iceberg_dict
    except Exception as e:
        logger.error(" Error Occurred in write_to_iceberg_table_v1 .....")
        logger.error(str(e))
        spark = None
        is_success = False
        df_final = None
        iceberg_dict = {1: spark, 2: is_success, 3: df_final}
        add_failed_table_entry(job_dict, etl_config, logger, str(e))
        return iceberg_dict


def write_to_iceberg_table_rest_api(df_final, job_dict, write_load_flag, etl_config: ETLConfig, table_name):
    logger = logging.getLogger("my_logger")
    try:
        is_table_present_flag = 0
        conf = (
            pyspark.SparkConf()
            # SQL Extensions
            # can not set property dynamically ---
            # .set('spark.sql.extensions', 'org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions')
            # Configuring Catalog
            .set('spark.sql.catalog.uipl', 'org.apache.iceberg.spark.SparkCatalog')
            .set('spark.sql.catalog.uipl.catalog-impl', 'org.apache.iceberg.aws.glue.GlueCatalog')
            .set('spark.sql.catalog.uipl.warehouse', 's3://{0}/'.format(job_dict["bucket_name"]))
            .set('spark.sql.catalog.uipl.io-impl', 'org.apache.iceberg.aws.s3.S3FileIO')
            .set('spark.sql.iceberg.handle-timestamp-without-timezone', True)
            .set('spark.sql.iceberg.use-timestamp-without-timezone-in-new-tables', True)
        )
        spark = SparkSession.builder.config(conf=conf).getOrCreate()
        spark.conf.set('spark.sql.session.timeZone', etl_config.timezone_param)

        #        for col in df_final.columns:
        #            df_final = df_final.withColumnRenamed(col, col.lower())
        #        df_final.createOrReplaceTempView("df_final")
        logger.info(" Display DF Before Writing .......")
        df_final.show(1, False)

        if len(job_dict["Partition_Column"]) > 0:
            Partition_Column_TABLE = str(job_dict["Partition_Column"])[1:-1].replace("'", '').lower()
        else:
            pass
        df_final.createOrReplaceTempView('df_final')
        logger.info(" calling  is_table_present ")
        logger.info(" Check If Iceberg table is already created or not ..")
        is_table_present = check_table_present(logger, job_dict, etl_config)

        is_success = True

        if is_table_present is True and write_load_flag != 0:
            if job_dict['load_type'].lower() == 'merge':
                logger.info(" Load Type Is Merge ..")
                logger.info(" is_table_present is True and write_load_flag != 0 ")
                query = f"""MERGE INTO uipl.{etl_config.athena_db_name}.{table_name} t
                                                USING (SELECT * FROM df_final) s
                                                ON t.{job_dict["pk_column"]} = s.{job_dict["pk_column"]}
                                                WHEN MATCHED THEN UPDATE SET * 
                                                WHEN NOT MATCHED THEN INSERT * """
                logger.info(" Merge Query....")
                logger.info(query)
            elif job_dict['load_type'].lower() == 'incremental':
                logger.info(" Load Type Is Incremental ....")
                if len(job_dict["Partition_Column"]) > 0 and Partition_Column_TABLE != '<na>':
                    logger.info(" length of Partition_Column > 0 ")
                    query = f""" 
                            INSERT INTO uipl.{etl_config.athena_db_name}.{table_name} 
                            SELECT * FROM df_final
                            ORDER BY {Partition_Column_TABLE}
                    """
                    logger.info(" Query: ")
                    logger.info(query)
                else:
                    logger.info("length of Partition_Column <= 0 ")
                    query = f""" 
                                                INSERT INTO uipl.{etl_config.athena_db_name}.{table_name} 
                                                SELECT * FROM df_final
                                        """
                    logger.info("Query: ")
                    logger.info(query)
            else:
                logger.info(" Load Type Is Full Load ....")
                if len(job_dict["Partition_Column"]) > 0 and Partition_Column_TABLE != '<na>':
                    query = f""" 
                                INSERT OVERWRITE uipl.{etl_config.athena_db_name}.{table_name} 
                                SELECT * FROM df_final
                                ORDER BY {Partition_Column_TABLE}
                            """
                    logger.info(" Query: ")
                    logger.info(query)
                else:
                    query = f""" 
                                                    INSERT OVERWRITE uipl.{etl_config.athena_db_name}.{table_name} 
                                                    SELECT * FROM df_final
                    """
                    logger.info(" Query: ")
                    logger.info(query)
            spark.sql(query)
            logger.info(" Data Has Been Written Successfully in Iceberg ....")

        elif is_table_present is False and write_load_flag != 0:
            logger.info("  is_table_present is False and write_load_flag != 0 ")
            print("CREATING DATABASE")
            spark.sql(f'CREATE DATABASE IF NOT EXISTS uipl.{etl_config.athena_db_name}')
            print("DATABASE CREATED")
            if len(job_dict["Partition_Column"]) > 0 and Partition_Column_TABLE != '<na>':
                logger.info(" length of Partition_Column > 0 ")
                query = f"""
                                    CREATE TABLE uipl.{etl_config.athena_db_name}.{table_name}
                                    USING iceberg TBLPROPERTIES ('format-version' = '2', 'write.target-file-size-bytes'='5242880')
                                    PARTITIONED BY ({Partition_Column_TABLE})
                                    AS SELECT * FROM df_final
                                    ORDER BY {Partition_Column_TABLE}
                """
                logger.info(" Query: ")
                logger.info(query)
            else:
                logger.info(" length of Partition_Column <= 0 ")
                query = f"""
                                                    CREATE TABLE uipl.{etl_config.athena_db_name}.{table_name}
                                                    USING iceberg TBLPROPERTIES ('format-version' = '2', 'write.target-file-size-bytes'='5242880')
                                                    AS SELECT * FROM df_final      
                """
                logger.info(" Query: ")
                logger.info(query)
            spark.sql(query)
            logger.info(" Table Created and Data Also Has Been Written Successfully in Iceberg ....")
        else:
            logger.info(" Skip Data Write In Iceerg ......")
        iceberg_dict = {1: spark, 2: is_success, 3: df_final}
        logger.info(" Return iceberg_dict ........")
        is_error = False
        return iceberg_dict, is_error
    except Exception as e:
        logger.error(" Error Occurred in write_to_iceberg_table_v1 .....")
        logger.error(str(e))
        spark = None
        is_success = False
        df_final = None
        iceberg_dict = {1: spark, 2: is_success, 3: df_final}
        add_failed_table_entry(job_dict, etl_config, logger, str(e))
        is_error = True
        return iceberg_dict, is_error


def check_table_present(logger, job_dict, etl_config):
    is_table_present = True

    table_name_list = job_dict["table_name"].split('/')
    table_name = table_name_list[len(table_name_list) - 2]
    if len(table_name.strip()) < 2:
        table_name = table_name_list[len(table_name_list) - 1]

    try:
        s3_client = boto3.client('athena')
        responce = s3_client.get_table_metadata(
            CatalogName='awsdatacatalog',
            DatabaseName=f'{etl_config.athena_db_name}',
            TableName=f'{table_name}'
        )
        logger.info(" Iceberg Table Is Already Created .....")
        return is_table_present
    except Exception as e:
        logger.error(" Error occurred in check_table_present .....")
        logger.error(str(e))
        check_table_present = False
        logger.info(" Iceberg table is not available ...need to create ")
        return check_table_present


def align_dataframe_schema_with_iceberg_table(job_dict, logger, df_final, spark, etl_config: ETLConfig):
    logger.info('Compare newly incoming data columns with existing columns')
    try:
        #            write_load_flag = 1
        table_name_val_list = job_dict["table_name"].split('/')
        if len(table_name_val_list) > 1:
            table_name = table_name_val_list[0]
            # print('r = ', r)
        else:
            table_name = table_name_val_list[-1]
            # print('t = ', t)
        #            table_name_val_list = job_dict["table_name"].split('/')
        #            table_name = table_name_val_list[len(table_name_val_list) - 2]
        #            if len(table_name) < 2:
        #                table_name = table_name_val_list[len(table_name_val_list) - 1]

        is_table_present = check_table_present(logger, job_dict, etl_config)
        logger.info(" is_table_present: ")
        logger.info(is_table_present)
        if is_table_present:
            logger.info("Table found for schema match")
            logger.info("Read data of existing table")
            logger.info("Table Name:" + str(table_name))
            df_tbl = spark.read.format("iceberg").load(f'uipl.{etl_config.athena_db_name}.{table_name}')
            df_columns = df_tbl.columns
            # logger.info('Schema of existing table')
            # logger.info(df_columns)
            df_columns = [column.lower() for column in df_columns]
            df_tbl = df_tbl.toDF(*df_columns)
            df_columns = df_final.columns
            df_columns = [column.lower() for column in df_columns]
            df_final = df_final.toDF(*df_columns)
            df_tbl.printSchema()
            df_final.printSchema()
            # logger.info("Checking column diff")
            column_list_dif = [col for col in df_tbl.dtypes if col not in df_final.dtypes]
            # logger.info(column_list_dif)
            if len(column_list_dif) > 0:
                logger.info("Some columns have been deleted from source")
                # logger.info("List of columns deleted from source")
                # logger.info(str(column_list_dif))
                for col in column_list_dif:
                    if col[0] not in df_final.columns:
                        df_final = df_final.withColumn(col[0], F.lit(None))
                        df_final = df_final.withColumn(col[0], F.col(col[0]).cast(col[1]))
                    elif col[1] == 'timestamp':
                        df_check = df_final.filter(length(F.col(col[0])) > 0)
                        if df_check.select(col[0]).collect()[0][0][len(df_check.select(col[0]).collect()[0][0]) - 1] == 'M':
                            # df_final = df_final.withColumn(col[0], from_utc_timestamp(F.col(col[0]),etl_config.timezone_param))
                            df_final = df_final.withColumn(col[0], from_utc_timestamp(to_timestamp(F.col(col[0]), "M/d/yyyy h:m:ss a"), etl_config.timezone_param))
                        else:
                            df_final = df_final.withColumn(col[0], F.col(col[0]).cast(col[1]))
                    else:
                        df_final = df_final.withColumn(col[0], F.col(col[0]).cast(col[1]))

            column_list_dif_1 = [col for col in df_final.dtypes if col not in df_tbl.dtypes and col[0] != 'file_date']
            if len(column_list_dif_1) > 0:
                logger.info("Add missing columns in destination Iceberg table")
                logger.info("List of missing columns in destination Iceberg table:-")
                logger.info(str(column_list_dif_1))
                for col in column_list_dif_1:
                    logger.info("Adding " + str(col) + " in Iceberg")
                    query = f"""ALTER TABLE uipl.{etl_config.athena_db_name}.{table_name}
                                        ADD COLUMNS (
                                            {col[0]} {col[1]}
                                          )"""
                    logger.info(query)
                    spark.sql(query)
            df_tbl = spark.read.format("iceberg").load(f'uipl.{etl_config.athena_db_name}.{table_name}')
            df_tbl_columns = df_tbl.columns
            #            df_tbl_columns.append('file_date')
            df_final = df_final.select(df_tbl_columns)
            df_tbl.printSchema()
            df_final.printSchema()
            df_columns = df_final.columns
            df_columns = [column.lower() for column in df_columns]
            df_final = df_final.toDF(*df_columns)
        else:
            logger.info("Table not found for schema match")
    except Exception as e:
        logger.error('error occurred')
        logger.error(str(e))
        # add_failed_table_entry(job_dict, etl_config, logger, str(e))
        return None
    return df_final
