import logging

logger = logging.getLogger('my_logger')


def extract_db_collection(spark, job_dict):
    """
    Args:
        spark:
        job_dict:
    Returns:
        database:
        collection:
        job_dict:
    """
    try:
        success = True
        spark.conf.set("spark.mongodb.input.sampleSize", "5000000")
        spark.conf.set("spark.mongodb.input.samplePoolSize", "5000000")
        spark.conf.set("spark.mongodb.input.batchSize", "10000")
        spark.conf.set("spark.sql.legacy.parquet.int96RebaseModeInRead", "CORRECTED")
        spark.conf.set("spark.sql.legacy.parquet.int96RebaseModeInWrite", "CORRECTED")
        spark.conf.set("spark.sql.legacy.parquet.datetimeRebaseModeInRead", "CORRECTED")
        spark.conf.set("spark.sql.legacy.parquet.datetimeRebaseModeInWrite", "CORRECTED")
        database = job_dict["SQL_Query"].split(".")[0].split()[-1]
        collection = job_dict["SQL_Query"].split(".")[1].split()[0].split(')')[0]
        logger.info(" MongoDB collection Name: "+str(collection))
        logger.info(" MongoDB database Name: " + str(database))
        is_error = None
        return database, collection, job_dict, success, is_error
    except Exception as e:
        logger.error(str(e))
        database = None
        collection = None
        success = False
        is_error = str(e)
        return database, collection, job_dict, success, is_error
