def get_json_string_columns(spark, df, logger):
    logger.info(" Executing get_json_string_columns .....")
    json_string_columns = []
    try:
        if len(df.head(1)) > 0:
            logger.info("DF is not empty")
            logger.info("df.dtypes")
            logger.info(df.dtypes)
            for data_type in df.dtypes:
                if data_type[1][:6] == "string":
                    logger.info("data type is struct")
                    # print("data_type[1][:6]", data_type[1][:6])
                    # print(data_type[0][:], "data_type[0][:]")
                    logger.info("check df is empty or not")
                    logger.info(df.rdd.isEmpty())
                    if df.rdd.isEmpty():
                        logger.info("DF is empty")
                    else:
                        logger.info(" DF Is Not Empty")
                        logger.info(df.collect()[0])
                        value = df.collect()[0][data_type[0][:]]
                        '''
                        if value is not None and (value.startswith("{") == True and value.endswith("}") == True or value.startswith(
                            "[") == True and value.endswith("]") == True):
                        '''
                        if value is not None and (value.startswith("{") == True and value.endswith("}") == True or value.startswith(
                                "[") == True and value.endswith("]") == True):
                            logger.info("appending to the list")
                            json_string_columns.append(data_type[0][:])
                            logger.info(data_type[0][:])
                            logger.info("column data type has been appended to the list")
                        else:
                            logger.info("struct type field not found in value")
        return json_string_columns
    except Exception as e:
        json_string_columns = []
        logger.error("Error Occurred ....::")
        logger.error(str(e))
        return json_string_columns
