from datetime import datetime, timedelta
import pytz
from ..audit_utilities.audit_utility import AuditUtility
import logging
from ..src.etl_config import ETLConfig
from .check_is_dataframe import check_is_dataframe
from datetime import datetime
from decimal import Decimal
from zoneinfo import ZoneInfo
#from backports.zoneinfo import ZoneInfo
logger = logging.getLogger("my_logger")


def update_audit_etl_master(spark, job_dict, df, etl_config: ETLConfig):
    try:
        success = True
        # logger.info("Audit is true")
        # df.show(1, False)
        '''
        check_is_dataframe_res = check_is_dataframe(df)
        if check_is_dataframe_res:
            logger.info(" Provided Object  is DataFrame")
        else:
            logger.info("Provided Object  is not a DataFrame")
            success = False
            is_error = None
            return success, is_error
        '''
        # records_count = df.count()
        # job_dict["records_count"] = records_count
        # logger.info("Total record are :{}".format(records_count))

        if job_dict['source'].lower() == 'sftp':
            logger.info("source is : ")
            logger.info(job_dict['source'])
            job_dict['table_name'] = job_dict['sftp_table_name']

        if job_dict["load_type"] == "incremental" or job_dict["load_type"] == "merge":
            # logger.info(" Load Type Is : ")
            # logger.info(job_dict["load_type"])
            df_cnt = 0
            if df is None:
                df_cnt = 0
            else:
                df_cnt = df.count()
            if df is None and df_cnt == 0:
                logger.info(" df is empty ....")
                job_dict["df_max_value"] = "'" + job_dict['startdatetime'] + "'"
                job_dict['records_count'] = 0
            else:
                # logger.info(" Check count .......")
                # records_count = df.count()
                records_count = job_dict['records_count']
                job_dict["records_count"] = records_count
                logger.info("Total record are :{}".format(records_count))
                if records_count > 0:
                    if 's3_' in job_dict['source'].lower():
                        if job_dict['business_unit'].lower() == 'haptik':
                            logger.info(" get max date value for haptic data source ....")
                            logger.info(" Change Max DateTime to CurrentDate + 1 Day .........")
                            df_max_value = str(datetime.datetime.now(pytz.timezone(etl_config.timezone_param)))[0:19]
                            str_df_max_value = "'" + str(df_max_value) + "'"
                        else:
                            logger.info(" Change Max DateTime to CurrentDate + 1 Day .........")
                            df_max_value = str(datetime.datetime.now(pytz.timezone(etl_config.timezone_param)) + timedelta(1))[0:19]
                            str_df_max_value = "'" + str(df_max_value) + "'"
                    else:
                        logger.info("s3 not in source")
                        if job_dict['source'].lower() == 'rest_api':
                            logger.info('source is rest_api...')
                            str_df_max_value = "'" + str(datetime.datetime.now(pytz.timezone(etl_config.timezone_param)))[0:10] + "'"
                        else:
                            logger.info("source is not rest_api.....")
                            # logger.info(job_dict)
                            incremental_column = str(job_dict["incremental_column"])
                            logger.info("MAX BY Incremental column")
                            df_max_value = df.agg({incremental_column: "max"}).collect()[0][0]
                            logger.info(df_max_value)
                            logger.info(str(type(df_max_value)))

                            if isinstance(df_max_value, int) or isinstance(df_max_value, float) or isinstance(df_max_value, Decimal) :
                                logger.info("MAX Value is Int/Float/Decimal...........")
                                df_max_value = int(df_max_value)
                            logger.info("Max value is not int/float/Decimal ...")
                            df_max_value = str(df_max_value)
                            logger.info("Updated Max value for Offset : "+str(df_max_value))

                            if job_dict['source'].lower() == 'mongodb':
                                df_max_value = str(df_max_value)[0:19].replace(' ', 'T') + 'Z'
                            logger.info(" df_max_value for Incremental Column:{}".format(str(df_max_value)))
                            str_df_max_value = "'" + str(df_max_value) + "'"
                    job_dict["df_max_value"] = str_df_max_value
                elif job_dict["incremental_value"] == 'nan' or \
                        job_dict["incremental_value"] == "None" or job_dict["incremental_value"] == "<NA>":
                    job_dict["df_max_value"] = "'" + \
                                               str(job_dict["startdatetime"]) + "'"
                    logger.info("MAX BY startdatetime")
                else:
                    offset_value_old = int(float(job_dict["incremental_value"]))
                    job_dict["df_max_value"] = "'" + str(offset_value_old) + "'"
                    logger.info("MAX BY offset_value")

        else:
            logger.info(" Load Type is : ")
            logger.info(job_dict["load_type"])

            if df is None:
                logger.info(" df is None ....")
                job_dict['records_count'] = 0
            else:
                logger.info(" DF is not none ........")
                df.createOrReplaceTempView("cnt_table")
                cnt = spark.sql(" select count(*) from cnt_table")
                cnt = cnt.first()[0]
                if cnt == 0:
                    logger.info(" df is empty ....")
                    logger.info(" Set records_count to 0 for full load entry in audit table .....")
                    job_dict['records_count'] = 0
            logger.info(" Load Type is ")
            logger.info(job_dict['load_type'])
            logger.info(str(job_dict["incremental_value"]))
            job_dict["df_max_value"] = job_dict['startdatetime']

        if len(job_dict['redshiftConnDetails']) != 0:
            # logger.info("audit entry call to Redshift ...........")
            audit_utility_obj = AuditUtility(job_dict, etl_config)
            d, success = audit_utility_obj.audit_entry()
            is_success = d[1]
            logger.info(" Response of audit_entry .... ")
            logger.info(is_success)

            logger.info("Update_ETL_Master_Entry call to redshift")
            audit_utility_obj = AuditUtility(job_dict, etl_config)
            d, success = audit_utility_obj.update_etl_master_entry()
            is_success = d[1]
            logger.info(" Response of update_etl_master_entry .....")
            logger.info(is_success)

        else:
            logger.info("Write Execution detail in Audit Table ......")

            audit_utils = AuditUtility(job_dict, etl_config)

            iceberg_insert_audit_res, success = audit_utils.audit_entry_iceberg()
            is_success = iceberg_insert_audit_res[1]
            logger.info(" Response of audit_entry_iceberg ....")
            logger.info(is_success)

            logger.info("Update etl_master table .......*****")
            update_etl_master_entry_obj = AuditUtility(job_dict, etl_config)
            iceberg_update_etl_master_res, success = update_etl_master_entry_obj.Update_ETL_Master_Entry_Iceberg()
            is_success = iceberg_update_etl_master_res[1]
            logger.info(" Response of Update_ETL_Master_Entry_Iceberg .....")
            logger.info(is_success)
        is_error = None
        return is_success, is_error
    except Exception as e:

        success = False
        logger.error(" Exception : ")
        logger.error(str(e))
        is_error = str(e)
        return success, is_error


def update_etl_master(job_dict, df, etl_config: ETLConfig):
    try:

        logger.info("Audit is False")
        records_count = df.count()
        job_dict["records_count"] = records_count
        logger.info("Total record are :{}".format(records_count))
        if job_dict["load_type"] == "incremental" or job_dict["load_type"] == "merge":
            if records_count > 0:
                incremental_column = job_dict["incremental_column"]
                # logger.info("MAX BY Incremental column")
                df_max_value = df.agg({incremental_column: "max"}).collect()[0][0]
                str_df_max_value = "'" + str(df_max_value) + "'"
                job_dict["df_max_value"] = str_df_max_value
            elif job_dict["incremental_value"] == 'nan' or job_dict["incremental_value"] == "None" or job_dict[
                "incremental_value"] == "<NA>":
                job_dict["df_max_value"] = "'" + \
                                           str(job_dict["startdatetime"]) + "'"
                logger.info("MAX BY startdatetime")
            else:
                offset_value_old = int(float(job_dict["incremental_value"]))
                job_dict["df_max_value"] = "'" + str(offset_value_old) + "'"
                logger.info("MAX BY offset_value")
        if job_dict['redshiftConnDetails'] != 'NA':
            logger.info("Update_ETL_Master_Entry call to redshift")
            audit_utility_obj = AuditUtility(job_dict, etl_config)
            d, success = audit_utility_obj.update_etl_master_entry()
            is_success = d[1]
            logger.info(" Response of update_etl_master_entry .....&&&&")
            logger.info(is_success)


        else:
            logger.info("Update_ETL_Master_Entry_Iceberg entry call to iceberg")
            etl_master_entry_iceberg_obj = AuditUtility(job_dict, etl_config)
            d, success = etl_master_entry_iceberg_obj.Update_ETL_Master_Entry_Iceberg()
            is_success = d[1]
            logger.info(" Response of Update_ETL_Master_Entry_Iceberg : ****")
            logger.info(is_success)
        is_error = None
        return is_success, is_error
    except Exception as e:
        logger.error(str(e))
        is_success = False
        is_error = str(e)
        return is_success, is_error


def update_audit_etl_master_s3_files(
        spark,
        job_dict,
        etl_config
):

    logger.info("Entered update_audit_etl_master_s3_files")

    tz = ZoneInfo(etl_config.timezone_param)
    logger.info(f"Timezone configured: {etl_config.timezone_param}")

    audit_table = (
        f"uipl.{etl_config.iceberg_db}."
        f"{etl_config.iceberg_audit_table_name}"
    )
    logger.info(f"Audit table resolved: {audit_table}")

    job_name = etl_config.job_name
    record_count = job_dict.get("records_count")
    status = job_dict.get("status", "SUCCESS")
    exception_desc = job_dict.get("exception_description", "")
    file_name = job_dict.get("file_name", "")
    start_time = job_dict.get("start_time")
    end_time = job_dict.get("end_time")
    source = job_dict.get("source", "")
    load_type = job_dict.get("load_type", "")
    business_unit = job_dict.get("business_unit", "")
    table_name = job_dict.get("table_name", "")
    '''
    logger.info(f"Job dict values extracted:")
    logger.info(f"Glue job name: {job_name}")
    logger.info(f"  table_name: {table_name}")
    logger.info(f"  business_unit: {business_unit}")
    logger.info(f"  record_count: {record_count}")
    logger.info(f"  status: {status}")
    logger.info(f"  file_name: {file_name}")
    logger.info(f"  load_type: {load_type}")
    logger.info(f"  source: {source}")
    logger.info(f"  start_time: {start_time}")
    logger.info(f"  end_time: {end_time}")
    '''
    insert_timestamp = datetime.now(tz)
    #logger.info(f"Insert timestamp: {insert_timestamp}")

    if start_time and end_time:
        job_runtime = str(end_time - start_time)
    else:
        job_runtime = ""

    #logger.info(f"Job runtime calculated: {job_runtime}")

    if exception_desc:
        safe_exception = exception_desc.replace("'", " ").replace("\n", " ")
        exception_sql = f"'{safe_exception[:4000]}'"
        logger.info(f"Exception description sanitized")
    else:
        exception_sql = "NULL"

    if record_count is None or record_count == "":
        record_count_sql = "NULL"
    else:
        record_count_sql = str(record_count)

    logger.info(f"Record count SQL value: {record_count_sql}")
    #logger.info(f"Exception SQL value: {exception_sql}")
    # TIMESTAMP '{insert_timestamp.strftime("%Y-%m-%d %H:%M:%S")}',
    insert_query = f"""
        INSERT INTO {audit_table} (
            glue_job_name,
            table_name,
            business_unit,
            job_runtime,
            record_count,
            insert_timestamp,
            status,
            exception_description,
            jobconfig,
            inventory_last_modified_date,
            file_name,
            load_type,
            start_time,
            end_time,
            source
        )
        VALUES (
            '{job_name}',
            '{table_name}',
            '{business_unit}',
            '{job_runtime}',
            {record_count_sql},
            '{insert_timestamp.strftime("%Y-%m-%d %H:%M:%S")}',
            '{status}',
            {exception_sql},
            '',
            '',
            '{file_name}',
            '{load_type}',
            TIMESTAMP '{start_time.strftime("%Y-%m-%d %H:%M:%S")}',
            TIMESTAMP '{end_time.strftime("%Y-%m-%d %H:%M:%S")}',
            '{source}'
        )
    """

    logger.info("Executing audit table INSERT query")
    single_line_query = " ".join(insert_query.split())
    logger.info(f"AUDIT INSERT QUERY: {single_line_query}")

    try:
        spark.sql(insert_query)
        logger.info("Audit table INSERT executed successfully")
    except Exception:
        logger.exception("Audit table INSERT failed")


    logger.info("Exiting update_audit_etl_master_s3_files successfully")
    return True, None