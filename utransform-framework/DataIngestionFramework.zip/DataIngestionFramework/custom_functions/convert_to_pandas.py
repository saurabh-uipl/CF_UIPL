from ..analytics_utilities.secrets_manager import SecretsManager

import logging

from ..src.etl_config import ETLConfig

logger = logging.getLogger("my_logger")


def convert_to_pandas(redshift_secret_name, etl_config: ETLConfig):
    """
    Args:
      redshift_secret_name:
      etl_config:

    Returns:
        dp_pandas:
        redshiftConnDetails:
    """
    try:
        sam_utility = SecretsManager(redshift_secret_name, etl_config)
        d = sam_utility.get_secret_name()
        redshiftConnDetails = d[1]
        table_name = """(select * from {redshift_schema_name}.
        etl_master where groupid = {job_id} and active = 1 order by Priority)""".format(
            job_id=etl_config.job_id, redshift_schema_name=etl_config.redshift_schema_name)
        df = etl_config.glueContext.read.format("jdbc").option("driver", str(redshiftConnDetails['driver'])).option(
            "url",
            str(
                redshiftConnDetails[
                    'jdbcURL'])).option(
            "dbtable", table_name).option("user", str(redshiftConnDetails['user'])).option("password",
                                                                                           str(
                                                                                               redshiftConnDetails[
                                                                                                   'password'])).load()

        dp_pandas = df.toPandas()
        logger.info('{}'.format(dp_pandas))
        return dp_pandas, redshiftConnDetails
    except Exception as e:
        logger.error(str(e))
