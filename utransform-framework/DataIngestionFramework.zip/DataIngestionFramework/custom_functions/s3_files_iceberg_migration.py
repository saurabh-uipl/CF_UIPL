import boto3
import uuid
import shutil
import tempfile
import zipfile
import os
import re
from datetime import datetime
from zoneinfo import ZoneInfo
#from backports.zoneinfo import ZoneInfo
import logging
from ..custom_functions.update_audit_etl_master import (
    update_audit_etl_master_s3_files
)
from ..custom_functions.write_to_iceberg_table import write_to_iceberg_table
from ..custom_functions.send_job_notifications import send_s3_iceberg_batch_only
logger = logging.getLogger("my_logger")
# Global notification guard
_start_mail_sent = False
# ==========================================================
# Helpers
# ==========================================================

def sanitize_column_name(col):
    #logger.info(f"Sanitizing column name: {col}")
    try:
        sanitized = re.sub(r"[^a-z0-9_]", "_", col.strip().lower())
        #logger.info(f"Sanitized column: {col} -> {sanitized}")
        return sanitized
    except Exception as e:
        logger.exception(f"Failed to sanitize column: {col}")
        raise Exception(f"Failed to sanitize column: {col}") from e


def extract_zip(s3_client, bucket, key, temp_bucket, logger):
    try:
        logger.info(f"Extracting ZIP file: {key}")
        logger.info(f"Source bucket: {bucket}, Temp bucket: {temp_bucket}")

        tmp_dir = tempfile.mkdtemp()
        zip_path = os.path.join(tmp_dir, "input.zip")
        logger.info(f"Temporary directory created: {tmp_dir}")

        s3_client.download_file(bucket, key, zip_path)
        logger.info(f"Downloaded ZIP to: {zip_path}")

        with zipfile.ZipFile(zip_path, "r") as z:
            logger.info(f"ZIP contains files: {z.namelist()}")
            z.extractall(tmp_dir)

        s3_paths = []
        prefix = f"_tmp_extracted/{uuid.uuid4().hex}/"
        logger.info(f"Temporary S3 prefix: {prefix}")

        for root, _, files in os.walk(tmp_dir):
            for f in files:
                if f.startswith(".") or f.lower().endswith(".zip"):
                    logger.info(f"Skipping file inside ZIP: {f}")
                    continue

                local_path = os.path.join(root, f)
                rel_path = os.path.relpath(local_path, tmp_dir)
                s3_key = f"{prefix}{rel_path.replace(os.sep, '/')}"

                logger.info(f"Uploading extracted file: {local_path} to {s3_key}")
                s3_client.upload_file(local_path, temp_bucket, s3_key)
                s3_paths.append(f"s3://{temp_bucket}/{s3_key}")

        logger.info(f"ZIP extraction completed: {len(s3_paths)} files uploaded")
        return tmp_dir, s3_paths, prefix

    except Exception:
        logger.exception(f"ZIP extraction failed for file: {key}")
        raise


def delete_s3_prefix(s3_client, bucket, prefix, logger):
    try:
        logger.info(f"Deleting temporary S3 prefix: {prefix}")
        paginator = s3_client.get_paginator("list_objects_v2")
        batch = []

        for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
            logger.info(f"Scanning page for deletion under prefix: {prefix}")
            for obj in page.get("Contents", []):
                batch.append({"Key": obj["Key"]})
                logger.info(f"Marked for deletion: {obj['Key']}")

                if len(batch) == 1000:
                    logger.info("Deleting batch of 1000 objects")
                    s3_client.delete_objects(Bucket=bucket, Delete={"Objects": batch})
                    batch = []

        if batch:
            logger.info(f"Deleting final batch of {len(batch)} objects")
            s3_client.delete_objects(Bucket=bucket, Delete={"Objects": batch})

        logger.info("Temporary S3 cleanup completed")

    except Exception:
        logger.exception("Failed during S3 cleanup")


# ==========================================================
# MAIN FUNCTION
# ==========================================================
'''
def run_s3_files_iceberg_job(job_dict, etl_config):
    spark = etl_config.glueContext
    region = etl_config.region_name
    logger.info("Entered run_s3_files_iceberg_job")
    logger.info(f"Region: {region}")
    tz = ZoneInfo(etl_config.timezone_param)
    logger.info(f"Timezone configured: {etl_config.timezone_param}")

    try:
        logger.info("Initializing S3 client")
        s3 = boto3.client("s3", region_name=region)
    except Exception:
        logger.exception("S3 client initialization failed")
        raise
    metadata_table = (
        f"uipl.{etl_config.iceberg_db}."
        f"{etl_config.iceberg_etl_master_table_name}"
    )

    logger.info(f"Metadata table: {metadata_table}")

    job_start_ts = datetime.now(tz)
    # store batch + start time in job_dict
    job_dict["start_time"] = job_start_ts
    global _start_mail_sent
    if not _start_mail_sent:
        send_s3_iceberg_batch_only(etl_config, job_dict, "STARTED")
        _start_mail_sent = True

    try:
        logger.info("Fetching metadata configuration")
        metadata = spark.sql(f"""
            SELECT *
            FROM {metadata_table}
            WHERE groupid = {job_dict["JOBID"]}
              AND active = 1
              AND lower(source) = 's3_files'
              AND lower(destination_type) = 'iceberg'
              order by priority asc
        """).collect()

        logger.info(f"Metadata rows fetched: {len(metadata)}")

        if not metadata:
            logger.error("No active metadata row found")
            raise Exception("No active metadata row found")

        r = metadata[0]
        #logger.info(f"Metadata row: {r}")

        folder = r.folder_name.replace("s3://", "")
        bucket = folder.split("/")[0]
        prefix = "/".join(folder.split("/")[1:])

        logger.info(f"S3 bucket: {bucket}")
        logger.info(f"S3 prefix: {prefix}")

        separator = r.fieldseparator or ","
        file_prefix = r.file_prefix

        logger.info(f"Separator: {separator}")
        logger.info(f"File prefix filter: {file_prefix}")

        last_ts = r.last_s3_file_timestamp
        if last_ts:
            last_ts = last_ts.replace(tzinfo=tz)
        else:
            last_ts = datetime(1970, 1, 1, tzinfo=tz)

        logger.info(f"Last processed timestamp: {last_ts}")

        target = f"uipl.{r.targetdatabasename}.{r.targettable}"
        logger.info(f"Target Iceberg table: {target}")

        # ================= S3 SCAN =================
        file_start_ts = datetime.now(tz)

        logger.info("Scanning S3 for new files")
        new_files = []
        paginator = s3.get_paginator("list_objects_v2")

        for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
            for obj in page.get("Contents", []):
                key = obj["Key"]

                if key.endswith("/"):
                    continue

                if file_prefix and not key.split("/")[-1].startswith(file_prefix):
                    continue

                modified = obj["LastModified"].astimezone(tz)

                if modified > last_ts:
                    logger.info(f"New file detected: {key}")
                    new_files.append((key, modified))

        new_files.sort(key=lambda x: x[1])
        logger.info(f"Total new files detected: {len(new_files)}")

        if not new_files:
            logger.info("No new files found")
            start_ts= datetime.now(tz)
            job_dict.update({
                "records_count": "",
                "file_name": r.folder_name,
                "start_time": file_start_ts,
                "end_time": datetime.now(tz),
                "status": "SKIPPED",
                "exception_description": "",
                "source": r.source,
                "load_type": r.loadtype,
                "table_name": r.targettable,
                "business_unit": ""
            })

            logger.info("Updating audit table with SKIPPED status")
            update_audit_etl_master_s3_files(spark, job_dict, etl_config)
            # SEND COMPLETION MAIL EVEN FOR SKIPPED
            job_dict.update({
                "start_time": job_start_ts,
                "end_time": datetime.now(tz)

            })

            send_s3_iceberg_batch_only(etl_config, job_dict, "COMPLETED")

            return True, None

        if r.loadtype.strip().lower() == "full load":
            logger.info("Full load detected — selecting latest file only")
            new_files = [max(new_files, key=lambda x: x[1])]

        max_ts = last_ts

        # ================= FILE PROCESS =================
        for key, modified in new_files:

            logger.info(f"Processing file: {key}")
            file_start = datetime.now(tz)

            tmp_dir = None
            tmp_prefix = None

            try:
                reader = (
                    spark.read.format("csv")
                    .option("header", "true")
                    .option("sep", separator)
                )

                if key.lower().endswith(".zip"):
                    logger.info("ZIP file detected")
                    tmp_dir, paths, tmp_prefix = extract_zip(
                        s3, bucket, key, job_dict["temp_bucket"], logger
                    )
                    df = reader.csv(paths)
                else:
                    df = reader.csv(f"s3://{bucket}/{key}")

                #if df.head(1) == []:
                if df.rdd.isEmpty():
                    logger.warning("File empty — skipping")
                    continue

                logger.info("Sanitizing DataFrame columns")
                df = df.toDF(*[sanitize_column_name(c) for c in df.columns])

                df = df.cache()
                record_count = df.count()
                logger.info(f"Record count: {record_count}")

                effective_load = r.loadtype
                logger.info(f"Load type: {effective_load}")

                if effective_load.lower() == "full load":
                    logger.info("Executing FULL LOAD write")
                    job_dict.update({
                        "table_name": r.targettable,
                        "load_type": r.loadtype
                    })

                    iceberg_dict, is_error = write_to_iceberg_table(
                        df, job_dict, etl_config
                    )

                    if is_error:
                        raise Exception(is_error)

                elif effective_load.lower() == "merge":
                    logger.info("Executing MERGE load")
                    job_dict.update({
                        "table_name": r.targettable,
                        "load_type": r.loadtype,
                        "pk_column": r.pk_columns
                    })

                    iceberg_dict, is_error = write_to_iceberg_table(
                        df, job_dict, etl_config
                    )

                    if is_error:
                        raise Exception(is_error)
                else:
                    logger.info("Executing DEFAULT load")
                    job_dict.update({
                        "table_name": r.targettable,
                        "load_type": r.loadtype
                    })

                    iceberg_dict, is_error = write_to_iceberg_table(
                        df, job_dict, etl_config
                    )

                    if is_error:
                        raise Exception(is_error)

                logger.info("Updating audit table with SUCCESS status")
                job_dict.update({
                    "records_count": record_count,
                    "file_name": key,
                    "start_time": file_start,
                    "end_time": datetime.now(tz),
                    "status": "SUCCESS",
                    "exception_description": "",
                    "source": r.source,
                    "load_type": r.loadtype,
                    "table_name": r.targettable,
                    "business_unit": ""
                })

                update_audit_etl_master_s3_files(spark, job_dict, etl_config)
                max_ts = modified

            except Exception as file_error:
                logger.exception(f"File processing failed: {key}")

                job_dict.update({
                    "records_count": "",
                    "file_name": key,
                    "start_time": file_start,
                    "end_time": datetime.now(tz),
                    "status": "Failed",
                    "exception_description": str(file_error),
                    "source": r.source,
                    "load_type": r.loadtype,
                    "table_name": r.targettable,
                    "business_unit": ""
                })

                update_audit_etl_master_s3_files(
                    spark,
                    job_dict,
                    etl_config
                )

                continue

            finally:
                if key.lower().endswith(".zip"):
                    logger.info("Cleaning up temporary ZIP resources")
                    if tmp_dir:
                        shutil.rmtree(tmp_dir, ignore_errors=True)
                    if tmp_prefix:
                        delete_s3_prefix(
                            s3,
                            job_dict["temp_bucket"],
                            tmp_prefix,
                            logger
                        )

        logger.info("Updating metadata table with latest timestamp")
        spark.sql(f"""
            UPDATE {metadata_table}
            SET last_s3_file_timestamp =
                TIMESTAMP '{max_ts.strftime("%Y-%m-%d %H:%M:%S")}'
            WHERE id = {job_dict["id"]}
        """)

        job_dict.update({
            "start_time": job_start_ts,
            "end_time": datetime.now(tz)
        })

        send_s3_iceberg_batch_only(etl_config, job_dict, "COMPLETED")
        #logger.info("===== S3_FILES JOB COMPLETED SUCCESSFULLY =====")

        return True, None

    except Exception as e:
        logger.exception(f"S3_FILES job failed: {str(e)}")

        job_dict.update({
            "records_count": "",
            "status": "Failed",
            "exception_description": str(e),
            "start_time": job_start_ts,
            "end_time": datetime.now(tz),
            "source": "s3_files"
        })

        update_audit_etl_master_s3_files(
            spark,
            job_dict,
            etl_config
        )

        return False, str(e)

'''

def run_s3_files_iceberg_job(job_dict, etl_config):
    spark = etl_config.glueContext
    region = etl_config.region_name
    logger.info("Entered run_s3_files_iceberg_job")
    logger.info(f"Region: {region}")
    tz = ZoneInfo(etl_config.timezone_param)
    logger.info(f"Timezone configured: {etl_config.timezone_param}")

    try:
        logger.info("Initializing S3 client")
        s3 = boto3.client("s3", region_name=region)
    except Exception:
        logger.exception("S3 client initialization failed")
        raise

    metadata_table = (
        f"uipl.{etl_config.iceberg_db}."
        f"{etl_config.iceberg_etl_master_table_name}"
    )

    logger.info(f"Metadata table: {metadata_table}")

    job_start_ts = datetime.now(tz)
    job_dict["start_time"] = job_start_ts

    global _start_mail_sent
    if not _start_mail_sent:
        send_s3_iceberg_batch_only(etl_config, job_dict, "STARTED")
        _start_mail_sent = True

    try:
        logger.info("Fetching metadata configuration")

        metadata = spark.sql(f"""
            SELECT *
            FROM {metadata_table}
            WHERE groupid = {job_dict["JOBID"]}
              AND active = 1
              AND lower(source) = 's3_files'
              AND lower(destination_type) = 'iceberg'
            ORDER BY priority asc
        """).collect()

        logger.info(f"Metadata rows fetched: {len(metadata)}")

        if not metadata:
            logger.error("No active metadata row found")
            raise Exception("No active metadata row found")

        # ==========================================================
        # LOOP THROUGH ALL METADATA ROWS (MULTI-TABLE SUPPORT)
        # ==========================================================

        for r in metadata:

            logger.info(f"Processing metadata ID: {r.id}")

            folder = r.folder_name.replace("s3://", "")
            bucket = folder.split("/")[0]
            prefix = "/".join(folder.split("/")[1:])

            logger.info(f"S3 bucket: {bucket}")
            logger.info(f"S3 prefix: {prefix}")

            separator = r.fieldseparator or ","
            file_prefix = r.file_prefix

            logger.info(f"Separator: {separator}")
            logger.info(f"File prefix filter: {file_prefix}")

            last_ts = r.last_s3_file_timestamp
            if last_ts:
                last_ts = last_ts.replace(tzinfo=tz)
            else:
                last_ts = datetime(1970, 1, 1, tzinfo=tz)

            logger.info(f"Last processed timestamp: {last_ts}")

            target = f"uipl.{r.targetdatabasename}.{r.targettable}"
            logger.info(f"Target Iceberg table: {target}")

            # ================= S3 SCAN =================
            file_start_ts = datetime.now(tz)
            logger.info("Scanning S3 for new files")
            new_files = []
            paginator = s3.get_paginator("list_objects_v2")

            for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
                for obj in page.get("Contents", []):
                    key = obj["Key"]

                    if key.endswith("/"):
                        continue

                    if file_prefix and not key.split("/")[-1].startswith(file_prefix):
                        continue

                    modified = obj["LastModified"].astimezone(tz)

                    if modified > last_ts:
                        logger.info(f"New file detected: {key}")
                        new_files.append((key, modified))

            new_files.sort(key=lambda x: x[1])
            logger.info(f"Total new files detected: {len(new_files)}")

            if not new_files:
                logger.info("No new files found")

                job_dict.update({
                    "records_count": "",
                    "file_name": r.folder_name,
                    "start_time": file_start_ts,
                    "end_time": datetime.now(tz),
                    "status": "SKIPPED",
                    "exception_description": "",
                    "source": r.source,
                    "load_type": r.loadtype,
                    "table_name": r.targettable,
                    "business_unit": ""
                })

                update_audit_etl_master_s3_files(
                    spark, job_dict, etl_config
                )

                continue  # DO NOT RETURN

            if r.loadtype.strip().lower() == "full load":
                logger.info("Full load detected — selecting latest file only")
                new_files = [max(new_files, key=lambda x: x[1])]

            max_ts = last_ts

            # ================= FILE PROCESS =================

            for key, modified in new_files:

                logger.info(f"Processing file: {key}")
                file_start = datetime.now(tz)

                tmp_dir = None
                tmp_prefix = None

                try:
                    reader = (
                        spark.read.format("csv")
                        .option("header", "true")
                        .option("sep", separator)
                    )

                    # ================= ZIP LOGIC KEPT =================

                    if key.lower().endswith(".zip"):
                        logger.info("ZIP file detected")
                        tmp_dir, paths, tmp_prefix = extract_zip(
                            s3, bucket, key, job_dict["temp_bucket"], logger
                        )
                        df = reader.csv(paths)
                    else:
                        df = reader.csv(f"s3://{bucket}/{key}")

                    if df.rdd.isEmpty():
                        logger.warning("File empty — skipping")
                        continue

                    logger.info("Sanitizing DataFrame columns")
                    df = df.toDF(
                        *[sanitize_column_name(c) for c in df.columns]
                    )

                    df = df.cache()
                    record_count = df.count()
                    logger.info(f"Record count: {record_count}")

                    effective_load = r.loadtype
                    logger.info(f"Load type: {effective_load}")

                    if effective_load.lower() == "full load":
                        logger.info("Executing FULL LOAD write")
                        job_dict.update({
                            "table_name": r.targettable,
                            "load_type": r.loadtype
                        })

                        iceberg_dict, is_error = write_to_iceberg_table(
                            df, job_dict, etl_config
                        )

                        if is_error:
                            raise Exception(is_error)

                    elif effective_load.lower() == "merge":
                        logger.info("Executing MERGE load")
                        job_dict.update({
                            "table_name": r.targettable,
                            "load_type": r.loadtype,
                            "pk_column": r.pk_columns
                        })

                        iceberg_dict, is_error = write_to_iceberg_table(
                            df, job_dict, etl_config
                        )

                        if is_error:
                            raise Exception(is_error)

                    else:
                        logger.info("Executing DEFAULT load")
                        job_dict.update({
                            "table_name": r.targettable,
                            "load_type": r.loadtype
                        })

                        iceberg_dict, is_error = write_to_iceberg_table(
                            df, job_dict, etl_config
                        )

                        if is_error:
                            raise Exception(is_error)

                    logger.info("Updating audit table with SUCCESS status")

                    job_dict.update({
                        "records_count": record_count,
                        "file_name": key,
                        "start_time": file_start,
                        "end_time": datetime.now(tz),
                        "status": "SUCCESS",
                        "exception_description": "",
                        "source": r.source,
                        "load_type": r.loadtype,
                        "table_name": r.targettable,
                        "business_unit": ""
                    })

                    update_audit_etl_master_s3_files(
                        spark, job_dict, etl_config
                    )

                    max_ts = modified

                except Exception as file_error:
                    logger.exception(f"File processing failed: {key}")

                    job_dict.update({
                        "records_count": "",
                        "file_name": key,
                        "start_time": file_start,
                        "end_time": datetime.now(tz),
                        "status": "Failed",
                        "exception_description": str(file_error),
                        "source": r.source,
                        "load_type": r.loadtype,
                        "table_name": r.targettable,
                        "business_unit": ""
                    })

                    update_audit_etl_master_s3_files(
                        spark, job_dict, etl_config
                    )

                finally:
                    # ================= ZIP CLEANUP KEPT =================
                    if key.lower().endswith(".zip"):
                        logger.info("Cleaning up temporary ZIP resources")
                        if tmp_dir:
                            shutil.rmtree(tmp_dir, ignore_errors=True)
                        if tmp_prefix:
                            delete_s3_prefix(
                                s3,
                                job_dict["temp_bucket"],
                                tmp_prefix,
                                logger
                            )

            # ================= METADATA UPDATE =================

            logger.info(f"Updating metadata table for ID {r.id}")

            spark.sql(f"""
                UPDATE {metadata_table}
                SET last_s3_file_timestamp =
                    TIMESTAMP '{max_ts.strftime("%Y-%m-%d %H:%M:%S")}'
                WHERE id = {r.id}
            """)

        # ==========================================================
        # SEND COMPLETION MAIL AFTER ALL TABLES FINISH
        # ==========================================================

        job_dict.update({
            "start_time": job_start_ts,
            "end_time": datetime.now(tz)
        })

        send_s3_iceberg_batch_only(etl_config, job_dict, "COMPLETED")

        return True, None

    except Exception as e:
        logger.exception(f"S3_FILES job failed: {str(e)}")

        job_dict.update({
            "records_count": "",
            "status": "Failed",
            "exception_description": str(e),
            "start_time": job_start_ts,
            "end_time": datetime.now(tz),
            "source": "s3_files"
        })

        update_audit_etl_master_s3_files(
            spark, job_dict, etl_config
        )

        return False, str(e)