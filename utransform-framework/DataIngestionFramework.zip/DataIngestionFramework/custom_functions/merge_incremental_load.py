import datetime
import pytz

from ..start_ingestion.start_ingestion import start_ingestion
import logging
from .insert_failed_tables import add_failed_table_entry

from ..src.etl_config import ETLConfig

logger = logging.getLogger("my_logger")


def merge_incremental_load(job_dict, source_conn_details, etl_config: ETLConfig):
    """
    Perform ETL (Extract, Transform, Load) based on the provided job dictionary.

    Args:
    :job_dict:
    :source_conn_details:
    :etl_config:


    Returns:
        dict: A dictionary containing the success and failure job lists.



    """
    try:
        logger.info("executing merge_incremental_load ... ")
        success = True
        if job_dict["enddatetime"] in ["None", "NaT"] and job_dict["incremental_value"] in ["None", "nan", "<NA>"]:

            logger.info(" enddatetime == None and incremental_value == <NA>")
            word = str(job_dict["SQL_Query"])
            logger.info(" Word: **** {}".format(word))

            if word.find('{startdatetime}') != -1:
                logger.info("word.find({startdatetime}) != -1 ")
                startdatetime = "'" + job_dict["startdatetime"] + "'"
                sql_query = job_dict["SQL_Query"].format(startdatetime=startdatetime,
                                                         enddatetime=job_dict["enddatetime"])
                logger.info(" sql_query:{}".format(sql_query))

                index = sql_query.rfind(' and ')
                logger.info(" index:  **** {}".format(index))

                '''
                if index > 0:
                    logger.info(" index > 0: ")
                    sub1 = sql_query[index:len(sql_query)]
                    sql_query = sql_query.replace(sub1, "").rstrip()
                '''
                sql_query = "(" + sql_query + ") as t"
                job_dict["SQL_Query"] = sql_query


            else:

                sql_query = job_dict["SQL_Query"]
                sql_query = "(" + sql_query + ") as t"
                job_dict["SQL_Query"] = sql_query

            logger.info(" Call start_ingestion: ")
            res, is_error = start_ingestion(job_dict, source_conn_details, etl_config)

            logger.info(" Response Of start_ingestion: ********** {}".format(res))

            if 's3_' not in job_dict["source"]:
                if 'df_max_value' in job_dict:
                    if job_dict['source'].lower() == 'rest_api':
                        logger.info("pulled_until date for rest_api.....")
                        pulled_until = job_dict["df_max_value"]
                    else:

                        logger.info("job_dict[df_max_value]......")
                        logger.info(job_dict["df_max_value"])
                        if job_dict['source'].lower() == 'mongodb':
                            logger.info("source is mongodb")
                            pulled_until = str(job_dict["df_max_value"])
                        else:
                            pulled_until = datetime.datetime.strptime(str(job_dict["df_max_value"]).split('.')[0].replace('"', '')[1:-1],
                                                                      etl_config.date_format)
                        logger.info(" pulled_until: ...")
                        logger.info(str(pulled_until))
                else:
                    pulled_until = ''

            else:
                pulled_until = ''
            if res > 0:
                logger.info(" res > 0 ...")
                logger.info(" prepare sns_dict ......")

                table_name_last_char = job_dict["table_name"][len(job_dict["table_name"]) - 1]
                logger.info("table_name_last_char: " + str(table_name_last_char))
                if table_name_last_char == '/':
                    updated_table_name = job_dict["table_name"].split('/')[-2]
                else:
                    updated_table_name = job_dict["table_name"].split('/')[-1]
                # logger.info("updated_table_name: ")
                # logger.info(updated_table_name)
                sns_dict = {
                    "Jod_Id": job_dict["JOBID"],
                    "Job_Name": job_dict["JOBNAME"],
                    "Load_Type": job_dict["load_type"],
                    "status": "succeed",
                    "Table_Name": updated_table_name,
                    "Start_Time": str(job_dict["initial_time_stamp"])[0:19],
                    "End_Time": str(datetime.datetime.now(pytz.timezone(etl_config.timezone_param)))[0:19],
                    "Execution_Time": str(datetime.datetime.now(pytz.timezone(etl_config.timezone_param)) - job_dict[
                        "initial_time_stamp"]),
                    "Total_Records_Pulled": job_dict["records_count"],
                    "Source_Data_Pulled_From": str(
                        datetime.datetime.strptime(str(job_dict["startdatetime"])[0:19], etl_config.date_format)),
                    "Source_Data_Pulled_Untill": str(pulled_until)
                }
                # logger.info(sns_dict)
                # logger.info(" sns_dict : ***:{} ".format(sns_dict))
                logger.info(" Adding table in success table list: *********")
                etl_config.sns_list_success.append(sns_dict)
            else:
                logger.info(" Adding table in fail table list: ********")
                etl_config.sns_list_failure.append(job_dict["table_name"])
                ##########Write Failed Table Details In Audit Table
                add_failed_table_entry(job_dict, etl_config, logger, is_error)

        elif job_dict["incremental_value"] in ["None", "<NA>"]:
            logger.info("incremental_value in None/<NA> ...")
            startdatetime_obj = datetime.datetime.strptime(job_dict["startdatetime"], etl_config.date_format)
            enddatetime_obj = datetime.datetime.strptime(job_dict["enddatetime"], etl_config.date_format)
            if startdatetime_obj > enddatetime_obj:
                logger.info("End Date should be greater then start date")

            else:

                logger.info("Start date & End Date is OK")
                startdatetime = "'" + job_dict["startdatetime"] + "'"
                enddatetime = "'" + job_dict["enddatetime"] + "'"
                sql_query = job_dict["sql_query"].format(startdatetime=startdatetime,
                                                         enddatetime=enddatetime)
                sql_query = "(" + sql_query + ") as t"
                job_dict["job_dict"] = sql_query

                res, is_error = start_ingestion(job_dict, source_conn_details, etl_config)
                if res > 0:
                    sns_dict = {
                        "Jod_Id": job_dict["JOBID"],
                        "Job_Name": job_dict["JOBNAME"],
                        "Load_Type": job_dict["load_type"],
                        "status": "succeed",
                        "Table_Name": job_dict["table_name"],
                        "Start_Time": str(job_dict["initial_time_stamp"]),
                        "End_Time": str(datetime.datetime.now(pytz.timezone(etl_config.timezone_param))),
                        "Execution_Time": str(
                            datetime.datetime.now(pytz.timezone(etl_config.timezone_param)) - job_dict[
                                "initial_time_stamp"]),
                        "Total_Records_Pulled": job_dict["records_count"],
                        "Source_Data_Pulled_From": str(
                            datetime.datetime.strptime(job_dict["startdatetime"], etl_config.date_format)),
                        "Source_Data_Pulled_Until": str(
                            datetime.datetime.strptime(job_dict["enddatetime"], etl_config.date_format))
                    }
                    etl_config.sns_list_success.append(sns_dict)
                else:
                    etl_config.sns_list_failure.append(job_dict["table_name"])
                    ##########Write Failed Table Details In Audit Table
                    add_failed_table_entry(job_dict, etl_config, logger, is_error)
        else:

            offset_value = int(float(job_dict["incremental_value"]))

            sql_query = job_dict["SQL_Query"].format(offset_value=offset_value)
            sql_query = "(" + sql_query + ") as t"
            job_dict["SQL_Query"] = sql_query
            res, is_error = start_ingestion(job_dict, source_conn_details, etl_config)
            logger.info(" res : ****** {}".format(res))

            pulled_until = job_dict["df_max_value"][1:-1]
            if res > 0:
                sns_dict = {
                    "Jod_Id": job_dict["JOBID"],
                    "Job_Name": job_dict["JOBNAME"],
                    "Load_Type": job_dict["load_type"],
                    "status": "succeed",
                    "Table_Name": job_dict["table_name"],
                    "Start_Time": str(job_dict["initial_time_stamp"]),
                    "End_Time": str(datetime.datetime.now(pytz.timezone(etl_config.timezone_param))),
                    "Execution_Time": str(datetime.datetime.now(pytz.timezone(etl_config.timezone_param)) - job_dict[
                        "initial_time_stamp"]),
                    "Total_Records_Pulled": job_dict["records_count"],
                    "Source_Data_Pulled_From": str(offset_value),
                    "Source_Data_Pulled_Until": str(pulled_until)
                }
                etl_config.sns_list_success.append(sns_dict)
            else:
                etl_config.sns_list_failure.append(job_dict["table_name"])
                ##########Write Failed Table Details In Audit Table
                add_failed_table_entry(job_dict, etl_config, logger, is_error)

        return {
            "success": etl_config.sns_list_success,
            "failure": etl_config.sns_list_failure,
            "job_dict": job_dict
        }
    except Exception as e:

        logger.error(" Error Occured ....: *****")
        logger.error(str(e))

        return {
            "success": etl_config.sns_list_success,
            "failure": etl_config.sns_list_failure,
            "job_dict": job_dict
        }
