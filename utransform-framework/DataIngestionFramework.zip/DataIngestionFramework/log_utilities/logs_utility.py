import boto3
import json
import datetime
import logging


class LogsUtility:
    def __init__(self, JobName, BucketName):

        self.logs_dict = {}

        self.JobName = JobName
        self.BucketName = BucketName
        self.logger = logging.getLogger("my_logger")

        '''
        Args:
        JobName:
        BucketName:
      
        
        '''

    def write_logs(self):
        """
        Returns:
            logs_dict:
        """
        is_write = 0

        try:
            #self.logger.info("----------Writing Logs in S3 .................")
            #s3 = boto3.resource('s3')
            dateTimeObj = datetime.datetime.now()
            folderName = str(dateTimeObj.year) + '_' + str(dateTimeObj.month) + '_' + str(dateTimeObj.day)

            self.logger.info("*****Folder Name :{} ***********".format(str(folderName)))
            fileName = str(dateTimeObj.hour) + '_' + str(dateTimeObj.minute) + '_' + str(dateTimeObj.second)

            keyName = "glue_job_logs/" + folderName + "/" + self.JobName + "_" + fileName + ".txt"
            self.logger.info("*****Key Name :{} ***********".format(keyName))

            self.logger.info(
                "*****Data write in S3 in BucketName :{} and fileName is {} ***********".format(self.BucketName,
                                                                                                keyName))

            is_write = 1
            self.logs_dict = {1: is_write}
        except Exception as e:
            self.logger.error(str(e))
            is_write = 0

            self.logger.info("*****NoSuchKey ***********")
            self.logs_dict = {1: is_write}
        return self.logs_dict
