# log_utilities/__init__.py

from .logs_utility import LogsUtility
