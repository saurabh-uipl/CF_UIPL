# s3_data_ingestion/__init__.py

from .S3_data_ingestion import S3DataIngestion
