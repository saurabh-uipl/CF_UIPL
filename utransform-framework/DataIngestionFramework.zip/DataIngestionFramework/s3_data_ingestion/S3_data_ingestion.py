import pytz
import boto3
from pyspark.sql import functions as F
from ..common_utilities.Common_utility import CommonUtility
from ..audit_utilities.audit_utility import AuditUtility
from datetime import datetime, timedelta
import logging

from ..custom_functions.insert_failed_tables import add_failed_table_entry
from ..src.etl_config import ETLConfig
from ..custom_functions.write_to_iceberg_table import write_to_iceberg_table, write_to_iceberg_table_v1
from .data_ingestion_method import load_and_process_data,  load_and_process_data_v1,load_data_into_iceberg_table, load_into_iceberg
from .data_ingestion_method import align_dataframe_schema_with_iceberg_table, construct_s3_paths_for_full_load
from .data_ingestion_method import construct_s3_paths_from_date_range, update_audit_and_master_entries


class S3DataIngestion:
    def __init__(self, job_dict, etl_config: ETLConfig):
        self.logger = logging.getLogger("my_logger")
        self.path_list = []
        self.final_path_list = []
        self.is_table_present_flag = 0
        self.job_dict = job_dict
        self.etl_config = etl_config
        self.write_load_flag = 0

    '''
    Args:
        job_dict:
        redshift_schema_name:
        redshift_audit_table_name:
        redshift_etl_master_table_name:
        athena_db_name:
        glueContext:
        
    
    
    '''

    def s3_data_process(self):

        """
        Returns:
            is_success:

        """
        try:
            if len(self.job_dict["Partition_Column"]) > 0:
                Partition_Column_TABLE = str(self.job_dict["Partition_Column"])[1:-1].replace("'", '').lower()
            else:
                pass

            is_success = True

            spark = self.etl_config.glueContext

            schema_name = self.job_dict["schema_name"].split(",")

            start_date = self.job_dict["startdatetime"]

            start_date_formatted_daily = start_date[0:10]

            self.job_dict["inventory_table_name"] = self.job_dict["table_name"]

            tbl_name = self.job_dict["table_name"].split("/")
            self.logger.info(" *****************tbl_name : *********************")
            self.logger.info(tbl_name)
            self.logger.info(" **************TABLE_NAME ********************")
            self.logger.info(self.job_dict["table_name"])
            final_path_list = []
            if self.job_dict["load_type"] != "merge" and self.job_dict["load_type"] != "incremental":

                is_success_construct, final_path_list = construct_s3_paths_for_full_load(self.job_dict, self.logger, tbl_name, self.etl_config)
                self.logger.info("Execution completed for construct_s3_paths_for_full_load ....")

            else:
                is_success_construct, final_path_list = construct_s3_paths_from_date_range(self.job_dict, self.logger, start_date_formatted_daily, tbl_name, self.etl_config)
                self.logger.info("Execution completed for construct_s3_paths_from_date_range ....")
            self.logger.info(" final_path_list after preparing the s3_paths ......")
            self.job_dict["SQL_Query"] = self.job_dict["SQL_Query"].lstrip('(').rstrip('as t )')
            self.logger.info(" sql query ....")
            self.logger.info(self.job_dict["SQL_Query"])
            source = self.job_dict["source"].split('_')[-1]
            self.logger.info(" source.......")
            self.logger.info(source)
            self.logger.info(" calling load_and_process_data ......")
            df, is_success = load_and_process_data_v1(self.job_dict, final_path_list, schema_name, source, spark, self.logger, self.etl_config)

            self.logger.info(" is_success for load_and_process_data ...")
            if df is None:
                self.logger.info(" DF RETURNED EMPTY FROM load_and_process_data_v1 ......")
            else:
                self.logger.info(" DF Records Returned from load_and_process_data_v1 ........")
                self.logger.info(df.count())
            self.logger.info(is_success)
            is_error = None
            # df.show(1, False)
            return is_success, df, is_error
        except Exception as e:
            self.logger.error("An error occurred during S3 data processing:")
            self.logger.error(str(e))
            is_success = False
            df =  None
            is_error = str(e)
            add_failed_table_entry(self.job_dict, self.etl_config, self.logger, is_error)
            return is_success, df, is_error
