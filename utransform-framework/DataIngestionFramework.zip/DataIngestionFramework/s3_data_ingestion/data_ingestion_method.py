import pytz
import boto3
from pyspark.sql import functions as F
from ..common_utilities.Common_utility import CommonUtility
from ..audit_utilities.audit_utility import AuditUtility
from datetime import datetime, timedelta
from ..custom_functions.insert_failed_tables import add_failed_table_entry
from ..custom_functions.write_to_iceberg_table import write_to_iceberg_table_v1
from ..src.etl_config import ETLConfig


def load_and_process_data_v1(job_dict, final_path_list, schema_name, source, spark, logger, etl_config: ETLConfig):
    try:
        spark.conf.set('spark.sql.session.timeZone', etl_config.timezone_param)
        is_success = True
        logger.info(" inside load_and_process_data ......")
        logger.info(" final_path_list: ")
        logger.info(final_path_list)
        write_load_flag = 0

        if job_dict['business_unit'].lower() == 'haptik':
            if len(final_path_list) > 0:
                logger.info("Running for haptik source in data ingetstion method")
                path = final_path_list
                if source == "csv":
                    logger.info(" Reading CSV ....")
                    df = spark.read.option("header", "true").format(source).load(path)
                    df = df.where(~df['_c0'].isin(schema_name))
                    df = df.toDF(*schema_name)

                elif source == "json":
                    logger.info(" Reading json ....")
                    try:
                        df = spark.read.format(source).load(path)
                    except Exception as e:
                        df = spark.read.option("multiline", 'true').format(source).load(path)

                    if str(job_dict['json_flatten']) == '1':
                        df = CommonUtility.json_flatten(df)
                        logger.info(" Json flat is enabled .....")
                    else:
                        logger.info('json flatten is disabled')

                else:
                    logger.info(" Reading Parquet or non CSV/JSON ....")
                    df = spark.read.format(source).load(path)
                logger.info(" Table has been created successfully from s3 files .....")
                df.createOrReplaceTempView('table')
                logger.info(" sql_query ....:::")
                logger.info(job_dict["SQL_Query"])
                logger.info(" JOBNAME: ")
                logger.info(job_dict['JOBNAME'])
                df = spark.sql(job_dict["SQL_Query"])
                df.createOrReplaceTempView('df')
                sql_query_staging = "select *, from_utc_timestamp(current_timestamp(), '{TIMEZONE}') as pulled_time, " \
                                    "from_utc_timestamp(current_timestamp(), '{TIMEZONE}') as update_time, " \
                                    "from_utc_timestamp(current_timestamp(), '{TIMEZONE}') as bdl_created, '{pipeline_id}' as pipelineid from df"
                logger.info(" sql_query_staging ....")
                logger.info(sql_query_staging)
                sql_query_staging = sql_query_staging.format(TIMEZONE=etl_config.timezone_param, pipeline_id=job_dict['JOBNAME'])
                logger.info(" updated sql_query_staging ....")
                logger.info(sql_query_staging)
                spark.conf.set('spark.sql.session.timeZone', etl_config.timezone_param)
                df = spark.sql(sql_query_staging)
                logger.info(" Display DF with IST Timezone .....")
                df.show(1)
                df = df.withColumn('file_date', F.split(F.split(F.input_file_name(), '/')[9], 'T')[0])
                logger.info(" Display DF .......")
                logger.info(" display table schema .....")
                df.printSchema()
                logger.info(" calling Remove_Special_Character ......")
                table_name_list = job_dict["table_name"].split('/')
                table_name = table_name_list[len(table_name_list) - 2].replace('-', '_')
                if len(table_name.strip()) < 2:
                    table_name = table_name_list[len(table_name_list) - 2].replace('-', '_')

                dir_check = CommonUtility.remove_special_character(table_name)
                logger.info(" dir_check .....")
                logger.info(dir_check)
                table_names3_suported = dir_check[1]
                logger.info(" table_names3_supported.....".format(table_names3_suported))

                logger.info(table_names3_suported)
                job_dict["table_name"] = table_names3_suported
                logger.info('job_dict '.format(job_dict["table_name"]))
                df_columns = df.columns
                df_columns = [column.lower() for column in df_columns]
                df_final = df.toDF(*df_columns)
                logger.info(" calling write_to_iceberg_table_v1 ......")
                ###Pass df_final to JSON Flat function

                iceberg = write_to_iceberg_table_v1(df_final, job_dict, write_load_flag, etl_config, table_name)

                spark = iceberg[1]
                is_table_present_flag = iceberg[2]
                df_final = iceberg[3]

                temp_df = align_dataframe_schema_with_iceberg_table(job_dict, logger, df_final, spark, etl_config)

                try:
                    temp_df_1 = temp_df_1.unionByName(temp_df, allowMissingColumns=True)
                    logger.info(" Performed Union")
                    temp_df_1.printSchema()
                except Exception as e:
                    logger.error("exception 271")
                    temp_df_1 = temp_df
                    logger.error(" temp_df is assigned to temp_df_1")
                    logger.error(str(e))
                ##### For Loop Ends Here

                temp_df_1.createOrReplaceTempView('staging_table')
                logger.info("STAGING TABLE CREATED SUCCESSFULLY")
                logger.info(" count before row_num: ")
                temp_df_1_cnt = temp_df_1.count()
                logger.info(str(temp_df_1_cnt))
                temp_df_1.printSchema()
                if job_dict["load_type"] == "merge":
                    print("MERGE QUERY :", job_dict["merge_query"])
                    deltaDF = spark.sql(job_dict["merge_query"])
                    logger.info("merge_query executed SUCCESSFULLY")
                    deltaDF = deltaDF.drop('row_num')
                    logger.info("printing deltaDf")
                    df = deltaDF
                    df_final = deltaDF
                else:
                    df_final = temp_df_1
                df_final = df_final.drop('file_date')
                logger.info('counts in df_final after row_num')
                df_final_cnt = df_final.count()
                logger.info(str(df_final_cnt))
                write_load_flag = 1
                iceberg = write_to_iceberg_table_v1(df_final, job_dict, write_load_flag, etl_config, table_name)
                spark = iceberg[1]
                is_table_present_flag = iceberg[2]
                # df_final = iceberg[3]
                write_load_flag = 0
                # df = df_final
                return df_final, is_success
            else:
                logger.info('setting df as  none')
                df = None
                is_success = True
                return df, is_success



        else:
            if len(final_path_list) > 0:
                path_list_length = len(final_path_list)
                for i in range(path_list_length):
                    path = final_path_list.pop(0)
                    logger.info(" path: *****")
                    logger.info(path)
                    print('Processing Data Of Below path :', path)
                    logger.info("Processing Data Of Below path :")
                    logger.info(path)
                    logger.info(" source is ")
                    logger.info(source)
                    if source == "csv":
                        logger.info(" Reading CSV ....")
                        df = spark.read.option("header", "true").format(source).load(path)
                        df = df.where(~df['_c0'].isin(schema_name))
                        df = df.toDF(*schema_name)

                    elif source == "json":
                        logger.info(" Reading json ....")
                        try:
                            df = spark.read.format(source).load(path)
                        except Exception as e:
                            df = spark.read.option("multiline", 'true').format(source).load(path)

                        if str(job_dict['json_flatten']) == '1':
                            df = CommonUtility.json_flatten(df)
                            logger.info(" Json flat is enabled .....")
                        else:
                            logger.info('json flatten is disabled')

                    else:
                        logger.info(" Reading Parquet or non CSV/JSON ....")
                        df = spark.read.format(source).load(path)
                    logger.info(" Table has been created successfully from s3 files .....")
                    df.createOrReplaceTempView('table')
                    logger.info(" sql_query ....:::")
                    logger.info(job_dict["SQL_Query"])
                    logger.info(" JOBNAME: ")
                    logger.info(job_dict['JOBNAME'])
                    spark.conf.set('spark.sql.session.timeZone', etl_config.timezone_param)
                    df = spark.sql(job_dict["SQL_Query"])
                    df.createOrReplaceTempView('df')
                    sql_query_staging = "select *, from_utc_timestamp(current_timestamp(), '{TIMEZONE}') as pulled_time, " \
                                        "from_utc_timestamp(current_timestamp(), '{TIMEZONE}') as update_time, " \
                                        "from_utc_timestamp(current_timestamp(), '{TIMEZONE}') as bdl_created, '{pipeline_id}' as pipelineid from df"
                    logger.info(" sql_query_staging ....")
                    logger.info(sql_query_staging)
                    sql_query_staging = sql_query_staging.format(TIMEZONE=etl_config.timezone_param, pipeline_id=job_dict['JOBNAME'])
                    logger.info(" updated sql_query_staging ....")
                    logger.info(sql_query_staging)
                    spark.conf.set('spark.sql.session.timeZone', etl_config.timezone_param)
                    df = spark.sql(sql_query_staging)
                    df.show(1, False)
                    df = df.withColumn('file_date', F.split(F.split(F.input_file_name(), '/')[9], 'T')[0])
                    logger.info(" Display DF .......")
                    logger.info(" display table schema .....")
                    df.printSchema()
                    logger.info(" calling Remove_Special_Character ......")
                    table_name_list = job_dict["table_name"].split('/')
                    table_name = table_name_list[len(table_name_list) - 2].replace('-', '_')
                    if len(table_name.strip()) < 2:
                        table_name = table_name_list[len(table_name_list) - 2].replace('-', '_')

                    dir_check = CommonUtility.remove_special_character(table_name)
                    logger.info(" dir_check .....")
                    logger.info(dir_check)
                    table_names3_suported = dir_check[1]
                    logger.info(" table_names3_supported.....".format(table_names3_suported))

                    logger.info(table_names3_suported)
                    job_dict["table_name"] = table_names3_suported
                    logger.info('job_dict '.format(job_dict["table_name"]))
                    df_columns = df.columns
                    df_columns = [column.lower() for column in df_columns]
                    df_final = df.toDF(*df_columns)
                    logger.info(" calling write_to_iceberg_table_v1 ......")
                    logger.info(df_final)
                    ###Pass df_final to JSON Flat function
                    # if str(job_dict['json_flatten']) == '1':
                    #     logger.info(" Json flat is enabled .....")
                    #     df_final = CommonUtility.json_flatten(df_final)
                    # else:
                    #     logger.info(" Json Flat is disabled ....")

                    iceberg = write_to_iceberg_table_v1(df_final, job_dict, write_load_flag, etl_config, table_name)

                    spark = iceberg[1]
                    is_table_present_flag = iceberg[2]
                    df_final = iceberg[3]

                    temp_df = align_dataframe_schema_with_iceberg_table(job_dict, logger, df_final, spark, etl_config)

                    try:
                        temp_df_1 = temp_df_1.unionByName(temp_df, allowMissingColumns=True)
                        logger.info(" Performed Union")
                        temp_df_1.printSchema()
                    except Exception as e:
                        logger.error("exception 271")
                        temp_df_1 = temp_df
                        logger.error(" temp_df is assigned to temp_df_1")
                        logger.error(str(e))
                ##### For Loop Ends Here

                temp_df_1.createOrReplaceTempView('staging_table')
                logger.info("STAGING TABLE CREATED SUCCESSFULLY")
                logger.info(" count before row_num: ")
                temp_df_1_cnt = temp_df_1.count()
                job_dict['records_count'] = temp_df_1_cnt
                logger.info(str(temp_df_1_cnt))
                temp_df_1.printSchema()
                if job_dict["load_type"] == "merge":
                    print("MERGE QUERY :", job_dict["merge_query"])
                    deltaDF = spark.sql(job_dict["merge_query"])
                    logger.info("merge_query executed SUCCESSFULLY")
                    deltaDF = deltaDF.drop('row_num')
                    logger.info("printing deltaDf")
                    df = deltaDF
                    df_final = deltaDF
                else:
                    df_final = temp_df_1

                df_final = df_final.drop('file_date')
                logger.info('counts in df_final after row_num')
                df_final_cnt = df_final.count()
                logger.info(str(df_final_cnt))
                write_load_flag = 1
                iceberg = write_to_iceberg_table_v1(df_final, job_dict, write_load_flag, etl_config, table_name)
                spark = iceberg[1]
                is_table_present_flag = iceberg[2]
                # df_final = iceberg[3]
                write_load_flag = 0
                # df = df_final
                logger.info(" DISPLAY COUNTS ...........................")
                logger.info(str(df_final.count()))
                return df_final, is_success

            else:
                logger.info(" Path List Is Empty ............")
                logger.info(" calling Remove_Special_Character ......")
                table_name_list = job_dict["table_name"].split('/')
                table_name = table_name_list[len(table_name_list) - 2].replace('-', '_')
                if len(table_name.strip()) < 2:
                    table_name = table_name_list[len(table_name_list) - 2].replace('-', '_')

                dir_check = CommonUtility.remove_special_character(table_name)
                logger.info(" dir_check .....")
                logger.info(dir_check)
                table_names3_suported = dir_check[1]
                logger.info(" table_names3_supported.....".format(table_names3_suported))

                logger.info(table_names3_suported)
                job_dict["table_name"] = table_names3_suported
                logger.info('Setting  df as none ')
                df = None
                is_success = True
                return df, is_success
    except Exception as e:
        logger.error(" Error ...***&&&")
        logger.error(str(e))
        df = None
        is_success = False
        add_failed_table_entry(job_dict, etl_config, logger, str(e))
        return df, is_success


def load_and_process_data(job_dict, final_path_list, schema_name, source, spark, logger, etl_config: ETLConfig):
    try:
        spark.conf.set('spark.sql.session.timeZone', etl_config.timezone_param)
        is_success = True
        logger.info(" inside load_and_process_data ......")
        logger.info(" final_path_list: ")
        logger.info(final_path_list)
        write_load_flag = 0

        if len(final_path_list) > 0 and job_dict['business_unit'].lower() == 'salesforce':
            path_list_length = len(final_path_list)
            for i in range(path_list_length):
                path = final_path_list.pop(0)
                logger.info(" path: *****")
                logger.info(path)
                print('Processing Data Of Below path :', path)
                logger.info("Processing Data Of Below path :")
                logger.info(path)
                logger.info(" source is ")
                logger.info(source)
                if source == "csv":
                    logger.info(" Reading CSV ....")
                    df = spark.read.option("header", "true").format(source).load(path)
                    df = df.where(~df['_c0'].isin(schema_name))
                    df = df.toDF(*schema_name)

                elif source == "json":
                    logger.info(" Reading json ....")
                    try:
                        df = spark.read.format(source).load(path)
                    except Exception as e:
                        df = spark.read.option("multiline", 'true').format(source).load(path)

                    if str(job_dict['json_flatten']) == '1':
                        df = CommonUtility.json_flatten(df)
                        logger.info(" Json flat is enabled .....")
                    else:
                        logger.info('json flatten is disabled')

                else:
                    logger.info(" Reading Parquet or non CSV/JSON ....")
                    df = spark.read.format(source).load(path)
                logger.info(" Table has been created successfully from s3 files .....")
                df.createOrReplaceTempView('table')
                logger.info(" sql_query ....:::")
                logger.info(job_dict["SQL_Query"])
                logger.info(" JOBNAME: ")
                logger.info(job_dict['JOBNAME'])
                df = spark.sql(job_dict["SQL_Query"])
                df.createOrReplaceTempView('df')
                sql_query_staging = "select *, from_utc_timestamp(current_timestamp(), '{TIMEZONE}') as pulled_time, " \
                                    "from_utc_timestamp(current_timestamp(), '{TIMEZONE}') as update_time, " \
                                    "from_utc_timestamp(current_timestamp(), '{TIMEZONE}') as bdl_created, '{pipeline_id}' as pipelineid from df"
                logger.info(" sql_query_staging ....")
                logger.info(sql_query_staging)
                sql_query_staging = sql_query_staging.format(TIMEZONE=etl_config.timezone_param, pipeline_id=job_dict['JOBNAME'])
                logger.info(" updated sql_query_staging ....")
                logger.info(sql_query_staging)
                spark.conf.set('spark.sql.session.timeZone', etl_config.timezone_param)
                df = spark.sql(sql_query_staging)
                df = df.withColumn('file_date', F.split(F.split(F.input_file_name(), '/')[9], 'T')[0])
                logger.info(" Display DF .......")
                logger.info(" display table schema .....")
                df.printSchema()
                logger.info(" calling Remove_Special_Character ......")
                table_name_list = job_dict["table_name"].split('/')
                table_name = table_name_list[len(table_name_list) - 2].replace('-', '_')
                if len(table_name.strip()) < 2:
                    table_name = table_name_list[len(table_name_list) - 2].replace('-', '_')

                dir_check = CommonUtility.remove_special_character(table_name)
                logger.info(" dir_check .....")
                logger.info(dir_check)
                table_names3_suported = dir_check[1]
                logger.info(" table_names3_supported.....".format(table_names3_suported))

                logger.info(table_names3_suported)
                job_dict["table_name"] = table_names3_suported
                logger.info('job_dict '.format(job_dict["table_name"]))
                df_columns = df.columns
                df_columns = [column.lower() for column in df_columns]
                df_final = df.toDF(*df_columns)
                logger.info(" calling write_to_iceberg_table_v1 ......")
                logger.info(df_final)
                ###Pass df_final to JSON Flat function
                # if str(job_dict['json_flatten']) == '1':
                #     logger.info(" Json flat is enabled .....")
                #     df_final = CommonUtility.json_flatten(df_final)
                # else:
                #     logger.info(" Json Flat is disabled ....")

                iceberg = write_to_iceberg_table_v1(df_final, job_dict, write_load_flag, etl_config, table_name)

                spark = iceberg[1]
                is_table_present_flag = iceberg[2]
                df_final = iceberg[3]

                temp_df = align_dataframe_schema_with_iceberg_table(job_dict, logger, df_final, spark, etl_config)

                try:
                    temp_df_1 = temp_df_1.unionByName(temp_df, allowMissingColumns=True)
                    logger.info(" Performed Union")
                    temp_df_1.printSchema()
                except Exception as e:
                    logger.error("exception 271")
                    temp_df_1 = temp_df
                    logger.error(" temp_df is assigned to temp_df_1")
                    logger.error(str(e))
            ##### For Loop Ends Here

            temp_df_1.createOrReplaceTempView('staging_table')
            logger.info("STAGING TABLE CREATED SUCCESSFULLY")
            logger.info(" count before row_num: ")
            temp_df_1_cnt = temp_df_1.count()
            logger.info(str(temp_df_1_cnt))
            temp_df_1.printSchema()
            if job_dict["load_type"] == "merge":
                print("MERGE QUERY :", job_dict["merge_query"])
                deltaDF = spark.sql(job_dict["merge_query"])
                logger.info("merge_query executed SUCCESSFULLY")
                deltaDF = deltaDF.drop('row_num')
                logger.info("printing deltaDf")
                df = deltaDF
                df_final = deltaDF
            else:
                df_final = temp_df_1
            df_final = df_final.drop('file_date')
            logger.info('counts in df_final after row_num')
            df_final_cnt = df_final.count()
            logger.info(str(df_final_cnt))
            write_load_flag = 1
            iceberg = write_to_iceberg_table_v1(df_final, job_dict, write_load_flag, etl_config, table_name)
            spark = iceberg[1]
            is_table_present_flag = iceberg[2]
            df_final = iceberg[3]
            write_load_flag = 0
            df = df_final
            return df, is_success

        else:
            path = final_path_list
            if source == "csv":
                logger.info(" Reading CSV ....")
                df = spark.read.option("header", "true").format(source).load(path)
                df = df.where(~df['_c0'].isin(schema_name))
                df = df.toDF(*schema_name)

            elif source == "json":
                logger.info(" Reading json ....")
                try:
                    df = spark.read.format(source).load(path)
                except Exception as e:
                    df = spark.read.option("multiline", 'true').format(source).load(path)

                if str(job_dict['json_flatten']) == '1':
                    df = CommonUtility.json_flatten(df)
                    logger.info(" Json flat is enabled .....")
                else:
                    logger.info('json flatten is disabled')

            else:
                logger.info(" Reading Parquet or non CSV/JSON ....")
                df = spark.read.format(source).load(path)
            logger.info(" Table has been created successfully from s3 files .....")
            df.createOrReplaceTempView('table')
            logger.info(" sql_query ....:::")
            logger.info(job_dict["SQL_Query"])
            logger.info(" JOBNAME: ")
            logger.info(job_dict['JOBNAME'])
            df = spark.sql(job_dict["SQL_Query"])
            df.createOrReplaceTempView('df')
            sql_query_staging = "select *, from_utc_timestamp(current_timestamp(), '{TIMEZONE}') as pulled_time, " \
                                "from_utc_timestamp(current_timestamp(), '{TIMEZONE}') as update_time, " \
                                "from_utc_timestamp(current_timestamp(), '{TIMEZONE}') as bdl_created, '{pipeline_id}' as pipelineid from df"
            logger.info(" sql_query_staging ....")
            logger.info(sql_query_staging)
            sql_query_staging = sql_query_staging.format(TIMEZONE=etl_config.timezone_param, pipeline_id=job_dict['JOBNAME'])
            logger.info(" updated sql_query_staging ....")
            logger.info(sql_query_staging)
            spark.conf.set('spark.sql.session.timeZone', etl_config.timezone_param)
            df = spark.sql(sql_query_staging)
            df = df.withColumn('file_date', F.split(F.split(F.input_file_name(), '/')[9], 'T')[0])
            logger.info(" Display DF .......")
            logger.info(" display table schema .....")
            df.printSchema()
            logger.info(" calling Remove_Special_Character ......")
            table_name_list = job_dict["table_name"].split('/')
            table_name = table_name_list[len(table_name_list) - 2].replace('-', '_')
            if len(table_name.strip()) < 2:
                table_name = table_name_list[len(table_name_list) - 2].replace('-', '_')

            dir_check = CommonUtility.remove_special_character(table_name)
            logger.info(" dir_check .....")
            logger.info(dir_check)
            table_names3_suported = dir_check[1]
            logger.info(" table_names3_supported.....".format(table_names3_suported))

            logger.info(table_names3_suported)
            job_dict["table_name"] = table_names3_suported
            logger.info('job_dict '.format(job_dict["table_name"]))
            df_columns = df.columns
            df_columns = [column.lower() for column in df_columns]
            df_final = df.toDF(*df_columns)
            logger.info(" calling write_to_iceberg_table_v1 ......")
            ###Pass df_final to JSON Flat function

            iceberg = write_to_iceberg_table_v1(df_final, job_dict, write_load_flag, etl_config, table_name)

            spark = iceberg[1]
            is_table_present_flag = iceberg[2]
            df_final = iceberg[3]

            temp_df = align_dataframe_schema_with_iceberg_table(job_dict, logger, df_final, spark, etl_config)

            try:
                temp_df_1 = temp_df_1.unionByName(temp_df, allowMissingColumns=True)
                logger.info(" Performed Union")
                temp_df_1.printSchema()
            except Exception as e:
                logger.error("exception 271")
                temp_df_1 = temp_df
                logger.error(" temp_df is assigned to temp_df_1")
                logger.error(str(e))
            ##### For Loop Ends Here

            temp_df_1.createOrReplaceTempView('staging_table')
            logger.info("STAGING TABLE CREATED SUCCESSFULLY")
            logger.info(" count before row_num: ")
            temp_df_1_cnt = temp_df_1.count()
            logger.info(str(temp_df_1_cnt))
            temp_df_1.printSchema()
            if job_dict["load_type"] == "merge":
                print("MERGE QUERY :", job_dict["merge_query"])
                deltaDF = spark.sql(job_dict["merge_query"])
                logger.info("merge_query executed SUCCESSFULLY")
                deltaDF = deltaDF.drop('row_num')
                logger.info("printing deltaDf")
                df = deltaDF
                df_final = deltaDF
            else:
                df_final = temp_df_1
            df_final = df_final.drop('file_date')
            logger.info('counts in df_final after row_num')
            df_final_cnt = df_final.count()
            logger.info(str(df_final_cnt))
            write_load_flag = 1
            iceberg = write_to_iceberg_table_v1(df_final, job_dict, write_load_flag, etl_config, table_name)
            spark = iceberg[1]
            is_table_present_flag = iceberg[2]
            df_final = iceberg[3]
            write_load_flag = 0
            df = df_final
            return df, is_success
    except Exception as e:
        logger.error(" Error ...***&&&")
        logger.error(str(e))
        df = None
        is_success = False
        add_failed_table_entry(job_dict, etl_config, logger, str(e))
        return df, is_success


def update_audit_and_master_entries(job_dict, logger, etl_config: ETLConfig, df_final):
    try:
        get_all_timezones = pytz.all_timezones
        records_count = df_final.count()
        job_dict["records_count"] = records_count
        if job_dict["load_type"] == "incremental" or job_dict["load_type"] == "merge":
            job_dict["load_type"] = job_dict["load_type"]
            if records_count > 0:
                incremental_column = job_dict["incremental_column"]
                df_max_value = str(datetime.now(pytz.timezone(etl_config.timezone_param)) + timedelta(1))[0:19]
                job_dict["df_max_value"] = "'" + df_max_value + "'"
            elif job_dict["incremental_value"] == 'nan' or job_dict["incremental_value"] == "None" or \
                    job_dict[
                        "incremental_value"] == "<NA>":
                df_max_value = str(datetime.now(pytz.timezone(etl_config.timezone_param)) + timedelta(1))[0:19]
                job_dict["df_max_value"] = "'" + df_max_value + "'"


            else:
                offset_value_old = int(float(job_dict["incremental_value"]))
                job_dict["df_max_value"] = "'" + str(offset_value_old) + "'"
        audit_utils = AuditUtility(job_dict, etl_config)
        dir_check = audit_utils.audit_entry_iceberg()
        is_success = dir_check[1]
        etl_master_entry_iceberg_obj = AuditUtility(job_dict, etl_config)
        dir_check = etl_master_entry_iceberg_obj.Update_ETL_Master_Entry_Iceberg()
        is_success = dir_check[1]
        return is_success
    except Exception as e:
        logger.error(str(e))


def load_into_iceberg(job_dict, logger, is_table_present_flag, spark, etl_config: ETLConfig, df_final):
    try:
        table_name_list = job_dict["table_name"].split('/')
        table_name = table_name_list[len(table_name_list) - 2]
        if len(table_name.strip()) < 2:
            table_name = table_name_list[len(table_name_list) - 1]

        logger.info(" Inside  load_into_iceberg ..........")
        df_final.createOrReplaceTempView("df_final")
        if job_dict["load_type"] == "incremental":

            query = f'INSERT INTO uipl.{job_dict["iceberg_db"]}.{table_name} ' \
                    f'SELECT * FROM df_final'

            spark.sql(query)

        elif job_dict["load_type"] == "merge":
            if is_table_present_flag == 1:

                pass
            else:

                query = f"""MERGE INTO uipl.{job_dict["iceberg_db"]}.{table_name} t
                            USING (SELECT * FROM df_final) s
                            ON t.{job_dict["pk_column"]} = s.{job_dict["pk_column"]}
                            WHEN MATCHED THEN UPDATE SET * 
                            WHEN NOT MATCHED THEN INSERT * """

                spark.sql(query)

        else:
            if is_table_present_flag == 1:
                pass
            else:

                query = f"""INSERT OVERWRITE uipl.{job_dict["iceberg_db"]}.{table_name}
                     SELECT * FROM df_final"""
                spark.sql(query)

    except Exception as e:
        logger.error(str(e))
        logger.info(" Error Occurred in load_into_iceberg")
        add_failed_table_entry(job_dict, etl_config, logger, str(e))


def load_data_into_iceberg_table(job_dict, logger, is_table_present_flag, spark, etl_config: ETLConfig, df_final):
    try:
        logger.info(" Creating temp view for df_final .....")
        df_final.createOrReplaceTempView("df_final")
        table_name_list = job_dict["table_name"].split('/')
        table_name = table_name_list[len(table_name_list) - 2]
        if len(table_name.strip()) < 2:
            table_name = table_name_list[len(table_name_list) - 1]
        logger.info(" Updated table_name :::::")
        logger.info(table_name)
        Partition_Column_TABLE = str(job_dict["Partition_Column"])[1:-1].replace("'", '').lower()
        if job_dict["load_type"] == "incremental":

            query = f'INSERT INTO uipl.{etl_config.athena_db_name}.{table_name} SELECT *' \
                    f' FROM df_final ORDER BY {Partition_Column_TABLE}'

            spark.sql(query)

        elif job_dict["load_type"] == "merge":
            if is_table_present_flag == 1:

                pass
            else:

                query = f"""MERGE INTO uipl.{etl_config.athena_db_name}.{table_name} t
                            USING (SELECT * FROM df_final) s
                            ON t.{job_dict["pk_column"]} = s.{job_dict["pk_column"]}
                            WHEN MATCHED THEN UPDATE SET * 
                            WHEN NOT MATCHED THEN INSERT * """

                spark.sql(query)

        else:
            if is_table_present_flag == 1:

                pass
            else:

                query = f"""INSERT OVERWRITE uipl.{etl_config.athena_db_name}.{table_name}
                     SELECT * FROM df_final ORDER BY {Partition_Column_TABLE}"""
                spark.sql(query)
    except Exception as e:
        logger.error(str(e))


def align_dataframe_schema_with_iceberg_table(job_dict, logger, df_final, spark, etl_config: ETLConfig):
    logger.info('inside datatype_check function')
    try:
        logger.info('inside try')
        df_final.printSchema()
        write_load_flag = 1
        table_name_val_list = job_dict["table_name"].split('/')
        table_name = table_name_val_list[len(table_name_val_list) - 2]
        if len(table_name) < 2:
            table_name = table_name_val_list[len(table_name_val_list) - 1]
        logger.info(" updated tablename : ")
        logger.info(table_name)
        df_tbl = spark.read.format("iceberg").load(f'uipl.{etl_config.athena_db_name}.{table_name}')
        logger.info('schema before lower')
        df_tbl.printSchema()
        df_columns = df_tbl.columns
        df_columns = [column.lower() for column in df_columns]
        df_tbl = df_tbl.toDF(*df_columns)
        logger.info('schema after lower')
        logger.info(" Displaying Schema ....")
        logger.info(df_tbl.printSchema())
        logger.info(" column_list_dif ....")
        column_list_dif = [col for col in df_tbl.dtypes if col not in df_final.dtypes]
        logger.info(column_list_dif)
        if len(column_list_dif) > 0:
            logger.info("column_list_dif")
            logger.info(str(column_list_dif))
            for col in column_list_dif:
                if col[0] not in df_final.columns:
                    df_final = df_final.withColumn(col[0], F.lit(None))
                df_final = df_final.withColumn(col[0], F.col(col[0]).cast(col[1]))

        column_list_dif_1 = [col for col in df_final.dtypes if col not in df_tbl.dtypes and col[0] != 'file_date']
        if len(column_list_dif_1) > 0:
            logger.info("column_list_dif_1 :")
            logger.info(str(column_list_dif_1))
            for col in column_list_dif_1:
                query = f"""ALTER TABLE uipl.{etl_config.athena_db_name}.{table_name}
                                    ADD COLUMNS (
                                        {col[0]} {col[1]}
                                      )"""
                spark.sql(query)
        df_tbl = spark.read.format("iceberg").load(f'uipl.{etl_config.athena_db_name}.{table_name}')
        df_tbl_columns = df_tbl.columns
        df_tbl_columns.append('file_date')
        df_final = df_final.select(df_tbl_columns)
    except Exception as e:
        logger.error('error occurred')
        logger.error(str(e))
        # add_failed_table_entry(job_dict, etl_config, logger, str(e))
    return df_final


# def align_dataframe_schema_with_iceberg_table(job_dict,logger, df_final, spark):
#     try:
#         df_tbl = spark.read.format("iceberg").load(
#             f'uipl.{job_dict["iceberg_db"]}.{job_dict["table_name"]}')
#         column_list_dif = [col for col in df_tbl.dtypes if col not in df_final.dtypes]
#         if len(column_list_dif) > 0:
#
#             for col in column_list_dif:
#                 if col[0] not in df_final.columns:
#                     df_final = df_final.withColumn(col[0], F.lit(None))
#                 elif df_final.select(F.col(col[0]).isNull()):
#                     df_final = df_final.withColumn(col[0], F.lit(None))
#                 df_final = df_final.withColumn(col[0], F.col(col[0]).cast(col[1]))
#         column_list_dif_1 = [col for col in df_final.dtypes if col not in df_tbl.dtypes]
#         if len(column_list_dif_1) > 0:
#
#             col_list = [col for col in df_final.dtypes if col not in df_tbl.dtypes]
#
#             if len(col_list) > 0:
#                 for col in col_list:
#                     query = f"""ALTER TABLE uipl.{job_dict["iceberg_db"]}.{job_dict["table_name"]}
#                                     ADD COLUMNS (
#                                         {col[0]} {col[1]}
#                                       )"""
#                     spark.sql(query)
#         df_tbl = spark.read.format("iceberg").load(
#             f'uipl.{job_dict["iceberg_db"]}.{job_dict["table_name"]}')
#         df_final = df_final.select(df_tbl.columns)
#         return df_final
#     except Exception as e:
#         logger.error(str(e))


def construct_s3_paths_from_date_range(job_dict, logger, start_date_formatted_daily, tbl_name, etl_config: ETLConfig):
    try:
        is_success = True
        logger.info("Starting construct_s3_paths_from_date_range function ......")
        path_list = []
        final_path_list = []
        bucket = f'{tbl_name[2]}'
        logger.info("Bucket-Name: ")
        logger.info(bucket)
        prefix = job_dict["inventory_table_name"].replace(tbl_name[0] + '//' + tbl_name[2] + '/', '')
        logger.info(" prefix: ")
        logger.info(prefix)
        rangeStartDate = datetime.strptime(start_date_formatted_daily, '%Y-%m-%d').date()
        logger.info(" rangeStartDate:  ")
        logger.info(rangeStartDate)
        rangeenddate_ = str(datetime.now(pytz.timezone(etl_config.timezone_param)))
        logger.info(" rangeenddate_: ")
        logger.info(rangeenddate_)
        rangeEndDate = datetime.strptime(rangeenddate_[0:10], '%Y-%m-%d').date()
        logger.info(" rangeEndDate: ")
        logger.info(rangeEndDate)
        if job_dict['business_unit'] == 'haptik':
            rangeEndDate = rangeEndDate - timedelta(1)
        for i in range(int((rangeEndDate + timedelta(+1) - rangeStartDate).days)):
            logger.info(" Iterate ...")
            logger.info(str(i))
            logger.info(" append in path_list ...")
            if job_dict['business_unit'].lower() == 'salesforce':
                path_list.append(prefix + str(rangeStartDate + timedelta(i))[0:10].replace('-', '/'))
                logger.info("append done in path_list ...")
            else:

                logger.info('Running for haptik data source')

                path_list.append(prefix + str(rangeStartDate + timedelta(i))[0:10])
                logger.info("append done in path_list ...")

        logger.info(" path_list: ***")
        logger.info(path_list)
        for path in path_list:
            common_dict = CommonUtility.check_s3_path(bucket, path)
            logger.info(" common_dict ..")
            logger.info(common_dict)
            if common_dict[1] == 1:
                final_path_list.append(f's3://{bucket}/{path}/*')
        logger.info(" final_path_list: ....")
        logger.info(final_path_list)
        return is_success, final_path_list
    except Exception as e:
        logger.info(" Error Occurred in construct_s3_paths_from_date_range .....")
        logger.error(str(e))
        final_path_list = []
        is_success = False
        add_failed_table_entry(job_dict, etl_config, logger, str(e))
        return is_success, final_path_list


def construct_s3_paths_for_full_load(job_dict, logger, tbl_name, etl_config: ETLConfig):
    try:
        is_success = True
        logger.info(" executing in construct_s3_paths_for_full_load ..... ")
        final_path_list = []
        bucket = f'{tbl_name[2]}'
        logger.info(" bucket: ")
        logger.info(bucket)

        prefix = job_dict["inventory_table_name"].replace(tbl_name[0] + '//' + tbl_name[2] + '/', '')
        logger.info(" prefix :::")
        logger.info(prefix)
        # prefix = f'{tbl_name[3]}/{tbl_name[4]}/'
        # if job_dict['business_unit'].lower() == 'salesforce':

        # start_date = str(datetime.now(pytz.timezone('Asia/Kolkata')))[0:10].replace('-', '/')

        start_date = str(datetime.now(pytz.timezone(etl_config.timezone_param)))[0:10].replace('-', '/')
        logger.info(" start_date:  ")
        logger.info(start_date)
        full_load_path = prefix + start_date
        logger.info(" full_load_path ")
        logger.info(full_load_path)
        common_dict = CommonUtility.check_s3_path(bucket, full_load_path)
        logger.info(" common_dict: ")
        logger.info(common_dict)
        if common_dict[1] == 1:
            logger.info(" append into final_path_list    ")
            final_path_list.append(f's3://{bucket}/{full_load_path}/*')
            logger.info(" append into final_path_list done .....   ")
        return is_success, final_path_list

        # else:
        # logger.info('Running for haptik data source ')
        # start_date = job_dict["startdatetime"]
        # start_date_formatted_daily = start_date[0:10]
        # is_success, final_path_list = construct_s3_paths_from_date_range(job_dict, logger,
        #                                                                  start_date_formatted_daily, tbl_name,
        #                                                                  etl_config)
        #
        # # start_date = str(datetime.now(pytz.timezone('Asia/Kolkata')))[0:10]
        # # logger.info(" start_date:  ")
        # # logger.info(start_date)
        # # full_load_path = prefix
        # # logger.info(" full_load_path ")
        # # logger.info(full_load_path)
        # # common_dict = CommonUtility.check_s3_path(bucket, full_load_path)
        # # logger.info(" common_dict: ")
        # # logger.info(common_dict)
        # # if common_dict[1] == 1:
        # #     logger.info(" append into final_path_list    ")
        # #     final_path_list.append(f's3://{bucket}/{full_load_path}/*')
        # #     logger.info(" append into final_path_list done .....   ")
        # return is_success, final_path_list
    except Exception as e:
        logger.error(str(e))
        is_success = False
        final_path_list = []
        add_failed_table_entry(job_dict, etl_config, logger, str(e))
        return is_success, final_path_list
