from ..common_utilities.Common_utility import CommonUtility
from ..audit_utilities.audit_utility import AuditUtility
from ..custom_functions.insert_failed_tables import add_failed_table_entry
from ..custom_functions.read_from_mongodb import read_from_mongodb, mongo_db_full_load, mongo_staging_query, \
    rdbms_staging_query
from ..custom_functions.extract_db_collection import extract_db_collection
from ..custom_functions.read_from_snowflake import read_from_snowflake
from ..custom_functions.read_from_rdbms import read_from_rdbms
from ..custom_functions.create_partition_column import create_partition_column
from ..custom_functions.generate_df import generate_merged_df, generate_incr_df
from ..custom_functions.write_to_s3_multi_part import write_to_s3_multi_part, write_to_s3_non_part
from ..custom_functions.update_audit_etl_master import update_audit_etl_master, update_etl_master
from ..s3_data_ingestion.S3_data_ingestion import S3DataIngestion
from ..s3_data_ingestion_inventory.s3_dataIngestion_inventory import S3DataIngestionInventory
from ..custom_functions.write_to_iceberg_table import write_to_iceberg_table
from ..custom_functions.write_to_iceberg_table import write_to_iceberg_table_v1
from ..custom_functions.write_to_iceberg_table import write_to_iceberg_table_rest_api
from ..custom_functions.read_from_rest_apis import read_from_rest_api
from ..custom_functions.read_from_sftp_excel import read_from_sftp_excel
from ..custom_functions.write_to_redshift import write_to_redshift

from ..custom_functions.s3_files_iceberg_migration import run_s3_files_iceberg_job

import logging
from ..src.etl_config import ETLConfig

logger = logging.getLogger("my_logger")


def start_ingestion(job_dict, source_conn_details, etl_config: ETLConfig):

    is_success = 0
    is_error = ''

    try:
        logger.info(" inside start_ingestion ..... .....")

        spark = etl_config.glueContext
        spark.conf.set('spark.sql.session.timeZone', etl_config.timezone_param)
        spark.conf.set("spark.sql.legacy.parquet.datetimeRebaseModeInRead", "CORRECTED")
        spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")

        # ============================================================
        # NEW: S3_FILES → ICEBERG (Custom Incremental Handler)
        # ============================================================
  
        if job_dict["inventory"] == 'NA' and \
           job_dict["chunk_size"] == 'NA' and \
           job_dict["source"].lower() == "s3_files" and \
           job_dict["destination_type"].lower() == "iceberg":

            logger.info("Routing to S3_FILES → ICEBERG custom handler")

            is_success, is_error = run_s3_files_iceberg_job(job_dict, etl_config)

            # return (1, is_error) if is_success else (0, is_error)
            if is_success:
                logger.info("S3_FILES → ICEBERG job completed. Skipping framework flow.")
                return (1, None)
            else:
                logger.error("S3_FILES → ICEBERG job failed.")
                return (0, is_error)

        # ============================================================
        # EXISTING NON-S3 LOGIC
        # ============================================================
        elif job_dict["inventory"] == 'NA' and \
                job_dict["chunk_size"] == 'NA' and \
                's3_' not in job_dict["source"]:

            if job_dict["source"].lower() == "mongodb":

                database, collection, job_dict, success, is_error = extract_db_collection(spark, job_dict)

                if job_dict["load_type"] in ["incremental", "merge"]:
                    incoming_source_df, job_dict, success, is_error = read_from_mongodb(
                        job_dict, database, collection, source_conn_details, etl_config)
                else:
                    incoming_source_df, success, is_error = mongo_db_full_load(
                        source_conn_details, database, collection, etl_config, job_dict)

            elif job_dict["source"].lower() == "snowflake":
                incoming_source_df, job_dict, success, is_error = read_from_snowflake(
                    spark, job_dict, source_conn_details)

            elif job_dict["source"].lower() == 'rest_api':
                incoming_source_df, job_dict, success, is_error = read_from_rest_api(
                    spark, job_dict, source_conn_details, etl_config)

            elif job_dict['source'].lower() == 'sftp_excel':
                incoming_source_df, job_dict, success, is_error = read_from_sftp_excel(
                    spark, job_dict, source_conn_details, etl_config)

            else:
                incoming_source_df, job_dict, success, is_error = read_from_rdbms(
                    spark, source_conn_details, job_dict, etl_config)

            if incoming_source_df is None and success is False:
                return 0, None

            cnt = 0
            if incoming_source_df is not None:
                cnt = incoming_source_df.count()
                job_dict['records_count'] = cnt

            if (incoming_source_df is None and success is not False) or cnt == 0:
                if job_dict["is_audit"] > 0:
                    job_dict['records_count'] = 0
                    success, is_error = update_audit_etl_master(spark, job_dict, incoming_source_df, etl_config)
                    return (1, is_error) if success else (0, is_error)
                else:
                    is_success, is_error = update_etl_master(job_dict, incoming_source_df, etl_config)
                    return (1, is_error) if is_success else (0, is_error)

            # ---------- DESTINATION HANDLING ----------
            if job_dict["destination_type"].lower() == 'iceberg':

                if job_dict['source'].lower() == 'rest_api':
                    iceberg_dict, is_error = write_to_iceberg_table_rest_api(
                        incoming_source_df, job_dict, 1, etl_config, job_dict['table_name'])

                elif job_dict['source'].lower() in ['sftp_csv', 'sftp_excel']:
                    iceberg_dict = write_to_iceberg_table_v1(
                        incoming_source_df, job_dict, 1, etl_config, job_dict['table_name'])

                else:
                    iceberg_dict, is_error = write_to_iceberg_table(
                        incoming_source_df, job_dict, etl_config)

            elif job_dict["destination_type"].lower() == 'redshift':

                success, is_error = write_to_redshift(
                    incoming_source_df, job_dict, etl_config, spark)

            if job_dict["is_audit"] > 0:
                success, is_error = update_audit_etl_master(
                    spark, job_dict, incoming_source_df, etl_config)
                return (1, is_error) if success else (0, is_error)
            else:
                is_success, is_error = update_etl_master(
                    job_dict, incoming_source_df, etl_config)
                return (1, is_error) if is_success else (0, is_error)

        # ============================================================
        # GENERIC S3 (NON s3_files) → ICEBERG
        # ============================================================
        elif job_dict["inventory"] == 'NA' and \
             job_dict["chunk_size"] == 'NA' and \
             job_dict["source"].lower().startswith("s3_") and \
             job_dict["destination_type"].lower() == 'iceberg':

            logger.info("Routing to Generic S3DataIngestion")

            s3_data_ingestion_obj = S3DataIngestion(job_dict, etl_config)
            is_success_s3_data_process, df, is_error = s3_data_ingestion_obj.s3_data_process()

            if job_dict["is_audit"] > 0:
                success, is_error = update_audit_etl_master(spark, job_dict, df, etl_config)
                return (1, is_error) if success else (0, is_error)
            else:
                is_success, is_error = update_etl_master(job_dict, df, etl_config)
                return (1, is_error) if is_success else (0, is_error)

        # ============================================================
        # INVENTORY FLOW
        # ============================================================
        else:
            s3_data_ingestion_inventory_obj = S3DataIngestionInventory(job_dict, etl_config)
            is_success, is_error = s3_data_ingestion_inventory_obj.s3_data_process()
            return (1, is_error) if is_success else (0, is_error)

    except Exception as e:
        logger.error(" Error Occurred ....::*** ")
        logger.error(f"Error Occurred: {str(e)}", exc_info=True)
        add_failed_table_entry(job_dict, etl_config, logger, str(e))
        return 0, str(e)
