# DataIngestionFramework
PySpark Data Ingestion Framework Which Can Run on Both AWS Glue &amp; AWS EMR

# In Order to Use the ETLUtility do the following :

1. Download the ZIP file from github repo (https://github.com/UIPLAnalytics/DataIngestionFramework/archive/refs/heads/master.zip)
2. Unzip the File to Local Drive and remove the "-master" from the directory name (Ie only keep dir name as DataIngestionFramework).
3. Download the __init.py__ (https://github.com/UIPLAnalytics/ETLUtility_InitPY/blob/main/__init__.py) file in the same location as #2 above.
4. Zip both #2 & #3 with name as DataIngestionFramework.zip

The hierachy Of Zip Should Look like follows :

DataIngestionFramework.zip > DataIngestionFramework & init.py > Code base

Screenshot :

![alt text](https://github.com/UIPLAnalytics/ETLUtility_InitPY/blob/main/ZipHierarchy.PNG?raw=true)

5. Download the AnalyticsUtilities (https://github.com/UIPLAnalytics/AnalyticsUtilities/archive/refs/heads/master.zip). Unzip to a folder & then Remove "-master" from the name of the extracted folder & then re-zip (The zip file will be as follows : AnalyticsUtilities.zip > AnalyticsUtilities (Folder) -> Pyfiles).
6. Download the related SitePackages (this is for awswrangler etc - https://github.com/UIPLAnalytics/ETLUtilitySitePackages/blob/main/site-packages.zip).
7. Finally you should be left with following zip's
- DataIngestionFramework.zip (Step #4)
- AnalyticsUtilities.zip (step #5)
- site-packages.zip
8. Upload all these to S3.
9. For Glue Based Deployment :
- Provide Path as follows :
s3://spark-ingestion-framework/libraries/site-packages.zip,s3://spark-ingestion-framework/libraries/DataIngestionFramework.zip,s3://spark-ingestion-framework/libraries/AnalyticsUtilities.zip
- Create a SampleGlueJob as mentioned here -> https://github.com/UIPLAnalytics/DataIngestionFramework/blob/master/sample/Sample_Glue_Job.py
10. For Metadata of ETL table you can refer -> https://github.com/UIPLAnalytics/DataIngestionFramework/tree/master/metadata_sql (For Iceberg vs Redshift)
