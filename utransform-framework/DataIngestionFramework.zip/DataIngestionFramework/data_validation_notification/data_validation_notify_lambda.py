import json
import boto3
import pandas as pd
from pg8000 import dbapi
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import smtplib, ssl
from datetime import datetime
import numpy as np 
from pytz import timezone


def highlight(row):
    lag =  abs(row['LAG'])
    print('lag: ')
    print(lag)    
    if lag > 100  :
        return ['background-color: red'] * len(row)
    elif lag > 50:
        return ['background-color: orange'] * len(row)
    elif lag > 0:
        return ['background-color: yellow'] * len(row)
    else:
        return [''] * len(row)
        

def get_secrets_json(secrets_name):
    try:
        session = boto3.session.Session()
        client = session.client(service_name='secretsmanager', region_name='ap-south-1')

        get_secret_value_response = client.get_secret_value(SecretId=secrets_name)

        secrets_json = json.loads(get_secret_value_response['SecretString'])

        return secrets_json
    except Exception as e:
        print("Error in get_secrets_json function: ", str(e))

def get_sql_query_result(secrets_json):
    try:
        conn = dbapi.connect(
            database="database_name",
            host=secrets_json['host'],
            port=database_port,
            user=secrets_json['user'],
            password=secrets_json['password']
        )
        

        curr = conn.cursor()
        sql_query = '''  SELECT GROUPID, TABLENAME, LOAD_TYPE, SOURCE_COUNT, SOURCE_CURR_OFFSET,  DATALAKE_COUNT,DATALAKE_CURR_OFFSET ,SOURCE_CURR_STARTDATETIME,DATALAKE_CURR_STARTDATETIME,  SOURCE_COUNT - DATALAKE_COUNT AS LAG  FROM PROD_ETL_FRAMEWORK_SCHEMA.DATA_VALIDATION_TABLE_NAME WHERE  DATE(INSERT_TIMESTAMP) = CURRENT_DATE ORDER BY INSERT_TIMESTAMP DESC  '''
        curr.execute(sql_query)
        records = curr.fetchall()

        return records
        
        
    except Exception as e:
        print(" Error in get_sql_query_result function: " + str(e))


def send_ses_notification(records, ses_secrets_json):
    try:
        df = pd.DataFrame(data=records, columns=["GROUPID", "TABLENAME", "LOAD_TYPE", "SOURCE_COUNT", "SOURCEL_CURR_OFFSET", "DATALAKE_COUNT", "DATALAKE_CURR_OFFSET", "SOURCE_TIMESTAMP","DATALAKE_TIMESTAMP",  "LAG"])
        df.index = np.arange(1, len(df) + 1)
        print(df)
        for col in df.columns:
            print(col)
        styled_df = df.style.apply(highlight, axis=1)
        body_html = """\
            <html>
              <head>
                <h1 style="text-align:center;">
                Credgenics Tables Recon Report<br>
                ----------------------------
                </h1>
                
              </head>
              <body>
                {0}
              </body>
            </html>
            """.format(styled_df.to_html().replace('class="dataframe"', 'class="table table-striped table-hover"'))
        sender = 'sender@domain.com'
        recipients = 'receiver@domain.com'
        msg = MIMEMultipart()
        msg['From'] = sender
        recipients = recipients.split(",")
        msg['To'] = ",".join(recipients)
        msg['Subject'] =  'Table Recon Report | ' + str(datetime.now(timezone("Asia/Kolkata")).strftime("%b %d %Y %H:%M:%S"))

        msg.attach(MIMEText(body_html, 'html'))

        server = smtplib.SMTP_SSL('email_smtp*****.amazonaws.com', port_no, context=ssl.create_default_context())
        server.login(ses_secrets_json['user'],  ses_secrets_json['password'])
        text = msg.as_string()
        server.sendmail(sender, recipients, text)
        server.quit()

        return True
    except Exception as e:
        print("Error in send_ses_notification:  " + str(e))
        return False


def lambda_handler(event, context):
    # TODO implement
    try:
        print("Starting ....")

        redshift_secrets = 'redshift_secret_name'
        ses_secrets = 'ses-secret-name'

        redshift_secrets_json = get_secrets_json(redshift_secrets)

        ses_secrets_json = get_secrets_json(ses_secrets)
        records = get_sql_query_result(redshift_secrets_json)
        is_success = send_ses_notification(records, ses_secrets_json)
        if is_success:
            print(" Mail Has Been Sent ....")
            return {
                'statusCode': 200,
                'body': json.dumps('Main Has Been Sent!')
            }
        else:
            print("Mail Not Sent ...")
            return {
                'statusCode': 200,
                'body': json.dumps('Mail Send Failed ')
            }
        
    except Exception as e:
        print(" Error : " + str(e))
        return {
            'statusCode': 400,
            'body': json.dumps('Error Occurred')
        }
