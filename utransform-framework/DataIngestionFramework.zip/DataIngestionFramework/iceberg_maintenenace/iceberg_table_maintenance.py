import sys
import pytz
import boto3
import pyspark
from pyspark.sql import functions as F
from pyspark.sql import SparkSession
from datetime import datetime, timedelta
from cloudwatch import cloudwatch
import logging
from pyspark.conf import SparkConf
spark = SparkSession.builder.getOrCreate()

spark.conf.set('spark.sql.catalog.AwsDataCatalog', 'org.apache.iceberg.spark.SparkCatalog')
spark.conf.set('spark.sql.catalog.AwsDataCatalog.catalog-impl', 'org.apache.iceberg.aws.glue.GlueCatalog')
spark.conf.set('spark.sql.catalog.AwsDataCatalog.warehouse', 's3://warehouse/dir/')
spark.conf.set('spark.sql.catalog.AwsDataCatalog.io-impl', 'org.apache.iceberg.aws.s3.S3FileIO')
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)



def get_cloudwatch_logger(log_group_name):
    logger = logging.getLogger('my_logger')
    formatter = logging.Formatter(
        '%(asctime)s | %(levelname)s | %(filename)s | %(funcName)s | %(message)s')
    handler = cloudwatch.CloudwatchHandler(log_group=log_group_name)
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    return logger


def __setup_logger():
    log_name = 'log_name'
    logg = get_cloudwatch_logger(log_name)
    logg.setLevel(logging.INFO)
    return logg

logger = __setup_logger()

athena_client = boto3.client('athena', region_name='ap-south-1')


database_list = ["db_name1","db_name2","db_name3"]

for db_name in database_list:
    logger.info("Processing Tables Of "+str(db_name))

    paginator = athena_client.get_paginator('list_table_metadata')

    response_iterator = paginator.paginate(CatalogName='AwsDataCatalog',DatabaseName= db_name)

    tablesToCompact = []
    for page in response_iterator:
        tablesToCompact.extend((i['Name'] for i in page['TableMetadataList']))
    logger.info(tablesToCompact)
    
    for table in tablesToCompact:
        try:
            logger.info("Starting to Compact: "+str(table))
        
            ### procedure rewrite_data_files : Rewrite the data files in table using the default rewrite algorithm of bin-packing to combine small files and also split large files according to the default write size of the table.         
            spark.sql("CALL AwsDataCatalog.system.rewrite_data_files(table => '{0}.{1}')".format(db_name,table)).show(10, False)
        
            ### procedure rewrite_manifests : Rewrite the manifests in table and align manifest files with table partitioning.
            spark.sql("CALL AwsDataCatalog.system.rewrite_manifests(table => '{0}.{1}')".format(db_name,table)).show(10, False)
            
            ### procedure expire_snapshots : used to remove older snapshots and their files which are no longer needed. 
            spark.sql("CALL AwsDataCatalog.system.expire_snapshots(table => '{0}.{1}')".format(db_name,table)).show(10, False)
            
            ### procedure remove_orphan_files : used to remove files which are not referenced in any metadata files of an Iceberg table .
            spark.sql("CALL AwsDataCatalog.system.remove_orphan_files(table => '{0}.{1}')".format(db_name,table)).show(10,False)
            
            
            logger.info("Ended Compaction : "+str(table))
        except Exception as e:
            logger.info(str(e))
    
logger.info("Compaction Job end")
