from pyspark.sql import SparkSession
from pyspark.context import SparkContext
import sys
from botocore.errorfactory import ClientError
import datetime
from DataIngestionFramework.src.data_migration import DataMigration
from DataIngestionFramework.src.etl_config import ETLConfig
from pyspark.conf import SparkConf

conf = SparkConf()
conf.set('spark.sql.extensions', 'org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions')
sc = SparkContext(conf=conf)
spark = SparkSession.builder.getOrCreate()

spark.conf.set("spark.sql.session.timeZone", "IST")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
spark.conf.set("spark.sql.session.timeZone", "Asia/Kolkata")
### HADOOP PARAMETERS #####
hadoopConf = sc._jsc.hadoopConfiguration()
hadoopConf.set("fs.s3.maxRetries", "1000")
hadoopConf.set("fs.s3a.experimental.input.fadvise", "random")
hadoopConf.set("fs.s3a.experimental.fadvise", "random")
hadoopConf.set("fs.s3a.readahead.range", "2048K")
hadoopConf.set("fs.s3a.fast.uploa", "true")

### SPARK TUNING PARAMETERS #####
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)
spark.conf.set("spark.sql.parquet.filterPushdown", "true")
spark.conf.set("spark.sql.shuffle.partitions", 500)
spark.conf.set("spark.sql.files.maxPartitionBytes", 31457280)
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", 524288000)
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", 209715200)
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", 629145600)
spark.conf.set("spark.sql.broadcastTimeout", 900)
spark.conf.set("spark.sql.debug.maxToStringFields", 1000)
spark.conf.set("spark.hadoop.fs.s3a.experimental.input.fadvise", "random")
spark.conf.set("spark.hadoop.fs.s3a.readahead.range", "2048K")
spark.conf.set("spark.hadoop.fs.s3a.fast.upload", "true")
spark.conf.set("spark.hadoop.parquet.filter.stats.enabled", "true")
spark.conf.set("spark.hadoop.fs.s3a.experimental.fadvise", "random")
spark.conf.set("spark.sql.join.preferSortMergeJoin", "false")
spark.conf.set("spark.sql.legacy.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.legacy.timeParserPolicy", "CORRECTED")
spark.conf.set("spark.sql.decimalOperations.allowPrecisionLoss", "true")
spark.conf.set("spark.sql.parquet.outputTimestampType", "TIMESTAMP_MICROS")

spark.conf.set('spark.sql.catalog.uipl', 'org.apache.iceberg.spark.SparkCatalog')
spark.conf.set('spark.sql.catalog.uipl.catalog-impl', 'org.apache.iceberg.aws.glue.GlueCatalog')
spark.conf.set('spark.sql.catalog.uipl.warehouse', 'S3_BUCKET_WAREHOUSE')
spark.conf.set('spark.sql.catalog.uipl.io-impl', 'org.apache.iceberg.aws.s3.S3FileIO')
# spark.conf.set("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions")

###	ETLConfig(source_secret_name=secret name to access source db, glueContext,
###          redshift_secret_name= secret name to access redshift, region_name="region_name", job_name='JOBNAME',
###          sns_topic='NA', smtp_ses_secret_name= secret name for ses,
###          inventory_database='NA', data_chunk_size='NA', iceberg_db='NA',
###          db_name=redshift db in which etl_master is stored, job_id= groupid,
###		 redshift_schema_name= redshift schema in which etl_master is stored,
###          redshift_audit_table_name= name of audit table present in redshift,
###		 redshift_etl_master_table_name=name of etl master table present in redshift, athena_db_name= name of database created in athena,
###          log_group='NA', iceberg_etl_master_table_name='NA', iceberg_audit_table_name='NA', timezone_param= Asia/Kolkata)


etl_config = ETLConfig('DB_SOURCE_SECRET_NAME', spark, 'NA', 'REGION_NAME',
                       'mssql_ouc', 'NA', 'NA', 'NA',
                       'NA', 'ETL_TABLE_DB_NAME_OF_ICEBERG', 'NA', 1,
                       'NA', 'NA',
                       'NA', 'ICEBERG_TARGET_ATHENA_DB_NAME', 'CLOUDWATCH_LOG_GROUP',
                       'etl_master', 'audit_table', 'Asia/Kolkata', 'NA', 'NA', 'NA', 'S3_BUCKET_FOR_TEMP_DATA')
data_migration_obj = DataMigration(etl_config)
is_success = data_migration_obj.start_ingestion_job()
is_success = is_success[0]

if int(is_success) > 0:
    print("job run successfully ")