from pyspark.sql import SparkSession


# Initialize Spark session with Iceberg configs (adjust catalog, warehouse, etc.)
spark = SparkSession.builder \
    .appName("IcebergMaintenance") \
    .config("spark.sql.catalog.uipl", "org.apache.iceberg.spark.SparkCatalog") \
     .config("spark.sql.catalog.uipl.region", "me-south-1")  \
    .config("spark.sql.catalog.uipl.catalog-impl", "org.apache.iceberg.aws.glue.GlueCatalog") \
    .config("spark.sql.catalog.uipl.warehouse", "s3://ewa-lakehouse-analytics-data/warehouse/") \
    .config("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions") \
    .getOrCreate()



# Set your database and table names
database = "athena_mssql_ouc_db"
table = "gccom_contract"

# Expire snapshots, keeping the last 3
print("Running expire_snapshots_query ..............")
expire_snapshots_query = ''' CALL uipl.'''+str(database)+'''.'''+str(table)+'''.'''+'''expire_snapshots(retain_last => 3) '''
print(expire_snapshots_query)

spark.sql(expire_snapshots_query)

# Remove orphan files
remove_orphan_files_query = '''CALL uipl.'''+str(database)+'''.'''+str(table)+'''.remove_orphan_files() '''
print("****************Running remove_orphan_files_query ......")
print(remove_orphan_files_query)
spark.sql(remove_orphan_files_query)

print("Expired old snapshots and removed orphan files successfully.")
