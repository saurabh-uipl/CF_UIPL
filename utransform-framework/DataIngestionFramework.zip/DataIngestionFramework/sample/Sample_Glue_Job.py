import awswrangler as wr
import sys
import boto3
import json
import os
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.dynamicframe import DynamicFrame
from awsglue.job import Job
import sys
from botocore.errorfactory import ClientError
import datetime
import pg8000 as dbapi
import boto3
import base64
from botocore.exceptions import ClientError
import awswrangler
import pandas as pd
from pyspark.conf import SparkConf

from DataIngestionFramework.src.data_migration import DataMigration
from DataIngestionFramework.src.etl_config import ETLConfig
import pg8000
import importlib_metadata as metadata

from cloudwatch import cloudwatch

print(" Job Starting .....")

print(" awswrangler: ")
print(awswrangler.__version__)
print(" pg8000: ")
print(pg8000.__version__)
print(" cloudwatch: ")
print(metadata.version('cloudwatch'))

# Adding Wrangler Configs
wr.config.s3_endpoint_url = "https://s3.ap-south-1.amazonaws.com"
wr.config.athena_endpoint_url = "https://athena.ap-south-1.amazonaws.com"
wr.config.sts_endpoint_url = "https://sts.ap-south-1.amazonaws.com"
wr.config.glue_endpoint_url = "https://glue.ap-south-1.amazonaws.com"
wr.config.secretsmanager_endpoint_url = "https://secretsmanager.ap-south-1.amazonaws.com"
wr.config.workgroup = "primary"

print("The Pythong Version Is :: " + sys.version)

args = getResolvedOptions(sys.argv, ['JOBID', 'JOBNAME', 'SOURCE_SECRET_NAME', 'SMTP_SES_SECRET_NAME', 'SNS_TOPIC',
                                     'REDSHIFT_SECRET_NAME', 'INVENTORY_DATABASE', 'DATA_CHUNK_SIZE',
                                     'REGION_NAME', 'ICEBERG_DB', 'SNS_LIST_SUCCESS', 'DB_NAME', 'REDSHIFT_SCHEMA_NAME',
                                     'REDSHIFT_AUDIT_TABLE_NAME', 'REDSHIFT_ETL_MASTER_TABLE_NAME', 'ATHENA_DB_NAME',
                                     'LOG_GROUP', 'ICEBERG_ETL_MASTER_TABLE_NAME', 'ICEBERG_AUDIT_TABLE_NAME' , 'TIMEZONE_NAME'])
print(args["JOBID"])
print(args["JOBNAME"])
print(args["SOURCE_SECRET_NAME"])
print(args["SMTP_SES_SECRET_NAME"])
print(args["SNS_TOPIC"])
print(args["REDSHIFT_SECRET_NAME"])
print(args["INVENTORY_DATABASE"])
print(args["DATA_CHUNK_SIZE"])
print(args["REGION_NAME"])
print(args["ICEBERG_DB"])
print(args["SNS_LIST_SUCCESS"])
print(args["DB_NAME"])
print(args["REDSHIFT_SCHEMA_NAME"])
print(args["REDSHIFT_AUDIT_TABLE_NAME"])
print(args["REDSHIFT_ETL_MASTER_TABLE_NAME"])
print(args['ATHENA_DB_NAME'])
print(args['LOG_GROUP'])
print(args['ICEBERG_ETL_MASTER_TABLE_NAME'])
print(args['ICEBERG_AUDIT_TABLE_NAME'])
print(args['TIMEZONE'])

conf = SparkConf()
conf.set('spark.sql.extensions', 'org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions')
sc = SparkContext(conf=conf)


glueContext = GlueContext(sc)
spark = glueContext.spark_session
spark.conf.set("spark.sql.session.timeZone", "IST")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
spark.conf.set("spark.sql.session.timeZone", "Asia/Kolkata")

### HADOOP PARAMETERS #####
hadoopConf = sc._jsc.hadoopConfiguration()
hadoopConf.set("fs.s3.maxRetries", "1000")
hadoopConf.set("fs.s3a.experimental.input.fadvise", "random")
hadoopConf.set("fs.s3a.experimental.fadvise", "random")
hadoopConf.set("fs.s3a.readahead.range", "2048K")
hadoopConf.set("fs.s3a.fast.uploa", "true")
### HADOOP PARAMETERS #####

### SPARK TUNING PARAMETERS #####

spark.conf.set("spark.sql.parquet.filterPushdown", "true")
spark.conf.set("spark.sql.shuffle.partitions", 200)
spark.conf.set("spark.sql.files.maxPartitionBytes", 31457280)
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", 524288000)
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", 209715200)
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", 629145600)
spark.conf.set("spark.sql.broadcastTimeout", 900)
# spark.conf.set("spark.driver.maxResultSize", "4g")
# spark.conf.set("spark.driver.memory", "g")
spark.conf.set("spark.sql.debug.maxToStringFields", 1000)
# spark.conf.set("spark.io.compression.codec", "org.apache.spark.io.ZStdCompressionCodec")
spark.conf.set("spark.hadoop.fs.s3a.experimental.input.fadvise", "random")
spark.conf.set("spark.hadoop.fs.s3a.readahead.range", "2048K")
spark.conf.set("spark.hadoop.fs.s3a.fast.upload", "true")
spark.conf.set("spark.hadoop.parquet.filter.stats.enabled", "true")
spark.conf.set("spark.hadoop.fs.s3a.experimental.fadvise", "random")
spark.conf.set("spark.sql.join.preferSortMergeJoin", "false")
### SPARK TUNING PARAMETERS #####


etl_config = ETLConfig(args["SOURCE_SECRET_NAME"], spark, args['REDSHIFT_SECRET_NAME'], args['REGION_NAME'],
                       args['JOBNAME'], args['SNS_TOPIC'], args['SMTP_SES_SECRET_NAME'], args['INVENTORY_DATABASE'],
                       args['DATA_CHUNK_SIZE'], args['ICEBERG_DB'], args['DB_NAME'], args['JOBID'],
                       args['REDSHIFT_SCHEMA_NAME'], args['REDSHIFT_AUDIT_TABLE_NAME'],
                       args['REDSHIFT_ETL_MASTER_TABLE_NAME'], args['ATHENA_DB_NAME'], args['LOG_GROUP'],
                       args['ICEBERG_ETL_MASTER_TABLE_NAME'], args['ICEBERG_AUDIT_TABLE_NAME'], args['TIMEZONE_NAME'])

data_migration_obj = DataMigration(etl_config)
is_success = data_migration_obj.start_ingestion_job()
is_success = is_success[0]
print(" is_success : ")
print(is_success)

if int(is_success) > 0:
    print("job run successfully for job Id:{}".format(args["JOBNAME"]))

job = Job(glueContext)

