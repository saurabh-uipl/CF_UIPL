import boto3
import json
import pyspark
from pyspark.conf import SparkConf
# from pyspark.context import SparkContext
# from awsglue.context import GlueContext
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql import functions as F
from pyspark.sql.types import StructField, StructType, StringType, LongType, IntegerType, ArrayType, DataType
from ..custom_functions.get_json_string_columns import get_json_string_columns
import logging
from pyspark.sql.functions import current_timestamp
from ..src.etl_config import ETLConfig
from ..custom_functions.write_to_iceberg_table import check_table_present


class CommonUtility:
    common_dict = {}
    is_table_present_flag = 0
    logger = logging.getLogger("my_logger")

    @staticmethod
    def remove_binary_columns(df):
        """
        Returns:
            common_dict
        """
        df = df
        try:
            CommonUtility.logger.info("Start Executing {}".format("remove_binary_columns"))
            sql_df_schema = df.schema.json()
            sql_df_schema = json.loads(sql_df_schema)
            schema_fields_json = sql_df_schema['fields']
            for jsonRows in schema_fields_json:
                data_type = jsonRows['type']
                column_name = jsonRows['name']
                if column_name.startswith("/"):
                    new_column_name = column_name.replace('/', '', 1).replace('/', '_')
                    df = df.withColumnRenamed(column_name, new_column_name)
                if data_type == 'binary':
                    CommonUtility.logger.info("***********BINARY DATA TYPE FOUND ****************")

                    CommonUtility.logger.info("*****DROPPING COLUMN ************** {}".format(str(column_name)))
                    df = df.drop(column_name)
            CommonUtility.logger.info("End Execution {}".format("remove_binary_columns"))
            common_dict = {1: df}
        except Exception as e:

            CommonUtility.logger.error("*****ERROR remove_binary_columns ***********")
            CommonUtility.logger.error(str(e))
            common_dict = {1: df}

        return common_dict

    def compare_columns(df1, df2):
        try:
            DF_Schema_1 = json.loads(df1.schema.json())
            lst1 = DF_Schema_1['fields']
            DF_Schema_2 = json.loads(df2.schema.json())
            lst2 = DF_Schema_2['fields']

            lst3 = []
            for jsonRows in lst1:
                columnName = jsonRows['name']
                lst3.append(columnName)
            lst4 = []
            for jsonRows in lst2:
                columnName = jsonRows['name']
                lst4.append(columnName)

            CommonUtility.logger.info([x for x in lst3 if x not in lst4])
            CommonUtility.logger.info([x for x in lst4 if x not in lst3])

            common_dict = {1: 1}

        except Exception as e:

            CommonUtility.logger.error("*****ERROR Compare_Columns ***********")
            CommonUtility.logger.error(str(e))
            common_dict = {1: 0}

        return common_dict

    def check_s3_path(bucket_name, directory_name):
        CommonUtility.logger.info("*****Check_S3_Path ***********")
        exists = 0
        s3_resource = boto3.resource('s3')
        s3 = boto3.client('s3')
        try:
            result = s3.list_objects(Bucket=bucket_name, Prefix=directory_name)
            if "Contents" in result:
                exists = 1

                CommonUtility.logger.info("*****True ***********")
                common_dict = {1: exists}
            else:
                exists = 0

                CommonUtility.logger.info("*****False ***********")
                common_dict = {1: exists}
        except:
            exists = 0

            CommonUtility.logger.info("*****NoSuchKey ***********")
            common_dict = {1: exists}
        return common_dict

    def remove_special_character(table_name):
        table_name = table_name
        CommonUtility.logger.info("*****Remove_Special_Character ***********")
        if table_name.startswith("/"):
            table_name = table_name.replace('/', '', 1).replace('/', '_')
        if '-' in table_name:
            table_name = table_name.replace('-', '_')

        return {1: table_name}

    def sap_supported_table_name(table_name):
        Sap_Supported_Table_Name = table_name
        if '/' in table_name:
            Sap_Supported_Table_Name = '"' + table_name + '"'
            return {1: Sap_Supported_Table_Name}

    def json_flatten(df):
        df.cache()
        logging.info("Starting json_flatten function ....")
        complex_fields = dict([(field.name, field.dataType)
                               for field in df.schema.fields
                               if type(field.dataType) == ArrayType or type(field.dataType) == StructType])
        while len(complex_fields) != 0:
            col_name = list(complex_fields.keys())[0]

            if (type(complex_fields[col_name]) == StructType):
                expanded = [F.col(col_name + '.' + k).alias(col_name + '_' + k) for k in
                            [n.name for n in complex_fields[col_name]]]
                df = df.select("*", *expanded).drop(col_name)

            elif (type(complex_fields[col_name]) == ArrayType):
                df = df.withColumn(col_name, F.explode_outer(col_name))

            complex_fields = dict([(field.name, field.dataType)
                                   for field in df.schema.fields
                                   if type(field.dataType) == ArrayType or type(field.dataType) == StructType])
        logging.info("json_flatten function finished....")
        logging.info(df.rdd.getNumPartitions())
        return df

    '''
    def Json_String_To_Struct(spark, df):

        json_string_columns = []
        if (len(df.head(1)) > 0):
            for data_type in df.dtypes:
                if data_type[1][:6] == "string":
                    value = df.collect()[0][data_type[0][:]]
                    if value.startswith("{") == True and value.endswith("}") == True or value.startswith(
                            "[") == True and value.endswith("]") == True:
                        json_string_columns.append(data_type[0][:])
        flatten_json_df = None
        if len(json_string_columns) > 0:
            for json_string_column in json_string_columns:
                json_schema = spark.read.json(df.rdd.map(lambda row: row[json_string_column])).schema
                flatten_json_string_df = df.withColumn(json_string_column,
                                                       F.from_json(F.col(json_string_column), json_schema))
                flatten_json_string_final_df = CommonUtility.Json_Flatten(flatten_json_string_df)
                df_select = flatten_json_string_final_df.select("pull_time", "updatetime")
                df_drop = flatten_json_string_final_df.drop("pull_time", "updatetime")
                flatten_json_df = df_drop.join(df_select).dropDuplicates()
        else:
            flatten_json_df = df
        return flatten_json_df
    '''

    def json_string_to_struct(spark, df, logger):
        logger.info("Executing json_string_to_struct function ......")
        logger.info("Ok")
        json_string_columns = get_json_string_columns(spark, df, logger)
        logger.info("json_string_columns")
        logger.info(str(json_string_columns))
        if len(json_string_columns) > 0:
            logger.info("len(json_string_columns) > 0....")
            for json_string_column in json_string_columns:
                logger.info("Iterate json_string_column.......")
                logger.info("Read JSON and get schema")
                json_schema = spark.read.json(df.rdd.map(lambda row: row[json_string_column])).schema
                logger.info(" Adding columns.....")
                flatten_json_string_df = df.withColumn(json_string_column, F.from_json(F.col(json_string_column), json_schema))
                logger.info("Column added...")
                logger.info(" Calling json_flatten function ....")
                flatten_json_string_final_df = CommonUtility.json_flatten(flatten_json_string_df)
                logger.info("Adding pull_time column...")
                df_select = flatten_json_string_final_df.select("pull_time", "updatetime")
                df_drop = flatten_json_string_final_df.drop("pull_time", "updatetime")
                df_drop_dups = df_drop.dropDuplicates()
                df_add_ts_cols_df = df_drop_dups.withColumn("pull_time", current_timestamp())
                df_add_ts_cols_df = df_add_ts_cols_df.withColumn("updatetime", current_timestamp())
                '''
                logger.info("Apply JOIN on DFs....")
                flatten_json_df = df_drop.join(df_select)
                '''
                flatten_json_df = df_add_ts_cols_df
        else:
            logger.info("No String Columns")
            flatten_json_df = df
        return flatten_json_df

    # def get_s3_file_paths(bucket_name, prefix):
    #     is_success = True
    #     try:
    #         client = boto3.client('s3')
    #         file_paths = []
    #         response = client.list_objects_v2(
    #             Bucket=bucket_name,
    #             Prefix=prefix)
    #
    #         for content in response.get('Contents', []):
    #             print(content['Key'])
    #             file_paths.append('s3://' + bucket_name + '/' + content['Key'])
    #             return file_paths, is_success
    #     except Exception as e:
    #         is_success = False
    #         file_paths = None
    #         CommonUtility.logger.error(" Error Occurred .....")
    #         CommonUtility.logger.error(str(e))
    #         return file_paths, is_success
    # def write_to_iceberg_table(df_final, jobdict):
    #
    #     conf = (
    #         pyspark.SparkConf()
    #         # SQL Extensions
    #         # .set('spark.sql.extensions', 'org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions')
    #         # Configuring Catalog
    #         .set('spark.sql.catalog.uipl', 'org.apache.iceberg.spark.SparkCatalog')
    #         .set('spark.sql.catalog.uipl.catalog-impl', 'org.apache.iceberg.aws.glue.GlueCatalog')
    #         .set('spark.sql.catalog.uipl.warehouse', 's3://{0}/'.format(jobdict["bucket_name"]))
    #         .set('spark.sql.catalog.uipl.io-impl', 'org.apache.iceberg.aws.s3.S3FileIO')
    #         .set('spark.sql.iceberg.handle-timestamp-without-timezone', True)
    #         .set('spark.sql.iceberg.use-timestamp-without-timezone-in-new-tables', True)
    #     )
    #     spark = SparkSession.builder.config(conf=conf).getOrCreate()
    #
    #     #        for col in df_final.columns:
    #     #            df_final = df_final.withColumnRenamed(col, col.lower())
    #     #        df_final.createOrReplaceTempView("df_final")
    #     df_final.printSchema()
    #
    #     if len(jobdict["Partition_Column"]) > 0:
    #         Partition_Column_TABLE = str(jobdict["Partition_Column"])[1:-1].replace("'", '').lower()
    #     else:
    #         pass
    #     df_final.createOrReplaceTempView('df_final')
    #
    #     try:
    #         s3_client = boto3.client('athena')
    #         responce = s3_client.get_table_metadata(
    #             CatalogName='awsdatacatalog',
    #             DatabaseName=f'{jobdict["iceberg_db"]}',
    #             TableName=f'{jobdict["table_name"]}'
    #         )
    #     except Exception as e:
    #         CommonUtility.is_table_present_flag = 1
    #     spark.sql(f'CREATE DATABASE IF NOT EXISTS uipl.{jobdict["iceberg_db"]}')
    #
    #     if len(jobdict["Partition_Column"]) > 0 and Partition_Column_TABLE != '<na>':
    #         CommonUtility.logger.error("Partition_Column_TABLE : {}".format(Partition_Column_TABLE))
    #
    #         query = f"""
    #             CREATE TABLE uipl.{jobdict["iceberg_db"]}.{jobdict["table_name"]}
    #             USING iceberg TBLPROPERTIES ('format-version' = '2')
    #             PARTITIONED BY ({Partition_Column_TABLE})
    #             AS SELECT * FROM df_final
    #             ORDER BY {Partition_Column_TABLE}
    #             """
    #     else:
    #
    #         query = f"""
    #             CREATE TABLE uipl.{jobdict["iceberg_db"]}.{jobdict['table_name']}
    #             USING iceberg TBLPROPERTIES ('format-version' = '2')
    #             AS SELECT * FROM df_final
    #             """
    #     spark.sql(query)
    #
    #     iceberg_dict = {1: spark, 2: CommonUtility.is_table_present_flag, 3: df_final}
    #     return iceberg_dict

    def align_dataframe_schema_with_iceberg_table(job_dict, logger, df_final, spark, etl_config: ETLConfig):
        logger.info('Compare newly incoming data columns with existing columns')
        try:
            #            write_load_flag = 1
            table_name_val_list = job_dict["table_name"].split('/')
            if len(table_name_val_list) > 1:
                table_name = table_name_val_list[0]
                # print('r = ', r)
            else:
                table_name = table_name_val_list[-1]
                # print('t = ', t)
            #            table_name_val_list = job_dict["table_name"].split('/')
            #            table_name = table_name_val_list[len(table_name_val_list) - 2]
            #            if len(table_name) < 2:
            #                table_name = table_name_val_list[len(table_name_val_list) - 1]

            is_table_present = check_table_present(logger, job_dict, etl_config)
            logger.info(" is_table_present: ")
            logger.info(is_table_present)
            if is_table_present:
                logger.info("Table found for schema match")
                logger.info("Read data of existing table")
                logger.info("Table Name:" + str(table_name))
                df_tbl = spark.read.format("iceberg").load(f'uipl.{etl_config.athena_db_name}.{table_name}')
                df_columns = df_tbl.columns
                logger.info('Schema of existing table')
                logger.info(df_columns)
                df_columns = [column.lower() for column in df_columns]
                df_tbl = df_tbl.toDF(*df_columns)
                df_columns = df_final.columns
                df_columns = [column.lower() for column in df_columns]
                df_final = df_final.toDF(*df_columns)
                df_tbl.printSchema()
                df_final.printSchema()
                logger.info("Checking column diff")
                column_list_dif = [col for col in df_tbl.dtypes if col not in df_final.dtypes]
                logger.info(column_list_dif)
                if len(column_list_dif) > 0:
                    logger.info("Some columns have been deleted from source")
                    logger.info("List of columns deleted from source")
                    logger.info(str(column_list_dif))
                    for col in column_list_dif:
                        if col[0] not in df_final.columns:
                            df_final = df_final.withColumn(col[0], F.lit(None))
                            df_final = df_final.withColumn(col[0], F.col(col[0]).cast(col[1]))
                        elif col[1] == 'timestamp':
                            df_check = df_final.filter(length(F.col(col[0])) > 0)
                            if df_check.select(col[0]).collect()[0][0][len(df_check.select(col[0]).collect()[0][0]) - 1] == 'M':
                                # df_final = df_final.withColumn(col[0], from_utc_timestamp(F.col(col[0]),etl_config.timezone_param))
                                df_final = df_final.withColumn(col[0], from_utc_timestamp(to_timestamp(F.col(col[0]), "M/d/yyyy h:m:ss a"), etl_config.timezone_param))
                            else:
                                df_final = df_final.withColumn(col[0], F.col(col[0]).cast(col[1]))
                        else:
                            df_final = df_final.withColumn(col[0], F.col(col[0]).cast(col[1]))

                column_list_dif_1 = [col for col in df_final.dtypes if col not in df_tbl.dtypes and col[0] != 'file_date']
                if len(column_list_dif_1) > 0:
                    logger.info("Add missing columns in destination Iceberg table")
                    logger.info("List of missing columns in destination Iceberg table:-")
                    logger.info(str(column_list_dif_1))
                    for col in column_list_dif_1:
                        logger.info("Adding " + str(col) + " in Iceberg")
                        query = f"""ALTER TABLE uipl.{etl_config.athena_db_name}.{table_name}
                                            ADD COLUMNS (
                                                {col[0]} {col[1]}
                                              )"""
                        logger.info(query)
                        spark.sql(query)
                df_tbl = spark.read.format("iceberg").load(f'uipl.{etl_config.athena_db_name}.{table_name}')
                df_tbl_columns = df_tbl.columns
                #            df_tbl_columns.append('file_date')
                df_final = df_final.select(df_tbl_columns)
                df_tbl.printSchema()
                df_final.printSchema()
                df_columns = df_final.columns
                df_columns = [column.lower() for column in df_columns]
                df_final = df_final.toDF(*df_columns)
            else:
                logger.info("Table not found for schema match")
        except Exception as e:
            logger.error('error occurred')
            logger.error(str(e))
            # add_failed_table_entry(job_dict, etl_config, logger, str(e))
            return None
        return df_final
