# common_utilities/__init__.py

from .Common_utility import CommonUtility
