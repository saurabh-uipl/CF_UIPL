import datetime
import pytz
import inspect
import logging
from ..custom_functions.create_params_dict import create_params_dict
from ..custom_functions.create_redshift_connection import create_redshift_connection
from ..custom_functions.merge_incremental_load import merge_incremental_load
from ..custom_functions.convert_to_pandas import convert_to_pandas
from ..custom_functions.create_audit_entry import create_audit_entry, create_connection, exception_records_process
from .get_source_tables import get_source_table_details
from ..custom_functions.send_job_notifications import send_job_notifications, job_notification
from ..analytics_utilities.secrets_manager import SecretsManager
from ..custom_functions.full_load import full_load
from ..push_logs_to_cloudwatch.cloudwatch_logs import get_cloudwatch_logger
from .etl_config import ETLConfig
from ..custom_functions.send_job_notifications import send_s3_iceberg_batch_only
from ..custom_functions.s3_files_iceberg_migration import run_s3_files_iceberg_job

class DataMigration:
    is_success = 0

    def __init__(self, etl_config: ETLConfig) -> None:
        self.etl_config = etl_config
        self.logger = self.__setup_logger()

        """
        Args:
        etl_config

        """

    def __setup_logger(self):
        logger = get_cloudwatch_logger(self.etl_config.log_group, self.etl_config.job_id)
        logger.setLevel(logging.INFO)
        return logger

    def start_ingestion_job(self):
        """
        Starts the ingestion job.

        Returns:
            is_success:
            redshift_conn_details:
        """
        self.logger.info('Executing start_ingestion_job ')
        self.logger.info('Executing read_table_data_as_df ')
        table_list_pandas_df, success = get_source_table_details(self.etl_config.redshift_secret_name, self.etl_config)
        '''
        self.logger.info('Executing send_job_notifications')
        notify_object, success = send_job_notifications(
            table_list_pandas_df,
            self.etl_config)
        '''
        # Detect if this is S3 → Iceberg only job
        is_s3_iceberg_only = False

        for k, row in table_list_pandas_df.iterrows():
            if (
                    str(row.get("inventory", "NA")) == 'NA' and
                    str(row.get("chunk_size", "NA")) == 'NA' and
                    str(row.get("source", "")).lower() == "s3_files" and
                    str(row.get("destination_type", "")).lower() == "iceberg"
            ):
                is_s3_iceberg_only = True
            else:
                is_s3_iceberg_only = False
                break

        if not is_s3_iceberg_only:
            self.logger.info('Executing send_job_notifications')
            notify_object, success = send_job_notifications(
                table_list_pandas_df,
                self.etl_config)
        else:
            self.logger.info('Skipping generic START notification for S3 → Iceberg flow')
            notify_object = {"notification_type": "SNS"}  # So completion logic still works

        # ============================================================
        # DIRECT S3_FILES → ICEBERG EXECUTION (SKIP FULL FRAMEWORK)
        # ============================================================
        '''
        if is_s3_iceberg_only:
            self.logger.info("Direct execution of S3_FILES → ICEBERG job. Skipping generic ingestion loop.")

            # Use first row only (priority 1)
            first_row = table_list_pandas_df.iloc[0]

            job_dict, success = create_params_dict(
                first_row,
                None,  # redshift_conn_details not needed for s3_files
                self.etl_config
            )

            # Run custom handler directly
            is_success, is_error = run_s3_files_iceberg_job(job_dict, self.etl_config)

            return is_success, {}
        '''
        # ============================================================
        # DIRECT S3_FILES → ICEBERG EXECUTION (SKIP FULL FRAMEWORK)
        # ============================================================

        first_row = table_list_pandas_df.iloc[0]

        if (
                str(first_row.get("source", "")).lower() == "s3_files" and
                str(first_row.get("destination_type", "")).lower() == "iceberg"
        ):
            self.logger.info("Direct S3_FILES → ICEBERG execution. Skipping full framework.")

            job_dict, success = create_params_dict(
                first_row,
                None,  # no redshift needed
                self.etl_config
            )

            is_success, is_error = run_s3_files_iceberg_job(job_dict, self.etl_config)

            return is_success, {}


        self.logger.info(" notify_object: ")
        redshift_conn_details = {}
        source_conn_details = {}

        if self.etl_config.redshift_secret_name != 'NA':
            self.logger.info('Executing SAMUtility , only if redshift_secret_name != NA')
            secrets_manager_obj = SecretsManager(self.etl_config.redshift_secret_name, self.etl_config)
            redshift_secrets_json, success = secrets_manager_obj.get_secret_name()
            redshift_conn_details = redshift_secrets_json[1]
        if self.etl_config.source_secret_name != 'NA':
            self.logger.info('Executing SAMUtility , only if source_secret_name != NA')
            secrets_manager_obj = SecretsManager(self.etl_config.source_secret_name, self.etl_config)
            source_secrets_json, success = secrets_manager_obj.get_secret_name()
            source_conn_details = source_secrets_json[1]

        job_dict = None
        conn_pg8000 = None
        if self.etl_config.redshift_secret_name != 'NA':
            self.logger.info(
                'Executing create_redshift_connection , only if redshift_secret_name != NA '
                '!= NA')
            conn_pg8000, success = create_redshift_connection(redshift_conn_details, self.etl_config.
                                                              redshift_secret_name)
        for k, row in table_list_pandas_df.iterrows():
            self.logger.info('Executing create_job_dict')
            job_dict, success = create_params_dict(row,
                                                   redshift_conn_details, self.etl_config)

            job_dict['conn_pg8000'] = conn_pg8000

            if job_dict["load_type"] in ["incremental", "merge"]:

                self.logger.info(" Load Type Is : {}".format(str(job_dict["load_type"])))
                self.logger.info(
                    'Executing merge_incremental_load only if load_type == incremental or load_type == merge')
                self.logger.info("calling merge_incremental_load")
                merge_incr_response = merge_incremental_load(job_dict, source_conn_details,
                                                             self.etl_config)

                if merge_incr_response:

                    job_dict = self.display_response(merge_incr_response)

                else:
                    self.logger.info(" merge_incr_response is Blank")

            else:

                self.logger.info(" Load Type Is : {}".format(str(job_dict["load_type"])))
                self.logger.info(" calling full_load ....")

                self.logger.info(
                    'Executing execute_ingestion_job')
                full_load_response = full_load(job_dict,
                                               source_conn_details, self.etl_config)

                if full_load_response:
                    job_dict = self.display_response(full_load_response)

                else:
                    self.logger.info(" full_load_response is blank... ")

        is_success = 1
        self.logger.info(" notify_object: ")
        '''
        if notify_object['notification_type'] == 'SES':
            self.logger.info('Executing job_notification only if notification_type == SES ')
            job_notification(self.etl_config,
                             job_dict, notify_object['sender'], notify_object['recipients'],
                             notify_object['smtp_ses_user'], notify_object['smtp_ses_password']
                             , notify_object['smtp_endpoint'])
        elif notify_object['notification_type'] == 'SNS':
            self.logger.info('Executing job_notification only if notification_type == SNS ')
            job_notification(self.etl_config, job_dict, 'NA', 'NA', 'NA', 'NA', 'NA')
        else:
            self.logger.info("Notification is not enabled for job completion ...")
        '''
        # Skip generic completion notification for S3 → Iceberg flow
        if not is_s3_iceberg_only:

            if notify_object['notification_type'] == 'SES':
                self.logger.info('Executing job_notification only if notification_type == SES ')
                job_notification(
                    self.etl_config,
                    job_dict,
                    notify_object['sender'],
                    notify_object['recipients'],
                    notify_object['smtp_ses_user'],
                    notify_object['smtp_ses_password'],
                    notify_object['smtp_endpoint']
                )

            elif notify_object['notification_type'] == 'SNS':
                self.logger.info('Executing job_notification only if notification_type == SNS ')
                job_notification(
                    self.etl_config,
                    job_dict,
                    'NA', 'NA', 'NA', 'NA', 'NA'
                )

            else:
                self.logger.info("Notification is not enabled for job completion ...")

        else:
            self.logger.info("Skipping generic completion notification for S3 → Iceberg flow")

        # Send ONE completion mail for S3 → Iceberg flow
        if is_s3_iceberg_only:
            send_s3_iceberg_batch_only(self.etl_config, job_dict, "COMPLETED")
        return is_success, redshift_conn_details

    def display_response(self, response):
        success_jobs = response['success']
        failure_jobs = response['failure']
        job_dict = response['job_dict']
        self.logger.info(" Success Jobs: ")
        # for job in success_jobs:
        # self.logger.info('{}'.format(job))
        self.logger.info("\nFailed jobs:")
        for job in failure_jobs:
            self.logger.info('{}'.format(job))
        return job_dict
