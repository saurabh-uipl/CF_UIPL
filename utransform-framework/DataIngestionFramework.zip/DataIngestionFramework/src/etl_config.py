import logging
import datetime
import pytz

class ETLConfig:

    def __init__(self, source_secret_name, glueContext,
                 redshift_secret_name='NA', region_name="region_name", job_name='JOBNAME',
                 sns_topic='NA', smtp_ses_secret_name='NA',
                 inventory_database='NA', data_chunk_size='NA', iceberg_db='NA',
                 db_name='NA', job_id='NA', redshift_schema_name='NA',
                 redshift_audit_table_name='NA', redshift_etl_master_table_name='NA', athena_db_name='NA',
                 log_group='NA', iceberg_etl_master_table_name='NA', iceberg_audit_table_name='NA',
                 timezone_param='NA', redshift_dest_db = 'NA', redshift_dest_schema = 'NA',
                 rs_iam_role_arn = 'NA', rs_temp_bucket_uri = 'NA'
                 ) -> None:
        self.iceberg_audit_table_name = iceberg_audit_table_name
        self.date_format = '%Y-%m-%d %H:%M:%S'
        self.logger = logging.getLogger(job_name)
        self.logger.setLevel(logging.INFO)
        self.sns_list_tables = []
        self.sns_list_failure = []
        self.sns_list_success = []
        self.path_list = []
        self.final_path_list = []
        self.is_table_present_flag = 0
        self.tbl_name_flag = 0
        self.chunk_flag = 0
        self.redshift_secret_name = redshift_secret_name
        self.region_name = region_name
        self.job_name = job_name
        self.redshift_schema_name = redshift_schema_name
        self.redshift_audit_table_name = redshift_audit_table_name
        self.redshift_etl_master_table_name = redshift_etl_master_table_name
        #self.current_time = lambda: datetime.datetime.now(pytz.timezone('Asia/Kolkata'))
        # move to configuration file
        self.sns_topic = sns_topic
        self.smtp_ses_secret_name = smtp_ses_secret_name
        self.source_secret_name = source_secret_name
        self.inventory_database = inventory_database
        self.data_chunk_size = data_chunk_size
        self.iceberg_db = iceberg_db
        self.glueContext = glueContext
        self.db_name = db_name
        self.job_id = job_id
        self.read_from_redshift = None
        self.athena_db_name = athena_db_name
        self.log_group = log_group
        self.iceberg_etl_master_table_name = iceberg_etl_master_table_name
        self.timezone_param = timezone_param
        self.redshift_dest_db = redshift_dest_db
        self.redshift_dest_schema = redshift_dest_schema
        self.rs_iam_role_arn = rs_iam_role_arn,
        self.rs_temp_bucket_uri = rs_temp_bucket_uri