from ..custom_functions.read_from_redshift import ReadFromRedshift
from ..custom_functions.read_from_iceberg import IceBerg
import logging
from .etl_config import ETLConfig

logger = logging.getLogger("my_logger")


def get_source_table_details(redshift_secret_name, etl_config: ETLConfig):
    """


    Args:
        redshift_secret_name:
        etl_config:


        Returns :
            data:
    """
    success = True
    try:
        if redshift_secret_name != 'NA':

            logger.info("redshift_secret_name is not blank ")
            logger.info('Executing read_from_redshift, only if redshift_secret_name != NA for job_id : '
                        )

            read_from_redshift_obj = ReadFromRedshift(redshift_secret_name, etl_config)
            data, success = read_from_redshift_obj.read_from_redshift()
            return data, success
        else:
            logger.info('Executing Iceberg, only if redshift_secret_name = NA ')
            read_from_iceberg = IceBerg(etl_config)

            data, success = read_from_iceberg.read_from_iceberg()

            return data, success
    except Exception as e:

        logger.error('error occurred')
        logger.error(str(e))

        success = False
        data = None
        return data, success
