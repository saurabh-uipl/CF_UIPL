from DataIngestionFramework.custom_functions.write_to_iceberg_table import write_to_iceberg_table_v1
from DataIngestionFramework.s3_data_ingestion.data_ingestion_method import align_dataframe_schema_with_iceberg_table
from DataIngestionFramework.src.etl_config import ETLConfig


def load_and_process_data_v1(job_dict, final_path_list, schema_name, source, spark, logger, etl_config: ETLConfig):
    try:
        is_success = True
        logger.info(" inside load_and_process_data ......")
        logger.info(" final_path_list: ")
        logger.info(final_path_list)
        write_load_flag = 0

        if job_dict['business_unit'].lower() == 'haptik':
            if len(final_path_list) > 0:
                logger.info("Running for haptik source in data ingetstion method")
                path = final_path_list
                if source == "csv":
                    logger.info(" Reading CSV ....")
                    df = spark.read.option("header", "true").format(source).load(path)
                    df = df.where(~df['_c0'].isin(schema_name))
                    df = df.toDF(*schema_name)

                elif source == "json":
                    logger.info(" Reading json ....")
                    try:
                        df = spark.read.format(source).load(path)
                    except Exception as e:
                        df = spark.read.option("multiline", 'true').format(source).load(path)

                    if str(job_dict['json_flatten']) == '1':
                        df = CommonUtility.json_flatten(df)
                        logger.info(" Json flat is enabled .....")
                    else:
                        logger.info('json flatten is disabled')

                else:
                    logger.info(" Reading Parquet or non CSV/JSON ....")
                    df = spark.read.format(source).load(path)
                logger.info(" Table has been created successfully from s3 files .....")
                df.createOrReplaceTempView('table')
                logger.info(" sql_query ....:::")
                logger.info(job_dict["SQL_Query"])
                logger.info(" JOBNAME: ")
                logger.info(job_dict['JOBNAME'])
                df = spark.sql(job_dict["SQL_Query"])
                df.createOrReplaceTempView('df')
                sql_query_staging = "select *, current_timestamp as pulled_time, " \
                                    "current_timestamp as update_time, " \
                                    "current_timestamp as bdl_created, '{pipeline_id}' as pipelineid from df"
                logger.info(" sql_query_staging ....")
                logger.info(sql_query_staging)
                sql_query_staging = sql_query_staging.format(pipeline_id=job_dict['JOBNAME'])
                logger.info(" updated sql_query_staging ....")
                logger.info(sql_query_staging)
                df = spark.sql(sql_query_staging)
                df = df.withColumn('file_date', F.split(F.split(F.input_file_name(), '/')[9], 'T')[0])
                logger.info(" Display DF .......")
                logger.info(" display table schema .....")
                df.printSchema()
                logger.info(" calling Remove_Special_Character ......")
                table_name_list = job_dict["table_name"].split('/')
                table_name = table_name_list[len(table_name_list) - 2].replace('-', '_')
                if len(table_name.strip()) < 2:
                    table_name = table_name_list[len(table_name_list) - 2].replace('-', '_')

                dir_check = CommonUtility.remove_special_character(table_name)
                logger.info(" dir_check .....")
                logger.info(dir_check)
                table_names3_suported = dir_check[1]
                logger.info(" table_names3_supported.....".format(table_names3_suported))

                logger.info(table_names3_suported)
                job_dict["table_name"] = table_names3_suported
                logger.info('job_dict '.format(job_dict["table_name"]))
                df_columns = df.columns
                df_columns = [column.lower() for column in df_columns]
                df_final = df.toDF(*df_columns)
                logger.info(" calling write_to_iceberg_table_v1 ......")
                ###Pass df_final to JSON Flat function

                iceberg = write_to_iceberg_table_v1(df_final, job_dict, write_load_flag, etl_config, table_name)

                spark = iceberg[1]
                is_table_present_flag = iceberg[2]
                df_final = iceberg[3]

                temp_df = align_dataframe_schema_with_iceberg_table(job_dict, logger, df_final, spark, etl_config)

                try:
                    temp_df_1 = temp_df_1.unionByName(temp_df, allowMissingColumns=True)
                    logger.info(" Performed Union")
                    temp_df_1.printSchema()
                except Exception as e:
                    logger.error("exception 271")
                    temp_df_1 = temp_df
                    logger.error(" temp_df is assigned to temp_df_1")
                    logger.error(str(e))
                ##### For Loop Ends Here

                temp_df_1.createOrReplaceTempView('staging_table')
                logger.info("STAGING TABLE CREATED SUCCESSFULLY")
                logger.info(" count before row_num: ")
                temp_df_1_cnt = temp_df_1.count()
                logger.info(str(temp_df_1_cnt))
                temp_df_1.printSchema()
                if job_dict["load_type"] == "merge":
                    print("MERGE QUERY :", job_dict["merge_query"])
                    deltaDF = spark.sql(job_dict["merge_query"])
                    logger.info("merge_query executed SUCCESSFULLY")
                    deltaDF = deltaDF.drop('row_num')
                    logger.info("printing deltaDf")
                    df = deltaDF
                    df_final = deltaDF
                else:
                    df_final = temp_df_1
                df_final = df_final.drop('file_date')
                logger.info('counts in df_final after row_num')
                df_final_cnt = df_final.count()
                logger.info(str(df_final_cnt))
                write_load_flag = 1
                iceberg = write_to_iceberg_table_v1(df_final, job_dict, write_load_flag, etl_config, table_name)
                spark = iceberg[1]
                is_table_present_flag = iceberg[2]
                df_final = iceberg[3]
                write_load_flag = 0
                df = df_final
                return df, is_success
            else:
                logger.info('setting df as  none')
                df = None
                is_success = True
                return df, is_success



        else:

            if len(final_path_list) > 0:
                path_list_length = len(final_path_list)
                for i in range(path_list_length):
                    path = final_path_list.pop(0)
                    logger.info(" path: *****")
                    logger.info(path)
                    print('Processing Data Of Below path :', path)
                    logger.info("Processing Data Of Below path :")
                    logger.info(path)
                    logger.info(" source is ")
                    logger.info(source)
                    if source == "csv":
                        logger.info(" Reading CSV ....")
                        df = spark.read.option("header", "true").format(source).load(path)
                        df = df.where(~df['_c0'].isin(schema_name))
                        df = df.toDF(*schema_name)

                    elif source == "json":
                        logger.info(" Reading json ....")
                        try:
                            df = spark.read.format(source).load(path)
                        except Exception as e:
                            df = spark.read.option("multiline", 'true').format(source).load(path)

                        if str(job_dict['json_flatten']) == '1':
                            df = CommonUtility.json_flatten(df)
                            logger.info(" Json flat is enabled .....")
                        else:
                            logger.info('json flatten is disabled')

                    else:
                        logger.info(" Reading Parquet or non CSV/JSON ....")
                        df = spark.read.format(source).load(path)
                    logger.info(" Table has been created successfully from s3 files .....")
                    df.createOrReplaceTempView('table')
                    logger.info(" sql_query ....:::")
                    logger.info(job_dict["SQL_Query"])
                    logger.info(" JOBNAME: ")
                    logger.info(job_dict['JOBNAME'])
                    df = spark.sql(job_dict["SQL_Query"])
                    df.createOrReplaceTempView('df')
                    sql_query_staging = "select *, current_timestamp as pulled_time, " \
                                        "current_timestamp as update_time, " \
                                        "current_timestamp as bdl_created, '{pipeline_id}' as pipelineid from df"
                    logger.info(" sql_query_staging ....")
                    logger.info(sql_query_staging)
                    sql_query_staging = sql_query_staging.format(pipeline_id=job_dict['JOBNAME'])
                    logger.info(" updated sql_query_staging ....")
                    logger.info(sql_query_staging)
                    df = spark.sql(sql_query_staging)
                    df = df.withColumn('file_date', F.split(F.split(F.input_file_name(), '/')[9], 'T')[0])
                    logger.info(" Display DF .......")
                    logger.info(" display table schema .....")
                    df.printSchema()
                    logger.info(" calling Remove_Special_Character ......")
                    table_name_list = job_dict["table_name"].split('/')
                    table_name = table_name_list[len(table_name_list) - 2].replace('-', '_')
                    if len(table_name.strip()) < 2:
                        table_name = table_name_list[len(table_name_list) - 2].replace('-', '_')

                    dir_check = CommonUtility.remove_special_character(table_name)
                    logger.info(" dir_check .....")
                    logger.info(dir_check)
                    table_names3_suported = dir_check[1]
                    logger.info(" table_names3_supported.....".format(table_names3_suported))

                    logger.info(table_names3_suported)
                    job_dict["table_name"] = table_names3_suported
                    logger.info('job_dict '.format(job_dict["table_name"]))
                    df_columns = df.columns
                    df_columns = [column.lower() for column in df_columns]
                    df_final = df.toDF(*df_columns)
                    logger.info(" calling write_to_iceberg_table_v1 ......")
                    logger.info(df_final)
                    ###Pass df_final to JSON Flat function
                    # if str(job_dict['json_flatten']) == '1':
                    #     logger.info(" Json flat is enabled .....")
                    #     df_final = CommonUtility.json_flatten(df_final)
                    # else:
                    #     logger.info(" Json Flat is disabled ....")

                    iceberg = write_to_iceberg_table_v1(df_final, job_dict, write_load_flag, etl_config, table_name)

                    spark = iceberg[1]
                    is_table_present_flag = iceberg[2]
                    df_final = iceberg[3]

                    temp_df = align_dataframe_schema_with_iceberg_table(job_dict, logger, df_final, spark, etl_config)

                    try:
                        temp_df_1 = temp_df_1.unionByName(temp_df, allowMissingColumns=True)
                        logger.info(" Performed Union")
                        temp_df_1.printSchema()
                    except Exception as e:
                        logger.error("exception 271")
                        temp_df_1 = temp_df
                        logger.error(" temp_df is assigned to temp_df_1")
                        logger.error(str(e))
                ##### For Loop Ends Here

                temp_df_1.createOrReplaceTempView('staging_table')
                logger.info("STAGING TABLE CREATED SUCCESSFULLY")
                logger.info(" count before row_num: ")
                temp_df_1_cnt = temp_df_1.count()
                logger.info(str(temp_df_1_cnt))
                temp_df_1.printSchema()
                if job_dict["load_type"] == "merge":
                    print("MERGE QUERY :", job_dict["merge_query"])
                    deltaDF = spark.sql(job_dict["merge_query"])
                    logger.info("merge_query executed SUCCESSFULLY")
                    deltaDF = deltaDF.drop('row_num')
                    logger.info("printing deltaDf")
                    df = deltaDF
                    df_final = deltaDF
                else:
                    df_final = temp_df_1
                df_final = df_final.drop('file_date')
                logger.info('counts in df_final after row_num')
                df_final_cnt = df_final.count()
                logger.info(str(df_final_cnt))
                write_load_flag = 1
                iceberg = write_to_iceberg_table_v1(df_final, job_dict, write_load_flag, etl_config, table_name)
                spark = iceberg[1]
                is_table_present_flag = iceberg[2]
                df_final = iceberg[3]
                write_load_flag = 0
                df = df_final
                return df, is_success


            else:
                logger.info('Setting  df as none ')
                df = None
                is_success = True
                return df, is_success
    except Exception as e:
        logger.error(" Error ...***&&&")
        logger.error(str(e))
        df = None
        is_success = False
        add_failed_table_entry(job_dict, etl_config, logger, str(e))
        return df, is_success