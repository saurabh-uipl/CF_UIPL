CREATE OR REPLACE PROCEDURE prod_etl_framework_schema.data_validation_prod_sp_name(integer, character varying(65535), character varying(100))
 LANGUAGE plpgsql
AS $_$
DECLARE  
    ETL_GROUPID ALIAS FOR $1;
    REDSHIFT_TABLES_SCHEMA ALIAS FOR $2;
    SOURCE_TABLES_SCHEMA ALIAS FOR $3;
    ETL_MASTER_ROW RECORD;
    SQL_COUNT_QUERY VARCHAR(10000);
    ETL_MASTER_CURSOR REFCURSOR;
    DAYS_FILTER VARCHAR(100);
    MYSQL_COUNT BIGINT;
    REDSHIFT_COUNT BIGINT;
    ERROR_INSERT_SQL VARCHAR(1000);
    
    REDSHIFT_ETL_MASTER_SCHEMA VARCHAR(100);
    REDSHIFT_ETL_MASTER_TABLE_NAME VARCHAR(100);

    
    -- TEMP VARIABLES 
    SOURCE_COUNT INT;
    DATALAKE_COUNT INT;
    SOURCE_COUNT_SQL VARCHAR(1000);
    DATALAKE_COUNT_SQL VARCHAR(1000);
    REDSHIFT_DATA_VALIDATION_TABLE VARCHAR(1000);
    DATA_VALIDATION_INSERT_SQL VARCHAR(1000);
    
    SOURCE_CURR_OFFSET_SQL VARCHAR(1000);
    DATALAKE_CURR_OFFSET_SQL VARCHAR(1000);
    SOURCE_CURR_OFFSET INT;
    DATALAKE_CURR_OFFSET INT;
    
    SOURCE_CURR_OFFSET_TIMESTAMP TIMESTAMP;
    DATALAKE_CURR_OFFSET_TIMESTAMP TIMESTAMP;
    
    BEGIN 
    	REDSHIFT_ETL_MASTER_SCHEMA := 'REDSHIFT_ETL_MASTER_SCHEMA_NAME';
    	REDSHIFT_ETL_MASTER_TABLE_NAME := 'REDSHIFT_ETL_MASTER_TABLE_NAME';
    	REDSHIFT_DATA_VALIDATION_TABLE := 'REDSHIFT_DATA_VALIDATION_TABLE_NAME';
  	
        OPEN ETL_MASTER_CURSOR FOR EXECUTE 'SELECT * FROM  '||REDSHIFT_ETL_MASTER_SCHEMA||'.'||REDSHIFT_ETL_MASTER_TABLE_NAME||' WHERE GROUPID = '||ETL_GROUPID||'  AND DATA_VALIDATION_ACTIVE  = 1   ORDER BY PRIORITY ASC ';
        LOOP
		    BEGIN
			    FETCH ETL_MASTER_CURSOR INTO ETL_MASTER_ROW;
                    EXIT WHEN  NOT  FOUND;
                    DAYS_FILTER := '1 day';
                    RAISE INFO 'GROUPID: %', ETL_MASTER_ROW.GROUPID;
                    RAISE INFO 'TABLENAME: %', ETL_MASTER_ROW.TABLENAME;
                    RAISE INFO 'DATA VALIDATION INCREMENTAL COLUMN : %', ETL_MASTER_ROW.DATA_VALIDATION_DATE_COLUMN;
                    RAISE INFO 'OFFSET_VALUE : %', ETL_MASTER_ROW.OFFSET_VALUE;
                    RAISE INFO 'LOAD_TYPE : %', ETL_MASTER_ROW.LOADTYPE;
                    
                    
                    IF UPPER(ETL_MASTER_ROW.LOADTYPE) = 'MERGE' OR UPPER(ETL_MASTER_ROW.LOADTYPE) =  'INCREMENTAL'            
				    THEN 
                        IF ETL_MASTER_ROW.OFFSET_VALUE IS NOT NULL
                        THEN 

                            RAISE INFO 'LOAD TYPE IS : %', ETL_MASTER_ROW.LOADTYPE;
                            
                            SOURCE_COUNT_SQL := 'SELECT COUNT(*)  FROM '||SOURCE_TABLES_SCHEMA||'.'||ETL_MASTER_ROW.TABLENAME||' WHERE '||ETL_MASTER_ROW.INCREMENTALCOLUMN || ' <= '|| ETL_MASTER_ROW.OFFSET_VALUE  ;
                            RAISE INFO 'SOURCE_COUNT_SQL: %', SOURCE_COUNT_SQL;
                            EXECUTE SOURCE_COUNT_SQL INTO SOURCE_COUNT;
                            RAISE INFO 'SOURCE_COUNT: %', SOURCE_COUNT;
                            
                            
                            SOURCE_CURR_OFFSET_SQL := 'SELECT MAX('||ETL_MASTER_ROW.INCREMENTALCOLUMN||') FROM '||SOURCE_TABLES_SCHEMA||'.'||ETL_MASTER_ROW.TABLENAME||' ' ;
                            RAISE INFO 'SOURCE_CURR_OFFSET_SQL: %', SOURCE_CURR_OFFSET_SQL;
                            EXECUTE SOURCE_CURR_OFFSET_SQL INTO SOURCE_CURR_OFFSET;
                            RAISE INFO 'SOURCE_CURR_OFFSET: %', SOURCE_CURR_OFFSET;
                            
                            
                            
                            
                            
                            DATALAKE_COUNT_SQL := 'SELECT COUNT(*)  FROM '||REDSHIFT_TABLES_SCHEMA||'.'||ETL_MASTER_ROW.TABLENAME||' WHERE '||ETL_MASTER_ROW.INCREMENTALCOLUMN || ' <= '|| ETL_MASTER_ROW.OFFSET_VALUE  ;
                            RAISE INFO 'DATALAKE_COUNT_SQL: %', DATALAKE_COUNT_SQL;
                            EXECUTE DATALAKE_COUNT_SQL INTO DATALAKE_COUNT;
                            
                            RAISE INFO 'DATALAKE_COUNT: %', DATALAKE_COUNT;
                            
                            DATALAKE_CURR_OFFSET_SQL := 'SELECT MAX('||ETL_MASTER_ROW.INCREMENTALCOLUMN||')  FROM '||REDSHIFT_TABLES_SCHEMA||'.'||ETL_MASTER_ROW.TABLENAME||' ';
                            RAISE INFO 'DATALAKE_CURR_OFFSET_SQL: %', DATALAKE_CURR_OFFSET_SQL;
                            EXECUTE DATALAKE_CURR_OFFSET_SQL INTO DATALAKE_CURR_OFFSET;
                            
                            RAISE INFO 'DATALAKE_CURR_OFFSET: %', DATALAKE_CURR_OFFSET;
                            
                            
                            DATA_VALIDATION_INSERT_SQL := 'INSERT INTO '||REDSHIFT_ETL_MASTER_SCHEMA||'.'||REDSHIFT_DATA_VALIDATION_TABLE||'(GROUPID, TABLENAME, LOAD_TYPE,SOURCE_COUNT, DATALAKE_COUNT, SOURCE_CURR_OFFSET, DATALAKE_CURR_OFFSET) VALUES('||ETL_MASTER_ROW.GROUPID||','''||ETL_MASTER_ROW.TABLENAME||''','''||ETL_MASTER_ROW.LOADTYPE||''','||SOURCE_COUNT||','||DATALAKE_COUNT||',  '||SOURCE_CURR_OFFSET||','||DATALAKE_CURR_OFFSET||')' ;
                            
                           RAISE INFO 'DATA_VALIDATION_INSERT_SQL : %', DATA_VALIDATION_INSERT_SQL; 
                           
                           EXECUTE DATA_VALIDATION_INSERT_SQL ;
                           
                        ELSE    
                            
                            SOURCE_COUNT_SQL := 'SELECT COUNT(*) FROM '||SOURCE_TABLES_SCHEMA||'.'||ETL_MASTER_ROW.TABLENAME||' WHERE DATE('||ETL_MASTER_ROW.DATA_VALIDATION_DATE_COLUMN||') <= CURRENT_DATE - interval '''||DAYS_FILTER|| '''  ';
                            
                            
                            RAISE INFO 'SOURCE_COUNT_SQL: %', SOURCE_COUNT_SQL;
                            EXECUTE SOURCE_COUNT_SQL INTO SOURCE_COUNT;
                            
                            RAISE INFO 'SOURCE_COUNT: %', SOURCE_COUNT;
                            
                            
                            SOURCE_CURR_OFFSET_SQL := 'SELECT MAX('||ETL_MASTER_ROW.INCREMENTALCOLUMN||') FROM '||SOURCE_TABLES_SCHEMA||'.'||ETL_MASTER_ROW.TABLENAME||' ';
                            RAISE INFO 'SOURCE_CURR_OFFSET_SQL: %', SOURCE_CURR_OFFSET_SQL;
                            EXECUTE SOURCE_CURR_OFFSET_SQL INTO SOURCE_CURR_OFFSET_TIMESTAMP;
                            
                            RAISE INFO 'SOURCE_CURR_OFFSET_TIMESTAMP: %', SOURCE_CURR_OFFSET_TIMESTAMP;
                            
                            
                            
                            DATALAKE_COUNT_SQL := 'SELECT COUNT(*)  FROM '||REDSHIFT_TABLES_SCHEMA||'.'||ETL_MASTER_ROW.TABLENAME||' WHERE DATE('||ETL_MASTER_ROW.DATA_VALIDATION_DATE_COLUMN||') <= CURRENT_DATE - interval '''||DAYS_FILTER|| '''  ';
                            
                            RAISE INFO 'DATALAKE_COUNT_SQL: %', DATALAKE_COUNT_SQL;
                            EXECUTE DATALAKE_COUNT_SQL INTO DATALAKE_COUNT;
                            
                            RAISE INFO 'DATALAKE_COUNT: %', DATALAKE_COUNT;
                            
                            DATALAKE_CURR_OFFSET_SQL := 'SELECT MAX('||ETL_MASTER_ROW.INCREMENTALCOLUMN||')  FROM '||REDSHIFT_TABLES_SCHEMA||'.'||ETL_MASTER_ROW.TABLENAME||' ';
                            RAISE INFO 'DATALAKE_CURR_OFFSET_SQL: %', DATALAKE_CURR_OFFSET_SQL;
                            EXECUTE DATALAKE_CURR_OFFSET_SQL INTO DATALAKE_CURR_OFFSET_TIMESTAMP;
                            
                            RAISE INFO 'DATALAKE_CURR_OFFSET_TIMESTAMP: %', DATALAKE_CURR_OFFSET_TIMESTAMP;
                            
                            
                            
                            DATA_VALIDATION_INSERT_SQL := 'INSERT INTO '||REDSHIFT_ETL_MASTER_SCHEMA||'.'||REDSHIFT_DATA_VALIDATION_TABLE||'(GROUPID, TABLENAME, LOAD_TYPE,SOURCE_COUNT, DATALAKE_COUNT, SOURCE_CURR_STARTDATETIME, DATALAKE_CURR_STARTDATETIME) VALUES('||ETL_MASTER_ROW.GROUPID||','''||ETL_MASTER_ROW.TABLENAME||''','''||ETL_MASTER_ROW.LOADTYPE||''','||SOURCE_COUNT||','||DATALAKE_COUNT||','''||SOURCE_CURR_OFFSET_TIMESTAMP||''','''||DATALAKE_CURR_OFFSET_TIMESTAMP||''')' ;
                           RAISE INFO 'DATA_VALIDATION_INSERT_SQL : %', DATA_VALIDATION_INSERT_SQL; 
                            
                           EXECUTE DATA_VALIDATION_INSERT_SQL ;

                        END IF;
                        
                    ELSE
                        
                            SOURCE_COUNT_SQL := 'SELECT COUNT(*)  FROM '||SOURCE_TABLES_SCHEMA||'.'||ETL_MASTER_ROW.TABLENAME||' ';
                            
                            
		            RAISE INFO 'SOURCE_COUNT_SQL: %', SOURCE_COUNT_SQL;
		            EXECUTE SOURCE_COUNT_SQL INTO SOURCE_COUNT;
		            
		            RAISE INFO 'SOURCE_COUNT: %', SOURCE_COUNT;
		            
		            DATALAKE_COUNT_SQL := 'SELECT COUNT(*)  FROM '||REDSHIFT_TABLES_SCHEMA||'.'||ETL_MASTER_ROW.TABLENAME|| ' ' ;
		            
		            RAISE INFO 'DATALAKE_COUNT_SQL: %', DATALAKE_COUNT_SQL;
		            EXECUTE DATALAKE_COUNT_SQL INTO DATALAKE_COUNT;
		            
		            RAISE INFO 'DATALAKE_COUNT: %', DATALAKE_COUNT;
		            
		            DATA_VALIDATION_INSERT_SQL := 'INSERT INTO '||REDSHIFT_ETL_MASTER_SCHEMA||'.'||REDSHIFT_DATA_VALIDATION_TABLE||'(GROUPID, TABLENAME, LOAD_TYPE,SOURCE_COUNT, DATALAKE_COUNT) VALUES('||ETL_MASTER_ROW.GROUPID||','''||ETL_MASTER_ROW.TABLENAME||''','''||ETL_MASTER_ROW.LOADTYPE||''','||SOURCE_COUNT||','||DATALAKE_COUNT||')' ;
                           RAISE INFO 'DATA_VALIDATION_INSERT_SQL : %', DATA_VALIDATION_INSERT_SQL; 
                           
                           EXECUTE DATA_VALIDATION_INSERT_SQL ;
		            
		            

                    END IF;

                    ---------------------------------ERROR LOGGING------------------------------------------------------------
			    		
                    EXCEPTION WHEN OTHERS then
                    RAISE INFO 'Error message: %', SQLERRM;
                    RAISE INFO 'EXCEPTION OCCURED IN TABLE %', ETL_MASTER_ROW.TABLENAME ;

                    ERROR_INSERT_SQL := 'INSERT INTO PROD_ETL_FRAMEWORK.SP_ERROR_TABLE_NAME (GROUPID, TABLENAME,ERROR_MESSAGE) 
                    VALUES('||ETL_MASTER_ROW.GROUPID||  ','''||ETL_MASTER_ROW.TABLENAME||''',''' || SQLERRM||''')';
                    
                    RAISE INFO 'ERROR_INSERT_SQL: %', ERROR_INSERT_SQL;
                    execute ERROR_INSERT_SQL;
                    ----------------------------------------------------------------------------------------------------------
                    
                END;
                
            END LOOP;
	    
		CLOSE ETL_MASTER_CURSOR;
	END;
$_$
