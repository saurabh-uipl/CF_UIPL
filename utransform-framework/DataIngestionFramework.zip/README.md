# DataIngestionFramework
PySpark Data Ingestion Framework Which Can Run on Both AWS Glue &amp; AWS EMR
