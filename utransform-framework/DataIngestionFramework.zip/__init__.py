# DataIngestionFramework/__init__.py
from .DataIngestionFramework.src.data_migration import DataMigration


